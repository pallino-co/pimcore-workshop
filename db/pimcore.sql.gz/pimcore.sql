-- MariaDB dump 10.19  Distrib 10.11.13-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.11.13-MariaDB-ubu2204-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parentId` int(11) unsigned DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `filename` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT '',
  `path` varchar(765) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `mimetype` varchar(190) DEFAULT NULL,
  `creationDate` int(11) unsigned DEFAULT NULL,
  `modificationDate` int(11) unsigned DEFAULT NULL,
  `dataModificationDate` int(11) unsigned DEFAULT NULL,
  `userOwner` int(11) unsigned DEFAULT NULL,
  `userModification` int(11) unsigned DEFAULT NULL,
  `customSettings` longtext DEFAULT NULL,
  `hasMetaData` tinyint(1) NOT NULL DEFAULT 0,
  `versionCount` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fullpath` (`path`,`filename`),
  KEY `parentId` (`parentId`),
  KEY `filename` (`filename`),
  KEY `modificationDate` (`modificationDate`),
  KEY `versionCount` (`versionCount`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
INSERT INTO `assets` VALUES
(1,0,'folder','','/',NULL,1760512442,1760512442,NULL,1,1,NULL,0,0);
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_image_thumbnail_cache`
--

DROP TABLE IF EXISTS `assets_image_thumbnail_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets_image_thumbnail_cache` (
  `cid` int(11) unsigned NOT NULL,
  `name` varchar(190) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `filename` varchar(190) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL,
  `modificationDate` int(11) unsigned DEFAULT NULL,
  `filesize` int(11) unsigned DEFAULT NULL,
  `width` smallint(5) unsigned DEFAULT NULL,
  `height` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`cid`,`name`,`filename`),
  CONSTRAINT `FK_assets_image_thumbnail_cache_assets` FOREIGN KEY (`cid`) REFERENCES `assets` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_image_thumbnail_cache`
--

LOCK TABLES `assets_image_thumbnail_cache` WRITE;
/*!40000 ALTER TABLE `assets_image_thumbnail_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets_image_thumbnail_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_metadata`
--

DROP TABLE IF EXISTS `assets_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets_metadata` (
  `cid` int(11) unsigned NOT NULL,
  `name` varchar(190) NOT NULL,
  `language` varchar(10) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL DEFAULT '',
  `type` enum('input','textarea','asset','document','object','date','select','checkbox') DEFAULT NULL,
  `data` longtext DEFAULT NULL,
  PRIMARY KEY (`cid`,`name`,`language`),
  KEY `name` (`name`),
  CONSTRAINT `FK_assets_metadata_assets` FOREIGN KEY (`cid`) REFERENCES `assets` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_metadata`
--

LOCK TABLES `assets_metadata` WRITE;
/*!40000 ALTER TABLE `assets_metadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_items`
--

DROP TABLE IF EXISTS `cache_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_items` (
  `item_id` varbinary(255) NOT NULL,
  `item_data` mediumblob NOT NULL,
  `item_lifetime` int(10) unsigned DEFAULT NULL,
  `item_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_items`
--

LOCK TABLES `cache_items` WRITE;
/*!40000 ALTER TABLE `cache_items` DISABLE KEYS */;
INSERT INTO `cache_items` VALUES
('appworkers.restart_requested_timestamp','\0\0\0�����A\�;ӧ���',31536000,1760513694),
('asset_1','\0\0\0�����\ZPimcore\\Model\\Asset\\Folder\0*\0__dataVersionTimestamp\nh\�I�\0*\0path/\0*\0id\0*\0creationDate\nh\�I�\0*\0modificationDate\nh\�I�\0*\0versionCount\0\0*\0userOwner	\0*\0locked\0\0*\0userModification\0*\0parentId\0\0*\0_fulldump\0*\0typefolder\0*\0filename\r\0*\0mimetype\0\0*\0metadata\0\0*\0customSettings\0*\0customSettingsCanBeCached\0*\0customSettingsNeedRefresh\0*\0hasMetaData\0*\0siblings\0\0*\0dataChanged\0*\0dataModificationDate\0asset_1\�s �W�',31536000,1760513287),
('asset_1tags','\0\0\0\�s �W�',NULL,1760513287),
('class_applicationtags','\0\0\0)yds�',NULL,1760515344),
('class_job_categorytags','\0\0\0��BS\�i',NULL,1760513493),
('class_positiontags','\0\0\0\�G\�\�\'�',NULL,1760513818),
('document_1','\0\0\0�����Pimcore\\Model\\Document\\Page\0*\0__dataVersionTimestamp\nh\�I�\0*\0path/\0*\0id\0*\0creationDate\nh\�I�\0*\0modificationDate\nh\�I�\0*\0versionCount\0\0*\0userOwner	\0*\0locked\0\0*\0userModification\0*\0parentId\0\0*\0_fulldump\0*\0typepage\0*\0key\r\0*\0index\n\0B?\0*\0published\0*\0siblings\0\r\0*\0controller/App\\Controller\\DefaultController::defaultAction\0*\0template\r\0*\0editables\0\0*\0contentMainDocumentId%\0\Z\0*\0contentMasterDocumentId%\0*\0supportsContentMain\Z\0*\0missingRequiredEditable\0\0*\0staticGeneratorEnabled\0\Z\0*\0staticGeneratorLifetime\0\0*\0title\r\0*\0description\r\0*\0prettyUrl\0\ndocument_1vޓd�\�',31536000,1760513286),
('document_1tags','\0\0\0vޓd�\�',NULL,1760513286),
('object_1','\0\0\0�����Pimcore\\Model\\DataObject\\Folder\0*\0__dataVersionTimestamp\nh\�I�\0*\0path/\0*\0id\0*\0creationDate\nh\�I�\0*\0modificationDate\nh\�I�\0*\0versionCount\0\0*\0userOwner	\0*\0locked\0\0*\0userModification\0*\0parentId\0\0*\0_fulldump\0*\0typefolder\0*\0key\r\0*\0index\n\0B?\0*\0siblings\0\0*\0childrenSortBy\0\0*\0childrenSortOrder\0\n\0*\0classId\0\0*\0__rawRelationData\0object_1�\��8}F',31536000,1760513287),
('object_1tags','\0\0\0�\��8}F',NULL,1760513287),
('object_10','\0\0\0�����!Pimcore\\Model\\DataObject\\Position\0*\0__dataVersionTimestamp\nh\�T\0*\0path/positions/\0*\0id\n\0*\0creationDate\nh\�QA\0*\0modificationDate\nh\�T\0*\0versionCount\0*\0userOwner	\0*\0locked\0\0*\0userModification\0*\0parentId\0*\0_fulldump\0*\0typeobject\0*\0keydevops\0*\0index\0\0*\0siblings\0\0*\0childrenSortBy\0\0*\0childrenSortOrder\0\n\0*\0classIdposition__objectAwareFieldslocalizedfields\0*\0published\0*\0classNamePosition\0*\0localizedfields\'Pimcore\\Model\\DataObject\\Localizedfield\0*\0itemsentitleDevOps Engineerdescription\0it\"#$�<p><strong>Cloud infrastructure management, deployment automation, monitoring, and security. Experience with Kubernetes, Docker, Terraform, and CI/CD pipelines.</strong></p>\n\0*\0context\"\0*\0objectId\n\0*\0siteROMA	object_10��\�\\zclass_position\�G\�\�\'�',31536000,1760515096),
('object_10tags','\0\0\0��\�\\z',NULL,1760515096),
('object_11','\0\0\0�����!Pimcore\\Model\\DataObject\\Position\0*\0__dataVersionTimestamp\nh\�TO\0*\0path/positions/\0*\0id\0*\0creationDate\nh\�Qm\0*\0modificationDate\nh\�TO\0*\0versionCount\0*\0userOwner	\0*\0locked\0\0*\0userModification\0*\0parentId\0*\0_fulldump\0*\0typeobject\0*\0keyproduct-manager\0*\0index\0\0*\0siblings\0\0*\0childrenSortBy\0\0*\0childrenSortOrder\0\n\0*\0classIdposition__objectAwareFieldslocalizedfields\0*\0published\0*\0classNamePosition\0*\0localizedfields\'Pimcore\\Model\\DataObject\\Localizedfield\0*\0itemsentitle\0description\0it\"Product Manager#\�<p><strong>Product roadmap coordination, requirements analysis, stakeholder management, and KPI definition. Experience with Agile methodologies and cross-team communication required.</strong></p>\n\0*\0context\"\0*\0objectId\0*\0siteMI	object_11\�z#�\�Gclass_position\�G\�\�\'�',31536000,1760515151),
('object_11tags','\0\0\0\�z#�\�G',NULL,1760515151),
('object_12','\0\0\0�����$Pimcore\\Model\\DataObject\\JobCategory\0*\0__dataVersionTimestamp\nh\�R\�\0*\0path/categories/\0*\0id\0*\0creationDate\nh\�Q�\0*\0modificationDate\nh\�R\�\0*\0versionCount\0*\0userOwner	\0*\0locked\0\0*\0userModification\0*\0parentId\0*\0_fulldump\0*\0typeobject\0*\0keyproduct\0*\0index\0\0*\0siblings\0\0*\0childrenSortBy\0\0*\0childrenSortOrder\0\n\0*\0classIdjob_category__objectAwareFieldslocalizedfields\0*\0published\0*\0classNameJobCategory\0*\0localizedfields\'Pimcore\\Model\\DataObject\\Localizedfield\0*\0itemsentitleProductdescription\0it\"Prodotto$\0\n\0*\0context\"\0*\0objectId	object_12f\��\�class_job_category��BS\�i',31536000,1760514908),
('object_12tags','\0\0\0f\��\�',NULL,1760514908),
('object_13','\0\0\0�����!Pimcore\\Model\\DataObject\\Position\0*\0__dataVersionTimestamp\nh\�T:\0*\0path/positions/\0*\0id\r\0*\0creationDate\nh\�Q�\0*\0modificationDate\nh\�T:\0*\0versionCount\0*\0userOwner	\0*\0locked\0\0*\0userModification\0*\0parentId\0*\0_fulldump\0*\0typeobject\0*\0key\rhr-generalist\0*\0index\0\0*\0siblings\0\0*\0childrenSortBy\0\0*\0childrenSortOrder\0\n\0*\0classIdposition__objectAwareFieldslocalizedfields\0*\0published\0*\0classNamePosition\0*\0localizedfields\'Pimcore\\Model\\DataObject\\Localizedfield\0*\0itemsentitle\rHR Generalistdescription\0it\"#$�<p><strong>HR process management: recruiting, onboarding, training, and personnel administration. Good communication skills and knowledge of labor regulations.</strong></p>\n\0*\0context\"\0*\0objectId\r\0*\0site\r	object_13�	ppVclass_position\�G\�\�\'�',31536000,1760515206),
('object_13tags','\0\0\0�	ppV',NULL,1760515130),
('object_14','\0\0\0�����!Pimcore\\Model\\DataObject\\Position\0*\0__dataVersionTimestamp\nh\�T\r\0*\0path/positions/\0*\0id\0*\0creationDate\nh\�RB\0*\0modificationDate\nh\�T\r\0*\0versionCount\0*\0userOwner	\0*\0locked\0\0*\0userModification\0*\0parentId\0*\0_fulldump\0*\0typeobject\0*\0keydata-scientist\0*\0index\0\0*\0siblings\0\0*\0childrenSortBy\0\0*\0childrenSortOrder\0\n\0*\0classIdposition__objectAwareFieldslocalizedfields\0*\0published\0*\0classNamePosition\0*\0localizedfields\'Pimcore\\Model\\DataObject\\Localizedfield\0*\0itemsentitleData Scientistdescription\0it\"#$�<p><strong>Data analysis, predictive modeling, and insight visualization to support business decisions. Experience with Python, ML, and SQL required.</strong></p>\n\0*\0context\"\0*\0objectId\0*\0sitePD	object_14\�eD�t{class_position\�G\�\�\'�',31536000,1760515085),
('object_14tags','\0\0\0\�eD�t{',NULL,1760515085),
('object_15','\0\0\0�����!Pimcore\\Model\\DataObject\\Position\0*\0__dataVersionTimestamp\nh\�S\�\0*\0path/positions/\0*\0id\0*\0creationDate\nh\�Rc\0*\0modificationDate\nh\�S\�\0*\0versionCount\0*\0userOwner	\0*\0locked\0\0*\0userModification\0*\0parentId\0*\0_fulldump\0*\0typeobject\0*\0keyux-designer\0*\0index\0\0*\0siblings\0\0*\0childrenSortBy\0\0*\0childrenSortOrder\0\n\0*\0classIdposition__objectAwareFieldslocalizedfields\0*\0published\0*\0classNamePosition\0*\0localizedfields\'Pimcore\\Model\\DataObject\\Localizedfield\0*\0itemsentitleUX/UI Designerdescription\0it\"#$�<p><strong>Progettazione interfacce e prototipi centrati sull&#039;utente, test di usabilità e collaborazione con dev. Esperienza in Figma, wireframing e design system.</strong></p>\n\0*\0context\"\0*\0objectId\0*\0siteTO	object_15��]\�class_position\�G\�\�\'�',31536000,1760515176),
('object_15tags','\0\0\0��]\�',NULL,1760515074),
('object_16','\0\0\0�����$Pimcore\\Model\\DataObject\\JobCategory\0*\0__dataVersionTimestamp\nh\�R\�\0*\0path/categories/\0*\0id\0*\0creationDate\nh\�Rv\0*\0modificationDate\nh\�R\�\0*\0versionCount\0*\0userOwner	\0*\0locked\0\0*\0userModification\0*\0parentId\0*\0_fulldump\0*\0typeobject\0*\0keydesign\0*\0index\0\0*\0siblings\0\0*\0childrenSortBy\0\0*\0childrenSortOrder\0\n\0*\0classIdjob_category__objectAwareFieldslocalizedfields\0*\0published\0*\0classNameJobCategory\0*\0localizedfields\'Pimcore\\Model\\DataObject\\Localizedfield\0*\0itemsentitleDesigndescription\0it\"#$\0\n\0*\0context\"\0*\0objectId	object_16^FNC\�class_job_category��BS\�i',31536000,1760514908),
('object_16tags','\0\0\0^FNC\�',NULL,1760514908),
('object_17','\0\0\0�����!Pimcore\\Model\\DataObject\\Position\0*\0__dataVersionTimestamp\nh\�S\�\0*\0path/positions/\0*\0id\0*\0creationDate\nh\�R�\0*\0modificationDate\nh\�S\�\0*\0versionCount\0*\0userOwner	\0*\0locked\0\0*\0userModification\0*\0parentId\0*\0_fulldump\0*\0typeobject\0*\0keyautomation-engineer\0*\0index\0\0*\0siblings\0\0*\0childrenSortBy\0\0*\0childrenSortOrder\0\n\0*\0classIdposition__objectAwareFieldslocalizedfields\0*\0published\0*\0classNamePosition\0*\0localizedfields\'Pimcore\\Model\\DataObject\\Localizedfield\0*\0itemsentitleQA Automation Engineerdescription\0it\"#$�<p><strong>Progettazione e sviluppo di test automatici, integrazione in pipeline CI e verifica regressioni. Esperienza con Selenium, Cypress o Playwright e testing API.</strong></p>\n\0*\0context\"\0*\0objectId\0*\0sitePD	object_1755\�h8class_position\�G\�\�\'�',31536000,1760515075),
('object_17tags','\0\0\055\�h8',NULL,1760515075),
('object_18','\0\0\0�����!Pimcore\\Model\\DataObject\\Position\0*\0__dataVersionTimestamp\nh\�S\�\0*\0path/positions/\0*\0id\0*\0creationDate\nh\�R�\0*\0modificationDate\nh\�S\�\0*\0versionCount\0*\0userOwner	\0*\0locked\0\0*\0userModification\0*\0parentId\0*\0_fulldump\0*\0typeobject\0*\0key\Ztechnical-support-engineer\0*\0index\0\0*\0siblings\0\0*\0childrenSortBy\0\0*\0childrenSortOrder\0\n\0*\0classIdposition__objectAwareFieldslocalizedfields\0*\0published\0*\0classNamePosition\0*\0localizedfields\'Pimcore\\Model\\DataObject\\Localizedfield\0*\0itemsentitle\ZTechnical Support Engineerdescription\0it\"#$�<p><strong>Supporto tecnico di secondo livello, troubleshooting, gestione ticket e documentazione. Richiesta conoscenza di reti, sistemi operativi e strumenti di ticketing.</strong></p>\n\0*\0context\"\0*\0objectId\0*\0siteROMA	object_185\�Q!�class_position\�G\�\�\'�',31536000,1760515164),
('object_18tags','\0\0\05\�Q!�',NULL,1760515075),
('object_19','\0\0\0�����$Pimcore\\Model\\DataObject\\JobCategory\0*\0__dataVersionTimestamp\nh\�R\�\0*\0path/categories/\0*\0id\0*\0creationDate\nh\�R\�\0*\0modificationDate\nh\�R\�\0*\0versionCount\0*\0userOwner	\0*\0locked\0\0*\0userModification\0*\0parentId\0*\0_fulldump\0*\0typeobject\0*\0key	marketing\0*\0index\0\0*\0siblings\0\0*\0childrenSortBy\0\0*\0childrenSortOrder\0\n\0*\0classIdjob_category__objectAwareFieldslocalizedfields\0*\0published\0*\0classNameJobCategory\0*\0localizedfields\'Pimcore\\Model\\DataObject\\Localizedfield\0*\0itemsentitle	Marketingdescription\0it\"#$\0\n\0*\0context\"\0*\0objectId	object_19\�.\�\�[class_job_category��BS\�i',31536000,1760514908),
('object_19tags','\0\0\0\�.\�\�[',NULL,1760514908),
('object_2','\0\0\0�����Pimcore\\Model\\DataObject\\Folder\0*\0__dataVersionTimestamp\nh\�L�\0*\0path/\0*\0id\0*\0creationDate\nh\�L�\0*\0modificationDate\nh\�L�\0*\0versionCount\0*\0userOwner	\0*\0locked\0\0*\0userModification\0*\0parentId\0*\0_fulldump\0*\0typefolder\0*\0key	positions\0*\0index\0\0*\0siblings\0\0*\0childrenSortBy\0\0*\0childrenSortOrder\0\n\0*\0classId\0\0*\0__rawRelationData\0object_2\�8\��',31536000,1760513287),
('object_2tags','\0\0\0\�8\��',NULL,1760513287),
('object_20','\0\0\0�����!Pimcore\\Model\\DataObject\\Position\0*\0__dataVersionTimestamp\nh\�TE\0*\0path/positions/\0*\0id\0*\0creationDate\nh\�R\�\0*\0modificationDate\nh\�TE\0*\0versionCount\0*\0userOwner	\0*\0locked\0\0*\0userModification\0*\0parentId\0*\0_fulldump\0*\0typeobject\0*\0keymarketing-specialist\0*\0index\0\0*\0siblings\0\0*\0childrenSortBy\0\0*\0childrenSortOrder\0\n\0*\0classIdposition__objectAwareFieldslocalizedfields\0*\0published\0*\0classNamePosition\0*\0localizedfields\'Pimcore\\Model\\DataObject\\Localizedfield\0*\0itemsentitleMarketing Specialistdescription\0it\"#$�<p><strong>Digital campaign planning and management, performance analysis, SEO/SEM, and content strategy. Experience with analytics and advertising tools.</strong></p>\n\0*\0context\"\0*\0objectId\0*\0sitePD	object_20U\�\�\�\�class_position\�G\�\�\'�',31536000,1760515142),
('object_20tags','\0\0\0U\�\�\�\�',NULL,1760515142),
('object_21','\0\0\0�����$Pimcore\\Model\\DataObject\\Application\Z\0*\0__dataVersionTimestamp\nh\�U:\0*\0path/applications/\0*\0id\0*\0creationDate\nh\�U\0*\0modificationDate\nh\�U:\0*\0versionCount\0*\0userOwner	\0*\0locked\0\0*\0userModification\0*\0parentId\0*\0_fulldump\0*\0typeobject\0*\0key\rapplication-1\0*\0index\0\0*\0siblings\0\0*\0childrenSortBy\0\0*\0childrenSortOrder\0\n\0*\0classIdapplication__objectAwareFields\0\0*\0published\0*\0classNameApplication\0*\0firstnameLeonardo\0*\0lastnameDa Vinci\0*\0emailleo_da_vinci@inventore.co\n\0*\0privacy%Pimcore\\Model\\DataObject\\Data\\Consent\n\0*\0consent	\0*\0noteId\0*\0note\0	\0*\0_owner\0\r\0*\0_fieldname\0\0*\0_language\0\0*\0marketing\Z$%&\0\'\0(\0)\0*\0	object_21�\�\"�\�class_application)yds�',31536000,1760515386),
('object_21tags','\0\0\0�\�\"�\�',NULL,1760515386),
('object_22','\0\0\0�����$Pimcore\\Model\\DataObject\\Application\Z\0*\0__dataVersionTimestamp\nh\�Ut\0*\0path/applications/\0*\0id\0*\0creationDate\nh\�UE\0*\0modificationDate\nh\�Ut\0*\0versionCount\0*\0userOwner	\0*\0locked\0\0*\0userModification\0*\0parentId\0*\0_fulldump\0*\0typeobject\0*\0key\rapplication-2\0*\0index\0\0*\0siblings\0\0*\0childrenSortBy\0\0*\0childrenSortOrder\0\n\0*\0classIdapplication__objectAwareFields\0\0*\0published\0*\0classNameApplication\0*\0firstnameGiovanna\0*\0lastnameD\'arco\0*\0emailgio@orleans.com\n\0*\0privacy%Pimcore\\Model\\DataObject\\Data\\Consent\n\0*\0consent	\0*\0noteId\0*\0note\0	\0*\0_owner\0\r\0*\0_fieldname\0\0*\0_language\0\0*\0marketing\Z$%&\0\'\0(\0)\0*\0	object_22\�\�o\��class_application)yds�',31536000,1760515449),
('object_22tags','\0\0\0\�\�o\��',NULL,1760515449),
('object_3','\0\0\0�����Pimcore\\Model\\DataObject\\Folder\0*\0__dataVersionTimestamp\nh\�L�\0*\0path/\0*\0id\0*\0creationDate\nh\�L�\0*\0modificationDate\nh\�L�\0*\0versionCount\0*\0userOwner	\0*\0locked\0\0*\0userModification\0*\0parentId\0*\0_fulldump\0*\0typefolder\0*\0keyapplications\0*\0index\0\0*\0siblings\0\0*\0childrenSortBy\0\0*\0childrenSortOrder\0\n\0*\0classId\0\0*\0__rawRelationData\0object_3�MZ�S',31536000,1760513287),
('object_3tags','\0\0\0�MZ�S',NULL,1760513287),
('object_4','\0\0\0�����Pimcore\\Model\\DataObject\\Folder\0*\0__dataVersionTimestamp\nh\�R\�\0*\0path/\0*\0id\0*\0creationDate\nh\�L�\0*\0modificationDate\nh\�R\�\0*\0versionCount\0*\0userOwner	\0*\0locked\0\0*\0userModification\0*\0parentId\0*\0_fulldump\0*\0typefolder\0*\0key\ncategories\0*\0index\0\0*\0siblings\0\0*\0childrenSortBy\0\0*\0childrenSortOrder\0\n\0*\0classId\0\0*\0__rawRelationData\0object_4�` Q$�',31536000,1760514807),
('object_4tags','\0\0\0�` Q$�',NULL,1760514807),
('object_5','\0\0\0�����$Pimcore\\Model\\DataObject\\JobCategory\0*\0__dataVersionTimestamp\nh\�M\"\0*\0path/categories/\0*\0id\0*\0creationDate\nh\�L�\0*\0modificationDate\nh\�M\"\0*\0versionCount\0*\0userOwner	\0*\0locked\0\0*\0userModification\0*\0parentId\0*\0_fulldump\0*\0typeobject\0*\0keyhr\0*\0index\0\0*\0siblings\0\0*\0childrenSortBy\0\0*\0childrenSortOrder\0\n\0*\0classIdjob_category__objectAwareFieldslocalizedfields\0*\0published\0*\0classNameJobCategory\0*\0localizedfields\'Pimcore\\Model\\DataObject\\Localizedfield\0*\0itemsentitleHRdescription\0it\"\0$\0\n\0*\0context\"\0*\0objectIdobject_5��BS\�iclass_job_category)',31536000,1760513493),
('object_5tags','\0\0\0��BS\�i',NULL,1760513493),
('object_6','\0\0\0�����$Pimcore\\Model\\DataObject\\JobCategory\0*\0__dataVersionTimestamp\nh\�M#\0*\0path/categories/\0*\0id\0*\0creationDate\nh\�L�\0*\0modificationDate\nh\�M#\0*\0versionCount\0*\0userOwner	\0*\0locked\0\0*\0userModification\0*\0parentId\0*\0_fulldump\0*\0typeobject\0*\0keyit\0*\0index\0\0*\0siblings\0\0*\0childrenSortBy\0\0*\0childrenSortOrder\0\n\0*\0classIdjob_category__objectAwareFieldslocalizedfields\0*\0published\0*\0classNameJobCategory\0*\0localizedfields\'Pimcore\\Model\\DataObject\\Localizedfield\0*\0itemsentitle\0description\0\"\0#\0\n\0*\0context\"\0*\0objectIdobject_6T\�u�\�class_job_category��BS\�i',31536000,1760513494),
('object_6tags','\0\0\0T\�u�\�',NULL,1760513494),
('object_7','\0\0\0�����$Pimcore\\Model\\DataObject\\JobCategory\0*\0__dataVersionTimestamp\nh\�M#\0*\0path/categories/\0*\0id\0*\0creationDate\nh\�L\�\0*\0modificationDate\nh\�M#\0*\0versionCount\0*\0userOwner	\0*\0locked\0\0*\0userModification\0*\0parentId\0*\0_fulldump\0*\0typeobject\0*\0keystaff\0*\0index\0\0*\0siblings\0\0*\0childrenSortBy\0\0*\0childrenSortOrder\0\n\0*\0classIdjob_category__objectAwareFieldslocalizedfields\0*\0published\0*\0classNameJobCategory\0*\0localizedfields\'Pimcore\\Model\\DataObject\\Localizedfield\0*\0itemsentitleStaffdescription\0it\"#$\0\n\0*\0context\"\0*\0objectIdobject_7/�\��class_job_category��BS\�i',31536000,1760514178),
('object_7tags','\0\0\0/�\��',NULL,1760514178),
('object_8','\0\0\0�����!Pimcore\\Model\\DataObject\\Position\0*\0__dataVersionTimestamp\nh\�S\�\0*\0path/positions/\0*\0id\0*\0creationDate\nh\�O\Z\0*\0modificationDate\nh\�S\�\0*\0versionCount\0*\0userOwner	\0*\0locked\0\0*\0userModification\0*\0parentId\0*\0_fulldump\0*\0typeobject\0*\0keybackend-dev\0*\0index\0\0*\0siblings\0\0*\0childrenSortBy\0\0*\0childrenSortOrder\0\n\0*\0classIdposition__objectAwareFieldslocalizedfields\0*\0published\0*\0classNamePosition\0*\0localizedfields\'Pimcore\\Model\\DataObject\\Localizedfield\0*\0itemsentitleBackend Senior Developerdescription\0it\"Sviluppatore Backend Senior$�<p><strong>Scalable API design and development, database management, and performance optimization. Experience with PHP/Laravel or Symfony and knowledge of CI/CD are required.</strong></p>\n\0*\0context\"\0*\0objectId\0*\0siteMIobject_8\�m\�\�\�class_position\�G\�\�\'�',31536000,1760515048),
('object_8tags','\0\0\0\�m\�\�\�',NULL,1760515048),
('object_9','\0\0\0�����!Pimcore\\Model\\DataObject\\Position\0*\0__dataVersionTimestamp\nh\�T.\0*\0path/positions/\0*\0id	\0*\0creationDate\nh\�Q\0*\0modificationDate\nh\�T.\0*\0versionCount\0*\0userOwner	\0*\0locked\0\0*\0userModification\0*\0parentId\0*\0_fulldump\0*\0typeobject\0*\0keyfrontend-dev\0*\0index\0\0*\0siblings\0\0*\0childrenSortBy\0\0*\0childrenSortOrder\0\n\0*\0classIdposition__objectAwareFieldslocalizedfields\0*\0published\0*\0classNamePosition\0*\0localizedfields\'Pimcore\\Model\\DataObject\\Localizedfield\0*\0itemsentitleFrontend Developer Reactdescription\0it\"#$�<p><strong>Responsive interface development with React, REST/GraphQL integration, and a focus on accessibility. Experience with TypeScript, testing, and optimization.</strong></p>\n\0*\0context\"\0*\0objectId	\0*\0sitePDobject_9lա�g�class_position\�G\�\�\'�',31536000,1760515118),
('object_9tags','\0\0\0lա�g�',NULL,1760515118),
('redirecttags','\0\0\0\�\\g�\�',NULL,1760513285),
('resourcetags','\0\0\0�\�$',NULL,1760513818),
('routetags','\0\0\0\�\\g�\�',NULL,1760513285),
('sitetags','\0\0\0��vLG\�',NULL,1760513286),
('site_domain_37b882196f044d0e7a59c32cde08e2e4','\0\0\0�����failedsystem\�\\g�\�site��vLG\�',31536000,1760513286),
('systemtags','\0\0\03xr',NULL,1760513721),
('system_resource_columns_edit_lock','\0\0\0�����columns\0idcidctypeuserId	sessionIddateprimaryKeyColumns\0system3xrresource�\�$',31536000,1760513818),
('system_resource_columns_gridconfig_favourites','\0\0\0�����columns\0ownerIdclassIdobjectIdgridConfigId\nsearchTypetypeprimaryKeyColumns\0system3xrresource�\�$',31536000,1760515001),
('system_resource_columns_gridconfigs','\0\0\0�����columns\0idownerIdclassIdname\nsearchTypetypeconfigdescriptioncreationDate	modificationDate\n\rshareGloballysetAsFavouriteprimaryKeyColumns\0system3xrresource�\�$',31536000,1760514942),
('system_resource_columns_versions','\0\0\0�����columns\0idcidctypeuserIdnote\nstackTracedatepublic\nserialized	versionCount\nbinaryFileHashbinaryFileIdautoSave\rstorageTypeprimaryKeyColumns\0system3xrresource�\�$',31536000,1760513821),
('system_route_redirect','\0\0\0�����\0system3xrredirect\�\\g�\�route',31536000,1760513721),
('system_supported_js_locales_en','\0\0\0�����\�fa-AFAfghanistan [fa-AF]ps-AFAfghanistan [ps-AF]afAfrikaans [af]agqAghem [agq]ak	Akan [ak]sq-ALAlbania [sq-AL]sq\rAlbanian [sq]ar-DZAlgeria [ar-DZ]fr-DZAlgeria [fr-DZ]kab-DZAlgeria [kab-DZ]en-ASAmerican Samoa [en-AS]amAmharic [am]ca-ADAndorra [ca-AD]ln-AOAngola [ln-AO]pt-AOAngola [pt-AO]en-AIAnguilla [en-AI]en-AGAntigua & Barbuda [en-AG]arArabic [ar]es-ARArgentina [es-AR]hy-AMArmenia [hy-AM]hy\rArmenian [hy]nl-AW\rAruba [nl-AW]as\rAssamese [as]astAsturian [ast]asa	Asu [asa]en-AUAustralia [en-AU]de-ATAustria [de-AT]en-ATAustria [en-AT]az-Cyrl Azerbaijani (Cyrillic) [az-Cyrl]az-LatnAzerbaijani (Latin) [az-Latn]azAzerbaijani [az]ksfBafia [ksf]en-BSBahamas [en-BS]ar-BHBahrain [ar-BH]bmBambara [bm]bnBangla [bn]bn-BDBangladesh [bn-BD]ccp-BDBangladesh [ccp-BD]en-BBBarbados [en-BB]basBasaa [bas]euBasque [eu]be-BYBelarus [be-BY]ru-BYBelarus [ru-BY]beBelarusian [be]de-BEBelgium [de-BE]en-BEBelgium [en-BE]fr-BEBelgium [fr-BE]nl-BEBelgium [nl-BE]en-BZBelize [en-BZ]es-BZBelize [es-BZ]bemBemba [bem]bez\nBena [bez]fr-BJ\rBenin [fr-BJ]yo-BJ\rBenin [yo-BJ]en-BMBermuda [en-BM]bhoBhojpuri [bho]dz-BTBhutan [dz-BT]brx\nBodo [brx]es-BOBolivia [es-BO]qu-BOBolivia [qu-BO]hr-BABosnia & Herzegovina [hr-BA]bs-CyrlBosnian (Cyrillic) [bs-Cyrl]bs-LatnBosnian (Latin) [bs-Latn]bsBosnian [bs]en-BWBotswana [en-BW]es-BRBrazil [es-BR]kgp-BRBrazil [kgp-BR]pt-BRBrazil [pt-BR]yrl-BRBrazil [yrl-BR]brBreton [br]en-IO&British Indian Ocean Territory [en-IO]en-VGBritish Virgin Islands [en-VG]ms-BNBrunei [ms-BN]bg-BGBulgaria [bg-BG]bgBulgarian [bg]fr-BFBurkina Faso [fr-BF]myBurmese [my]en-BIBurundi [en-BI]fr-BIBurundi [fr-BI]rn-BIBurundi [rn-BI]km-KHCambodia [km-KH]agq-CMCameroon [agq-CM]bas-CMCameroon [bas-CM]dua-CMCameroon [dua-CM]en-CMCameroon [en-CM]ewo-CMCameroon [ewo-CM]fr-CMCameroon [fr-CM]jgo-CMCameroon [jgo-CM]kkj-CMCameroon [kkj-CM]ksf-CMCameroon [ksf-CM]mgo-CMCameroon [mgo-CM]mua-CMCameroon [mua-CM]nmg-CMCameroon [nmg-CM]nnh-CMCameroon [nnh-CM]yav-CMCameroon [yav-CM]en-CACanada [en-CA]fr-CACanada [fr-CA]es-ICCanary Islands [es-IC]yue-Hans!Cantonese (Simplified) [yue-Hans]yue-Hant\"Cantonese (Traditional) [yue-Hant]yueCantonese [yue]kea-CVCape Verde [kea-CV]pt-CVCape Verde [pt-CV]nl-BQCaribbean Netherlands [nl-BQ]caCatalan [ca]en-KYCayman Islands [en-KY]ceb\rCebuano [ceb]fr-CF Central African Republic [fr-CF]ln-CF Central African Republic [ln-CF]sg-CF Central African Republic [sg-CF]tzmCentral Atlas Tamazight [tzm]ckbCentral Kurdish [ckb]es-EACeuta & Melilla [es-EA]ar-TDChad [ar-TD]fr-TDChad [fr-TD]ccpChakma [ccp]ceChechen [ce]chrCherokee [chr]cggChiga [cgg]es-CL\rChile [es-CL]bo-CN\rChina [bo-CN]ii-CN\rChina [ii-CN]ug-CN\rChina [ug-CN]zh-HansChinese (Simplified) [zh-Hans]zh-HantChinese (Traditional) [zh-Hant]zhChinese [zh]en-CXChristmas Island [en-CX]cvChuvash [cv]en-CCCocos (Keeling) Islands [en-CC]kshColognian [ksh]es-COColombia [es-CO]yrl-COColombia [yrl-CO]ar-KMComoros [ar-KM]fr-KMComoros [fr-KM]fr-CGCongo - Brazzaville [fr-CG]ln-CGCongo - Brazzaville [ln-CG]fr-CDCongo - Kinshasa [fr-CD]ln-CDCongo - Kinshasa [ln-CD]lu-CDCongo - Kinshasa [lu-CD]sw-CDCongo - Kinshasa [sw-CD]en-CKCook Islands [en-CK]kwCornish [kw]es-CRCosta Rica [es-CR]hr-HRCroatia [hr-HR]hr\rCroatian [hr]es-CUCuba [es-CU]nl-CWCuraçao [nl-CW]el-CYCyprus [el-CY]en-CYCyprus [en-CY]tr-CYCyprus [tr-CY]cs\nCzech [cs]cs-CZCzechia [cs-CZ]fr-CICôte d’Ivoire [fr-CI]daDanish [da]da-DKDenmark [da-DK]en-DKDenmark [en-DK]fo-DKDenmark [fo-DK]en-DGDiego Garcia [en-DG]ar-DJDjibouti [ar-DJ]fr-DJDjibouti [fr-DJ]so-DJDjibouti [so-DJ]doiDogri [doi]en-DMDominica [en-DM]es-DO\ZDominican Republic [es-DO]duaDuala [dua]nl\nDutch [nl]dz\rDzongkha [dz]es-ECEcuador [es-EC]qu-ECEcuador [qu-EC]ar-EG\rEgypt [ar-EG]es-SVEl Salvador [es-SV]ebu\nEmbu [ebu]enEnglish [en]es-GQEquatorial Guinea [es-GQ]fr-GQEquatorial Guinea [fr-GQ]pt-GQEquatorial Guinea [pt-GQ]ar-EREritrea [ar-ER]en-EREritrea [en-ER]ti-EREritrea [ti-ER]eoEsperanto [eo]et-EEEstonia [et-EE]et\rEstonian [et]en-SZEswatini [en-SZ]am-ETEthiopia [am-ET]om-ETEthiopia [om-ET]so-ETEthiopia [so-ET]ti-ETEthiopia [ti-ET]en-150Europe [en-150]eeEwe [ee]ewoEwondo [ewo]en-FKFalkland Islands [en-FK]fo-FOFaroe Islands [fo-FO]foFaroese [fo]en-FJFiji [en-FJ]filFilipino [fil]en-FIFinland [en-FI]fi-FIFinland [fi-FI]se-FIFinland [se-FI]smn-FIFinland [smn-FI]sv-FIFinland [sv-FI]fiFinnish [fi]br-FRFrance [br-FR]ca-FRFrance [ca-FR]fr-FRFrance [fr-FR]gsw-FRFrance [gsw-FR]fr-GFFrench Guiana [fr-GF]fr-PFFrench Polynesia [fr-PF]frFrench [fr]furFriulian [fur]ff-AdlmFula (Adlam) [ff-Adlm]ff-LatnFula (Latin) [ff-Latn]ff	Fula [ff]fr-GA\rGabon [fr-GA]gl\rGalician [gl]en-GMGambia [en-GM]lg\nGanda [lg]ka-GEGeorgia [ka-GE]os-GEGeorgia [os-GE]ka\rGeorgian [ka]deGerman [de]de-DEGermany [de-DE]dsb-DEGermany [dsb-DE]en-DEGermany [en-DE]hsb-DEGermany [hsb-DE]ksh-DEGermany [ksh-DE]ak-GH\rGhana [ak-GH]ee-GH\rGhana [ee-GH]en-GH\rGhana [en-GH]ha-GH\rGhana [ha-GH]en-GIGibraltar [en-GI]el-GRGreece [el-GR]el\nGreek [el]da-GLGreenland [da-GL]kl-GLGreenland [kl-GL]en-GDGrenada [en-GD]fr-GPGuadeloupe [fr-GP]en-GUGuam [en-GU]es-GTGuatemala [es-GT]en-GGGuernsey [en-GG]fr-GNGuinea [fr-GN]pt-GWGuinea-Bissau [pt-GW]gu\rGujarati [gu]guzGusii [guz]en-GYGuyana [en-GY]fr-HT\rHaiti [fr-HT]bgcHaryanvi [bgc]ha\nHausa [ha]hawHawaiian [haw]heHebrew [he]hi-LatnHindi (Latin) [hi-Latn]hi\nHindi [hi]es-HNHonduras [es-HN]en-HKHong Kong SAR China [en-HK]huHungarian [hu]hu-HUHungary [hu-HU]is-ISIceland [is-IS]isIcelandic [is]ig	Igbo [ig]smnInari Sami [smn]as-IN\rIndia [as-IN]bgc-INIndia [bgc-IN]bho-INIndia [bho-IN]bn-IN\rIndia [bn-IN]bo-IN\rIndia [bo-IN]brx-INIndia [brx-IN]ccp-INIndia [ccp-IN]doi-INIndia [doi-IN]en-IN\rIndia [en-IN]gu-IN\rIndia [gu-IN]hi-IN\rIndia [hi-IN]kn-IN\rIndia [kn-IN]kok-INIndia [kok-IN]mai-INIndia [mai-IN]ml-IN\rIndia [ml-IN]mr-IN\rIndia [mr-IN]ne-IN\rIndia [ne-IN]or-IN\rIndia [or-IN]raj-INIndia [raj-IN]sa-IN\rIndia [sa-IN]ta-IN\rIndia [ta-IN]te-IN\rIndia [te-IN]ur-IN\rIndia [ur-IN]id-IDIndonesia [id-ID]jv-IDIndonesia [jv-ID]ms-IDIndonesia [ms-ID]idIndonesian [id]iaInterlingua [ia]ckb-IR\rIran [ckb-IR]fa-IRIran [fa-IR]lrc-IR\rIran [lrc-IR]mzn-IR\rIran [mzn-IR]ar-IQIraq [ar-IQ]ckb-IQ\rIraq [ckb-IQ]lrc-IQ\rIraq [lrc-IQ]en-IEIreland [en-IE]ga-IEIreland [ga-IE]ga\nIrish [ga]en-IMIsle of Man [en-IM]gv-IMIsle of Man [gv-IM]ar-ILIsrael [ar-IL]en-ILIsrael [en-IL]he-ILIsrael [he-IL]itItalian [it]ca-IT\rItaly [ca-IT]de-IT\rItaly [de-IT]fur-ITItaly [fur-IT]it-IT\rItaly [it-IT]sc-IT\rItaly [sc-IT]en-JMJamaica [en-JM]ja-JP\rJapan [ja-JP]ja\rJapanese [ja]jv\rJavanese [jv]en-JEJersey [en-JE]dyoJola-Fonyi [dyo]ar-JOJordan [ar-JO]keaKabuverdianu [kea]kabKabyle [kab]kgpKaingang [kgp]kkj\nKako [kkj]klKalaallisut [kl]klnKalenjin [kln]kamKamba [kam]knKannada [kn]ks-ArabKashmiri (Arabic) [ks-Arab]ks-DevaKashmiri (Devanagari) [ks-Deva]ks\rKashmiri [ks]kkKazakh [kk]kk-KZKazakhstan [kk-KZ]ru-KZKazakhstan [ru-KZ]dav-KEKenya [dav-KE]ebu-KEKenya [ebu-KE]en-KE\rKenya [en-KE]guz-KEKenya [guz-KE]kam-KEKenya [kam-KE]ki-KE\rKenya [ki-KE]kln-KEKenya [kln-KE]luo-KEKenya [luo-KE]luy-KEKenya [luy-KE]mas-KEKenya [mas-KE]mer-KEKenya [mer-KE]om-KE\rKenya [om-KE]saq-KEKenya [saq-KE]so-KE\rKenya [so-KE]sw-KE\rKenya [sw-KE]teo-KEKenya [teo-KE]km\nKhmer [km]kiKikuyu [ki]rwKinyarwanda [rw]en-KIKiribati [en-KI]kok\rKonkani [kok]koKorean [ko]sq-XKKosovo [sq-XK]khqKoyra Chiini [khq]sesKoyraboro Senni [ses]kuKurdish [ku]ar-KWKuwait [ar-KW]nmgKwasio [nmg]kyKyrgyz [ky]ky-KGKyrgyzstan [ky-KG]ru-KGKyrgyzstan [ru-KG]lktLakota [lkt]lagLangi [lag]loLao [lo]lo-LALaos [lo-LA]es-419Latin America [es-419]lv-LVLatvia [lv-LV]lvLatvian [lv]ar-LBLebanon [ar-LB]en-LSLesotho [en-LS]en-LRLiberia [en-LR]ar-LY\rLibya [ar-LY]de-LILiechtenstein [de-LI]gsw-LILiechtenstein [gsw-LI]lnLingala [ln]lt-LTLithuania [lt-LT]ltLithuanian [lt]dsbLower Sorbian [dsb]luLuba-Katanga [lu]luo	Luo [luo]de-LULuxembourg [de-LU]fr-LULuxembourg [fr-LU]lb-LULuxembourg [lb-LU]pt-LULuxembourg [pt-LU]lbLuxembourgish [lb]luyLuyia [luy]en-MOMacao SAR China [en-MO]pt-MOMacao SAR China [pt-MO]mkMacedonian [mk]jmc\rMachame [jmc]en-MGMadagascar [en-MG]fr-MGMadagascar [fr-MG]mg-MGMadagascar [mg-MG]maiMaithili [mai]mghMakhuwa-Meetto [mgh]kde\rMakonde [kde]mg\rMalagasy [mg]en-MWMalawi [en-MW]ms\nMalay [ms]mlMalayalam [ml]en-MYMalaysia [en-MY]ms-MYMalaysia [ms-MY]ta-MYMalaysia [ta-MY]en-MVMaldives [en-MV]bm-MLMali [bm-ML]fr-MLMali [fr-ML]khq-ML\rMali [khq-ML]ses-ML\rMali [ses-ML]en-MT\rMalta [en-MT]mt-MT\rMalta [mt-MT]mtMaltese [mt]mni-BengManipuri (Bangla) [mni-Beng]mniManipuri [mni]gv	Manx [gv]mrMarathi [mr]en-MHMarshall Islands [en-MH]fr-MQMartinique [fr-MQ]masMasai [mas]ar-MRMauritania [ar-MR]fr-MRMauritania [fr-MR]en-MUMauritius [en-MU]fr-MUMauritius [fr-MU]mfe-MUMauritius [mfe-MU]fr-YTMayotte [fr-YT]mznMazanderani [mzn]mer\nMeru [mer]mgoMetaʼ [mgo]es-MXMexico [es-MX]en-FMMicronesia [en-FM]ro-MDMoldova [ro-MD]ru-MDMoldova [ru-MD]fr-MCMonaco [fr-MC]mn-MNMongolia [mn-MN]mnMongolian [mn]en-MSMontserrat [en-MS]mfeMorisyen [mfe]ar-MAMorocco [ar-MA]fr-MAMorocco [fr-MA]tzm-MAMorocco [tzm-MA]zgh-MAMorocco [zgh-MA]mgh-MZMozambique [mgh-MZ]pt-MZMozambique [pt-MZ]seh-MZMozambique [seh-MZ]mua\rMundang [mua]my-MMMyanmar (Burma) [my-MM]miMāori [mi]naq\nNama [naq]af-NANamibia [af-NA]en-NANamibia [en-NA]naq-NANamibia [naq-NA]en-NR\rNauru [en-NR]ne-NP\rNepal [ne-NP]neNepali [ne]en-NLNetherlands [en-NL]fy-NLNetherlands [fy-NL]nl-NLNetherlands [nl-NL]fr-NCNew Caledonia [fr-NC]en-NZNew Zealand [en-NZ]mi-NZNew Zealand [mi-NZ]nnhNgiemboon [nnh]jgoNgomba [jgo]yrlNheengatu [yrl]es-NINicaragua [es-NI]dje-NENiger [dje-NE]fr-NE\rNiger [fr-NE]ha-NE\rNiger [ha-NE]twq-NENiger [twq-NE]en-NGNigeria [en-NG]ha-NGNigeria [ha-NG]ig-NGNigeria [ig-NG]pcm-NGNigeria [pcm-NG]yo-NGNigeria [yo-NG]pcmNigerian Pidgin [pcm]en-NUNiue [en-NU]en-NFNorfolk Island [en-NF]ko-KPNorth Korea [ko-KP]mk-MKNorth Macedonia [mk-MK]sq-MKNorth Macedonia [sq-MK]ndNorth Ndebele [nd]lrcNorthern Luri [lrc]en-MP Northern Mariana Islands [en-MP]seNorthern Sami [se]nb-NONorway [nb-NO]nn-NONorway [nn-NO]se-NONorway [se-NO]nbNorwegian Bokmål [nb]nnNorwegian Nynorsk [nn]noNorwegian [no]nus\nNuer [nus]nynNyankole [nyn]or	Odia [or]ar-OMOman [ar-OM]om\nOromo [om]osOssetic [os]en-PKPakistan [en-PK]ps-PKPakistan [ps-PK]ur-PKPakistan [ur-PK]en-PW\rPalau [en-PW]ar-PSPalestinian Territories [ar-PS]es-PAPanama [es-PA]en-PGPapua New Guinea [en-PG]es-PYParaguay [es-PY]psPashto [ps]faPersian [fa]es-PEPeru [es-PE]qu-PEPeru [qu-PE]ceb-PHPhilippines [ceb-PH]en-PHPhilippines [en-PH]es-PHPhilippines [es-PH]fil-PHPhilippines [fil-PH]en-PNPitcairn Islands [en-PN]pl-PLPoland [pl-PL]plPolish [pl]pt-PTPortugal [pt-PT]ptPortuguese [pt]en-PRPuerto Rico [en-PR]es-PRPuerto Rico [es-PR]pa-Arab\ZPunjabi (Arabic) [pa-Arab]pa-GuruPunjabi (Gurmukhi) [pa-Guru]paPunjabi [pa]ar-QA\rQatar [ar-QA]quQuechua [qu]rajRajasthani [raj]ro-RORomania [ro-RO]ro\rRomanian [ro]rmRomansh [rm]rofRombo [rof]rn\nRundi [rn]ce-RURussia [ce-RU]cv-RURussia [cv-RU]os-RURussia [os-RU]ru-RURussia [ru-RU]sah-RURussia [sah-RU]tt-RURussia [tt-RU]ruRussian [ru]rwk	Rwa [rwk]en-RWRwanda [en-RW]fr-RWRwanda [fr-RW]rw-RWRwanda [rw-RW]fr-RERéunion [fr-RE]saq\rSamburu [saq]en-WS\rSamoa [en-WS]it-SMSan Marino [it-SM]sg\nSango [sg]sbpSangu [sbp]sa\rSanskrit [sa]sat-OlckSantali (Ol Chiki) [sat-Olck]sat\rSantali [sat]scSardinian [sc]ar-SASaudi Arabia [ar-SA]gdScottish Gaelic [gd]seh\nSena [seh]dyo-SNSenegal [dyo-SN]fr-SNSenegal [fr-SN]wo-SNSenegal [wo-SN]sr-CyrlSerbian (Cyrillic) [sr-Cyrl]sr-LatnSerbian (Latin) [sr-Latn]srSerbian [sr]en-SCSeychelles [en-SC]fr-SCSeychelles [fr-SC]ksbShambala [ksb]sn\nShona [sn]iiSichuan Yi [ii]en-SLSierra Leone [en-SL]sd-ArabSindhi (Arabic) [sd-Arab]sd-DevaSindhi (Devanagari) [sd-Deva]sdSindhi [sd]en-SGSingapore [en-SG]ms-SGSingapore [ms-SG]ta-SGSingapore [ta-SG]siSinhala [si]en-SXSint Maarten [en-SX]nl-SXSint Maarten [nl-SX]skSlovak [sk]sk-SKSlovakia [sk-SK]en-SISlovenia [en-SI]sl-SISlovenia [sl-SI]slSlovenian [sl]xog\nSoga [xog]en-SBSolomon Islands [en-SB]soSomali [so]ar-SOSomalia [ar-SO]so-SOSomalia [so-SO]af-ZASouth Africa [af-ZA]en-ZASouth Africa [en-ZA]xh-ZASouth Africa [xh-ZA]zu-ZASouth Africa [zu-ZA]ko-KRSouth Korea [ko-KR]ar-SSSouth Sudan [ar-SS]en-SSSouth Sudan [en-SS]nus-SSSouth Sudan [nus-SS]ast-ESSpain [ast-ES]ca-ES\rSpain [ca-ES]es-ES\rSpain [es-ES]eu-ES\rSpain [eu-ES]gl-ES\rSpain [gl-ES]esSpanish [es]si-LKSri Lanka [si-LK]ta-LKSri Lanka [ta-LK]fr-BLSt. Barthélemy [fr-BL]en-SHSt. Helena [en-SH]en-KNSt. Kitts & Nevis [en-KN]en-LCSt. Lucia [en-LC]fr-MFSt. Martin [fr-MF]fr-PMSt. Pierre & Miquelon [fr-PM]en-VC St. Vincent & Grenadines [en-VC]zgh!Standard Moroccan Tamazight [zgh]ar-SD\rSudan [ar-SD]en-SD\rSudan [en-SD]su-LatnSundanese (Latin) [su-Latn]suSundanese [su]nl-SRSuriname [nl-SR]nb-SJSvalbard & Jan Mayen [nb-SJ]swSwahili [sw]en-SESweden [en-SE]se-SESweden [se-SE]sv-SESweden [sv-SE]svSwedish [sv]gswSwiss German [gsw]de-CHSwitzerland [de-CH]en-CHSwitzerland [en-CH]fr-CHSwitzerland [fr-CH]gsw-CHSwitzerland [gsw-CH]it-CHSwitzerland [it-CH]pt-CHSwitzerland [pt-CH]rm-CHSwitzerland [rm-CH]wae-CHSwitzerland [wae-CH]ar-SY\rSyria [ar-SY]fr-SY\rSyria [fr-SY]pt-STSão Tomé & Príncipe [pt-ST]shi-LatnTachelhit (Latin) [shi-Latn]shi-TfngTachelhit (Tifinagh) [shi-Tfng]shiTachelhit [shi]davTaita [dav]tg\nTajik [tg]tg-TJTajikistan [tg-TJ]ta\nTamil [ta]asa-TZTanzania [asa-TZ]bez-TZTanzania [bez-TZ]en-TZTanzania [en-TZ]jmc-TZTanzania [jmc-TZ]kde-TZTanzania [kde-TZ]ksb-TZTanzania [ksb-TZ]lag-TZTanzania [lag-TZ]mas-TZTanzania [mas-TZ]rof-TZTanzania [rof-TZ]rwk-TZTanzania [rwk-TZ]sbp-TZTanzania [sbp-TZ]sw-TZTanzania [sw-TZ]vun-TZTanzania [vun-TZ]twq\rTasawaq [twq]tt\nTatar [tt]teTelugu [te]teo\nTeso [teo]th	Thai [th]th-THThailand [th-TH]boTibetan [bo]ti\rTigrinya [ti]pt-TLTimor-Leste [pt-TL]ee-TGTogo [ee-TG]fr-TGTogo [fr-TG]en-TKTokelau [en-TK]en-TO\rTonga [en-TO]to-TO\rTonga [to-TO]toTongan [to]en-TTTrinidad & Tobago [en-TT]ar-TNTunisia [ar-TN]fr-TNTunisia [fr-TN]ku-TRTurkey [ku-TR]tr-TRTurkey [tr-TR]trTurkish [tr]tkTurkmen [tk]tk-TMTurkmenistan [tk-TM]en-TCTurks & Caicos Islands [en-TC]en-TVTuvalu [en-TV]en-UMU.S. Outlying Islands [en-UM]en-VIU.S. Virgin Islands [en-VI]cgg-UGUganda [cgg-UG]en-UGUganda [en-UG]lg-UGUganda [lg-UG]nyn-UGUganda [nyn-UG]sw-UGUganda [sw-UG]teo-UGUganda [teo-UG]xog-UGUganda [xog-UG]ru-UAUkraine [ru-UA]uk-UAUkraine [uk-UA]ukUkrainian [uk]ar-AEUnited Arab Emirates [ar-AE]en-AEUnited Arab Emirates [en-AE]cy-GBUnited Kingdom [cy-GB]en-GBUnited Kingdom [en-GB]ga-GBUnited Kingdom [ga-GB]gd-GBUnited Kingdom [gd-GB]kw-GBUnited Kingdom [kw-GB]chr-USUnited States [chr-US]en-USUnited States [en-US]es-USUnited States [es-US]haw-USUnited States [haw-US]lkt-USUnited States [lkt-US]hsbUpper Sorbian [hsb]ur	Urdu [ur]es-UYUruguay [es-UY]ugUyghur [ug]uz-ArabUzbek (Arabic) [uz-Arab]uz-Cyrl\ZUzbek (Cyrillic) [uz-Cyrl]uz-LatnUzbek (Latin) [uz-Latn]uz\nUzbek [uz]vai-LatnVai (Latin) [vai-Latn]vai-VaiiVai (Vai) [vai-Vaii]vai	Vai [vai]en-VUVanuatu [en-VU]fr-VUVanuatu [fr-VU]it-VAVatican City [it-VA]es-VEVenezuela [es-VE]yrl-VEVenezuela [yrl-VE]vi-VNVietnam [vi-VN]viVietnamese [vi]vunVunjo [vun]fr-WFWallis & Futuna [fr-WF]waeWalser [wae]cy\nWelsh [cy]fyWestern Frisian [fy]ar-EHWestern Sahara [ar-EH]wo\nWolof [wo]xh\nXhosa [xh]sahYakut [sah]yav\rYangben [yav]ar-YE\rYemen [ar-YE]yiYiddish [yi]yoYoruba [yo]bem-ZMZambia [bem-ZM]en-ZMZambia [en-ZM]djeZarma [dje]en-ZWZimbabwe [en-ZW]nd-ZWZimbabwe [nd-ZW]sn-ZWZimbabwe [sn-ZW]zu	Zulu [zu]ar-001world [ar-001]en-001world [en-001]eo-001world [eo-001]ia-001world [ia-001]yi-001world [yi-001]sv-AXÅland Islands [sv-AX]system\�\\g�\�',31536000,1760513286),
('system_supported_locales_en','\0\0\0�����%af	Afrikaansaf_NAAfrikaans (Namibia)af_ZAAfrikaans (South Africa)agqAghemagq_CMAghem (Cameroon)akAkanak_GHAkan (Ghana)sqAlbaniansq_ALAlbanian (Albania)sq_XKAlbanian (Kosovo)sq_MK\ZAlbanian (North Macedonia)amAmharicam_ETAmharic (Ethiopia)arArabicar_DZArabic (Algeria)ar_BHArabic (Bahrain)ar_TD\rArabic (Chad)ar_KMArabic (Comoros)ar_DJArabic (Djibouti)ar_EGArabic (Egypt)ar_ERArabic (Eritrea)ar_IQ\rArabic (Iraq)ar_ILArabic (Israel)ar_JOArabic (Jordan)ar_KWArabic (Kuwait)ar_LBArabic (Lebanon)ar_LYArabic (Libya)ar_MRArabic (Mauritania)ar_MAArabic (Morocco)ar_OM\rArabic (Oman)ar_PS Arabic (Palestinian Territories)ar_QAArabic (Qatar)ar_SAArabic (Saudi Arabia)ar_SOArabic (Somalia)ar_SSArabic (South Sudan)ar_SDArabic (Sudan)ar_SYArabic (Syria)ar_TNArabic (Tunisia)ar_AEArabic (United Arab Emirates)ar_EHArabic (Western Sahara)ar_YEArabic (Yemen)ar_001Arabic (world)hyArmenianhy_AMArmenian (Armenia)asAssameseas_INAssamese (India)astAsturianast_ESAsturian (Spain)asaAsuasa_TZAsu (Tanzania)azAzerbaijaniaz_Cyrlgaz_Latng\naz_Cyrl_AZAzerbaijani (Azerbaijan)\naz_Latn_AZkksfBafiaksf_CMBafia (Cameroon)bmBambarabm_MLBambara (Mali)bnBanglabn_BDBangla (Bangladesh)bn_INBangla (India)basBasaabas_CMBasaa (Cameroon)euBasqueeu_ESBasque (Spain)be\nBelarusianbe_BYBelarusian (Belarus)bemBembabem_ZMBemba (Zambia)bezBenabez_TZBena (Tanzania)bhoBhojpuribho_INBhojpuri (India)brxBodobrx_INBodo (India)bsBosnianbs_Cyrl�bs_Latn�\nbs_Cyrl_BABosnian (Bosnia & Herzegovina)\nbs_Latn_BA�brBretonbr_FRBreton (France)bg	Bulgarianbg_BGBulgarian (Bulgaria)myBurmesemy_MMBurmese (Myanmar (Burma))yue	Cantoneseyue_Hans�yue_Hant�yue_Hans_CNCantonese (China)yue_Hant_HKCantonese (Hong Kong SAR China)caCatalanca_ADCatalan (Andorra)ca_FRCatalan (France)ca_ITCatalan (Italy)ca_ESCatalan (Spain)cebCebuanoceb_PHCebuano (Philippines)tzmCentral Atlas Tamazighttzm_MA!Central Atlas Tamazight (Morocco)ckbCentral Kurdishckb_IRCentral Kurdish (Iran)ckb_IQCentral Kurdish (Iraq)ccpChakmaccp_BDChakma (Bangladesh)ccp_INChakma (India)ceChechence_RUChechen (Russia)chrCherokeechr_USCherokee (United States)cggChigacgg_UGChiga (Uganda)zhChinesezh_Hans\�zh_Hant\�\nzh_Hans_CNChinese (China)\nzh_Hans_HKChinese (Hong Kong SAR China)\nzh_Hant_HK\�\nzh_Hans_MOChinese (Macao SAR China)\nzh_Hant_MO\�\nzh_Hans_SGChinese (Singapore)\nzh_Hant_TWChinese (Taiwan)cvChuvashcv_RUChuvash (Russia)ksh	Colognianksh_DEColognian (Germany)kwCornishkw_GBCornish (United Kingdom)hrCroatianhr_BACroatian (Bosnia & Herzegovina)hr_HRCroatian (Croatia)csCzechcs_CZCzech (Czechia)daDanishda_DKDanish (Denmark)da_GLDanish (Greenland)doiDogridoi_IN\rDogri (India)duaDualadua_CMDuala (Cameroon)nlDutchnl_AW\rDutch (Aruba)nl_BEDutch (Belgium)nl_BQDutch (Caribbean Netherlands)nl_CWDutch (Curaçao)nl_NLDutch (Netherlands)nl_SXDutch (Sint Maarten)nl_SRDutch (Suriname)dzDzongkhadz_BTDzongkha (Bhutan)ebuEmbuebu_KEEmbu (Kenya)enEnglishen_ASEnglish (American Samoa)en_AIEnglish (Anguilla)en_AGEnglish (Antigua & Barbuda)en_AUEnglish (Australia)en_ATEnglish (Austria)en_BSEnglish (Bahamas)en_BBEnglish (Barbados)en_BEEnglish (Belgium)en_BZEnglish (Belize)en_BMEnglish (Bermuda)en_BWEnglish (Botswana)en_IO(English (British Indian Ocean Territory)en_VG English (British Virgin Islands)en_BIEnglish (Burundi)en_CMEnglish (Cameroon)en_CAEnglish (Canada)en_KYEnglish (Cayman Islands)en_CX\ZEnglish (Christmas Island)en_CC!English (Cocos (Keeling) Islands)en_CKEnglish (Cook Islands)en_CYEnglish (Cyprus)en_DKEnglish (Denmark)en_DGEnglish (Diego Garcia)en_DMEnglish (Dominica)en_EREnglish (Eritrea)en_SZEnglish (Eswatini)en_150English (Europe)en_FK\ZEnglish (Falkland Islands)en_FJEnglish (Fiji)en_FIEnglish (Finland)en_GMEnglish (Gambia)en_DEEnglish (Germany)en_GHEnglish (Ghana)en_GIEnglish (Gibraltar)en_GDEnglish (Grenada)en_GUEnglish (Guam)en_GGEnglish (Guernsey)en_GYEnglish (Guyana)en_HKEnglish (Hong Kong SAR China)en_INEnglish (India)en_IEEnglish (Ireland)en_IMEnglish (Isle of Man)en_ILEnglish (Israel)en_JMEnglish (Jamaica)en_JEEnglish (Jersey)en_KEEnglish (Kenya)en_KIEnglish (Kiribati)en_LSEnglish (Lesotho)en_LREnglish (Liberia)en_MOEnglish (Macao SAR China)en_MGEnglish (Madagascar)en_MWEnglish (Malawi)en_MYEnglish (Malaysia)en_MVEnglish (Maldives)en_MTEnglish (Malta)en_MH\ZEnglish (Marshall Islands)en_MUEnglish (Mauritius)en_FMEnglish (Micronesia)en_MSEnglish (Montserrat)en_NAEnglish (Namibia)en_NREnglish (Nauru)en_NLEnglish (Netherlands)en_NZEnglish (New Zealand)en_NGEnglish (Nigeria)en_NUEnglish (Niue)en_NFEnglish (Norfolk Island)en_MP\"English (Northern Mariana Islands)en_PKEnglish (Pakistan)en_PWEnglish (Palau)en_PG\ZEnglish (Papua New Guinea)en_PHEnglish (Philippines)en_PN\ZEnglish (Pitcairn Islands)en_PREnglish (Puerto Rico)en_RWEnglish (Rwanda)en_WSEnglish (Samoa)en_SCEnglish (Seychelles)en_SLEnglish (Sierra Leone)en_SGEnglish (Singapore)en_SXEnglish (Sint Maarten)en_SIEnglish (Slovenia)en_SBEnglish (Solomon Islands)en_ZAEnglish (South Africa)en_SSEnglish (South Sudan)en_SHEnglish (St. Helena)en_KNEnglish (St. Kitts & Nevis)en_LCEnglish (St. Lucia)en_VC\"English (St. Vincent & Grenadines)en_SDEnglish (Sudan)en_SEEnglish (Sweden)en_CHEnglish (Switzerland)en_TZEnglish (Tanzania)en_TKEnglish (Tokelau)en_TOEnglish (Tonga)en_TTEnglish (Trinidad & Tobago)en_TC English (Turks & Caicos Islands)en_TVEnglish (Tuvalu)en_UMEnglish (U.S. Outlying Islands)en_VIEnglish (U.S. Virgin Islands)en_UGEnglish (Uganda)en_AEEnglish (United Arab Emirates)en_GBEnglish (United Kingdom)en_USEnglish (United States)en_US_POSIX\�en_VUEnglish (Vanuatu)en_ZMEnglish (Zambia)en_ZWEnglish (Zimbabwe)en_001English (world)eo	Esperantoeo_001Esperanto (world)etEstonianet_EEEstonian (Estonia)eeEweee_GHEwe (Ghana)ee_TG\nEwe (Togo)ewoEwondoewo_CMEwondo (Cameroon)foFaroesefo_DKFaroese (Denmark)fo_FOFaroese (Faroe Islands)filFilipinofil_PHFilipino (Philippines)fiFinnishfi_FIFinnish (Finland)frFrenchfr_DZFrench (Algeria)fr_BEFrench (Belgium)fr_BJFrench (Benin)fr_BFFrench (Burkina Faso)fr_BIFrench (Burundi)fr_CMFrench (Cameroon)fr_CAFrench (Canada)fr_CF!French (Central African Republic)fr_TD\rFrench (Chad)fr_KMFrench (Comoros)fr_CGFrench (Congo - Brazzaville)fr_CDFrench (Congo - Kinshasa)fr_CIFrench (Côte d’Ivoire)fr_DJFrench (Djibouti)fr_GQ\ZFrench (Equatorial Guinea)fr_FRFrench (France)fr_GFFrench (French Guiana)fr_PFFrench (French Polynesia)fr_GAFrench (Gabon)fr_GPFrench (Guadeloupe)fr_GNFrench (Guinea)fr_HTFrench (Haiti)fr_LUFrench (Luxembourg)fr_MGFrench (Madagascar)fr_ML\rFrench (Mali)fr_MQFrench (Martinique)fr_MRFrench (Mauritania)fr_MUFrench (Mauritius)fr_YTFrench (Mayotte)fr_MCFrench (Monaco)fr_MAFrench (Morocco)fr_NCFrench (New Caledonia)fr_NEFrench (Niger)fr_RWFrench (Rwanda)fr_REFrench (Réunion)fr_SNFrench (Senegal)fr_SCFrench (Seychelles)fr_BLFrench (St. Barthélemy)fr_MFFrench (St. Martin)fr_PMFrench (St. Pierre & Miquelon)fr_CHFrench (Switzerland)fr_SYFrench (Syria)fr_TG\rFrench (Togo)fr_TNFrench (Tunisia)fr_VUFrench (Vanuatu)fr_WFFrench (Wallis & Futuna)furFriulianfur_ITFriulian (Italy)ffFulaff_Adlm�ff_Latn�\nff_Adlm_BFFula (Burkina Faso)\nff_Latn_BF�\nff_Adlm_CMFula (Cameroon)\nff_Latn_CM�\nff_Adlm_GM\rFula (Gambia)\nff_Latn_GM�\nff_Adlm_GHFula (Ghana)\nff_Latn_GH�\nff_Adlm_GN\rFula (Guinea)\nff_Latn_GN�\nff_Adlm_GWFula (Guinea-Bissau)\nff_Latn_GW�\nff_Adlm_LRFula (Liberia)\nff_Latn_LR�\nff_Adlm_MRFula (Mauritania)\nff_Latn_MR�\nff_Adlm_NEFula (Niger)\nff_Latn_NE�\nff_Adlm_NGFula (Nigeria)\nff_Latn_NG�\nff_Adlm_SNFula (Senegal)\nff_Latn_SN�\nff_Adlm_SLFula (Sierra Leone)\nff_Latn_SL�glGaliciangl_ESGalician (Spain)lgGandalg_UGGanda (Uganda)kaGeorgianka_GEGeorgian (Georgia)deGermande_ATGerman (Austria)de_BEGerman (Belgium)de_DEGerman (Germany)de_ITGerman (Italy)de_LIGerman (Liechtenstein)de_LUGerman (Luxembourg)de_CHGerman (Switzerland)elGreekel_CYGreek (Cyprus)el_GRGreek (Greece)guGujaratigu_INGujarati (India)guzGusiiguz_KE\rGusii (Kenya)bgcHaryanvibgc_INHaryanvi (India)haHausaha_GH\rHausa (Ghana)ha_NE\rHausa (Niger)ha_NGHausa (Nigeria)hawHawaiianhaw_USHawaiian (United States)heHebrewhe_ILHebrew (Israel)hiHindihi_Latn\�hi_IN\rHindi (India)\nhi_Latn_IN\�hu	Hungarianhu_HUHungarian (Hungary)is	Icelandicis_ISIcelandic (Iceland)igIgboig_NGIgbo (Nigeria)smn\nInari Samismn_FIInari Sami (Finland)id\nIndonesianid_IDIndonesian (Indonesia)iaInterlinguaia_001Interlingua (world)gaIrishga_IEIrish (Ireland)ga_GBIrish (United Kingdom)itItalianit_ITItalian (Italy)it_SMItalian (San Marino)it_CHItalian (Switzerland)it_VAItalian (Vatican City)jaJapaneseja_JPJapanese (Japan)jvJavanesejv_IDJavanese (Indonesia)dyo\nJola-Fonyidyo_SNJola-Fonyi (Senegal)keaKabuverdianukea_CVKabuverdianu (Cape Verde)kabKabylekab_DZKabyle (Algeria)kgpKaingangkgp_BRKaingang (Brazil)kkjKakokkj_CMKako (Cameroon)klKalaallisutkl_GLKalaallisut (Greenland)klnKalenjinkln_KEKalenjin (Kenya)kamKambakam_KE\rKamba (Kenya)knKannadakn_INKannada (India)ksKashmiriks_ArabBks_DevaB\nks_Arab_INKashmiri (India)\nks_Deva_INFkkKazakhkk_KZKazakh (Kazakhstan)kmKhmerkm_KHKhmer (Cambodia)kiKikuyuki_KEKikuyu (Kenya)rwKinyarwandarw_RWKinyarwanda (Rwanda)kokKonkanikok_INKonkani (India)koKoreanko_KPKorean (North Korea)ko_KRKorean (South Korea)khqKoyra Chiinikhq_MLKoyra Chiini (Mali)sesKoyraboro Sennises_MLKoyraboro Senni (Mali)kuKurdishku_TRKurdish (Turkey)nmgKwasionmg_CMKwasio (Cameroon)kyKyrgyzky_KGKyrgyz (Kyrgyzstan)lktLakotalkt_USLakota (United States)lagLangilag_TZLangi (Tanzania)loLaolo_LA\nLao (Laos)lvLatvianlv_LVLatvian (Latvia)lnLingalaln_AOLingala (Angola)ln_CF\"Lingala (Central African Republic)ln_CGLingala (Congo - Brazzaville)ln_CD\ZLingala (Congo - Kinshasa)lt\nLithuanianlt_LTLithuanian (Lithuania)dsb\rLower Sorbiandsb_DELower Sorbian (Germany)luLuba-Katangalu_CDLuba-Katanga (Congo - Kinshasa)luoLuoluo_KELuo (Kenya)lb\rLuxembourgishlb_LU\ZLuxembourgish (Luxembourg)luyLuyialuy_KE\rLuyia (Kenya)mk\nMacedonianmk_MKMacedonian (North Macedonia)jmcMachamejmc_TZMachame (Tanzania)maiMaithilimai_INMaithili (India)mghMakhuwa-Meettomgh_MZMakhuwa-Meetto (Mozambique)kdeMakondekde_TZMakonde (Tanzania)mgMalagasymg_MGMalagasy (Madagascar)msMalayms_BNMalay (Brunei)ms_IDMalay (Indonesia)ms_MYMalay (Malaysia)ms_SGMalay (Singapore)ml	Malayalamml_INMalayalam (India)mtMaltesemt_MTMaltese (Malta)mniManipurimni_Beng\�mni_Beng_INManipuri (India)gvManxgv_IMManx (Isle of Man)mrMarathimr_INMarathi (India)masMasaimas_KE\rMasai (Kenya)mas_TZMasai (Tanzania)mznMazanderanimzn_IRMazanderani (Iran)merMerumer_KEMeru (Kenya)mgoMetaʼmgo_CMMetaʼ (Cameroon)mn	Mongolianmn_MNMongolian (Mongolia)mfeMorisyenmfe_MUMorisyen (Mauritius)muaMundangmua_CMMundang (Cameroon)miMāorimi_NZMāori (New Zealand)naqNamanaq_NANama (Namibia)neNepaline_INNepali (India)ne_NPNepali (Nepal)nnh	Ngiemboonnnh_CMNgiemboon (Cameroon)jgoNgombajgo_CMNgomba (Cameroon)yrl	Nheengatuyrl_BRNheengatu (Brazil)yrl_CONheengatu (Colombia)yrl_VENheengatu (Venezuela)pcmNigerian Pidginpcm_NGNigerian Pidgin (Nigeria)nd\rNorth Ndebelend_ZWNorth Ndebele (Zimbabwe)lrc\rNorthern Lurilrc_IRNorthern Luri (Iran)lrc_IQNorthern Luri (Iraq)se\rNorthern Samise_FINorthern Sami (Finland)se_NONorthern Sami (Norway)se_SENorthern Sami (Sweden)no	NorwegiannbNorwegian Bokmålnb_NO\ZNorwegian Bokmål (Norway)nb_SJ(Norwegian Bokmål (Svalbard & Jan Mayen)nnNorwegian Nynorsknn_NO\ZNorwegian Nynorsk (Norway)nusNuernus_SSNuer (South Sudan)nynNyankolenyn_UGNyankole (Uganda)orOdiaor_INOdia (India)omOromoom_ETOromo (Ethiopia)om_KE\rOromo (Kenya)osOsseticos_GEOssetic (Georgia)os_RUOssetic (Russia)psPashtops_AFPashto (Afghanistan)ps_PKPashto (Pakistan)faPersianfa_AFPersian (Afghanistan)fa_IRPersian (Iran)plPolishpl_PLPolish (Poland)pt\nPortuguesept_AOPortuguese (Angola)pt_BRPortuguese (Brazil)pt_CVPortuguese (Cape Verde)pt_GQPortuguese (Equatorial Guinea)pt_GW\ZPortuguese (Guinea-Bissau)pt_LUPortuguese (Luxembourg)pt_MOPortuguese (Macao SAR China)pt_MZPortuguese (Mozambique)pt_PTPortuguese (Portugal)pt_CHPortuguese (Switzerland)pt_ST#Portuguese (São Tomé & Príncipe)pt_TLPortuguese (Timor-Leste)paPunjabipa_Arab�pa_Guru�\npa_Guru_INPunjabi (India)\npa_Arab_PKPunjabi (Pakistan)quQuechuaqu_BOQuechua (Bolivia)qu_ECQuechua (Ecuador)qu_PEQuechua (Peru)raj\nRajasthaniraj_INRajasthani (India)roRomanianro_MDRomanian (Moldova)ro_RORomanian (Romania)rmRomanshrm_CHRomansh (Switzerland)rofRomborof_TZRombo (Tanzania)rnRundirn_BIRundi (Burundi)ruRussianru_BYRussian (Belarus)ru_KZRussian (Kazakhstan)ru_KGRussian (Kyrgyzstan)ru_MDRussian (Moldova)ru_RURussian (Russia)ru_UARussian (Ukraine)rwkRwarwk_TZRwa (Tanzania)saqSamburusaq_KESamburu (Kenya)sgSangosg_CF Sango (Central African Republic)sbpSangusbp_TZSangu (Tanzania)saSanskritsa_INSanskrit (India)satSantalisat_Olck\�sat_Olck_INSantali (India)sc	Sardiniansc_ITSardinian (Italy)gdScottish Gaelicgd_GB Scottish Gaelic (United Kingdom)sehSenaseh_MZSena (Mozambique)srSerbiansr_Cyrl\�sr_Latn\�\nsr_Cyrl_BASerbian (Bosnia & Herzegovina)\nsr_Latn_BA\�\nsr_Cyrl_XKSerbian (Kosovo)\nsr_Latn_XK\�\nsr_Cyrl_MESerbian (Montenegro)\nsr_Latn_ME\�\nsr_Cyrl_RSSerbian (Serbia)\nsr_Latn_RS\�ksbShambalaksb_TZShambala (Tanzania)snShonasn_ZWShona (Zimbabwe)ii\nSichuan Yiii_CNSichuan Yi (China)sdSindhisd_Arab\�sd_Deva\�\nsd_Deva_INSindhi (India)\nsd_Arab_PKSindhi (Pakistan)siSinhalasi_LKSinhala (Sri Lanka)skSlovaksk_SKSlovak (Slovakia)sl	Sloveniansl_SISlovenian (Slovenia)xogSogaxog_UG\rSoga (Uganda)soSomaliso_DJSomali (Djibouti)so_ETSomali (Ethiopia)so_KESomali (Kenya)so_SOSomali (Somalia)esSpanishes_ARSpanish (Argentina)es_BZSpanish (Belize)es_BOSpanish (Bolivia)es_BRSpanish (Brazil)es_ICSpanish (Canary Islands)es_EASpanish (Ceuta & Melilla)es_CLSpanish (Chile)es_COSpanish (Colombia)es_CRSpanish (Costa Rica)es_CUSpanish (Cuba)es_DOSpanish (Dominican Republic)es_ECSpanish (Ecuador)es_SVSpanish (El Salvador)es_GQSpanish (Equatorial Guinea)es_GTSpanish (Guatemala)es_HNSpanish (Honduras)es_419Spanish (Latin America)es_MXSpanish (Mexico)es_NISpanish (Nicaragua)es_PASpanish (Panama)es_PYSpanish (Paraguay)es_PESpanish (Peru)es_PHSpanish (Philippines)es_PRSpanish (Puerto Rico)es_ESSpanish (Spain)es_USSpanish (United States)es_UYSpanish (Uruguay)es_VESpanish (Venezuela)zghStandard Moroccan Tamazightzgh_MA%Standard Moroccan Tamazight (Morocco)su	Sundanesesu_LatnU\nsu_Latn_IDSundanese (Indonesia)swSwahilisw_CD\ZSwahili (Congo - Kinshasa)sw_KESwahili (Kenya)sw_TZSwahili (Tanzania)sw_UGSwahili (Uganda)svSwedishsv_FISwedish (Finland)sv_SESwedish (Sweden)sv_AXSwedish (Åland Islands)gswSwiss Germangsw_FRSwiss German (France)gsw_LISwiss German (Liechtenstein)gsw_CH\ZSwiss German (Switzerland)shi	Tachelhitshi_Latntshi_Tfngtshi_Latn_MATachelhit (Morocco)shi_Tfng_MAxdavTaitadav_KE\rTaita (Kenya)tgTajiktg_TJTajik (Tajikistan)taTamilta_IN\rTamil (India)ta_MYTamil (Malaysia)ta_SGTamil (Singapore)ta_LKTamil (Sri Lanka)twqTasawaqtwq_NETasawaq (Niger)ttTatartt_RUTatar (Russia)teTelugute_INTelugu (India)teoTesoteo_KETeso (Kenya)teo_UG\rTeso (Uganda)thThaith_THThai (Thailand)boTibetanbo_CNTibetan (China)bo_INTibetan (India)tiTigrinyati_ERTigrinya (Eritrea)ti_ETTigrinya (Ethiopia)toTonganto_TOTongan (Tonga)trTurkishtr_CYTurkish (Cyprus)tr_TRTurkish (Turkey)tkTurkmentk_TMTurkmen (Turkmenistan)uk	Ukrainianuk_UAUkrainian (Ukraine)hsb\rUpper Sorbianhsb_DEUpper Sorbian (Germany)urUrduur_INUrdu (India)ur_PKUrdu (Pakistan)ugUyghurug_CNUyghur (China)uzUzbekuz_Arab\�uz_Cyrl\�uz_Latn\�\nuz_Arab_AFUzbek (Afghanistan)\nuz_Cyrl_UZUzbek (Uzbekistan)\nuz_Latn_UZ\�vaiVaivai_Latn\�vai_Vaii\�vai_Latn_LR\rVai (Liberia)vai_Vaii_LR\�vi\nVietnamesevi_VNVietnamese (Vietnam)vunVunjovun_TZVunjo (Tanzania)waeWalserwae_CHWalser (Switzerland)cyWelshcy_GBWelsh (United Kingdom)fyWestern Frisianfy_NLWestern Frisian (Netherlands)woWolofwo_SNWolof (Senegal)xhXhosaxh_ZAXhosa (South Africa)sahYakutsah_RUYakut (Russia)yavYangbenyav_CMYangben (Cameroon)yiYiddishyi_001Yiddish (world)yoYorubayo_BJYoruba (Benin)yo_NGYoruba (Nigeria)djeZarmadje_NE\rZarma (Niger)zuZuluzu_ZAZulu (South Africa)system\�\\g�\�',31536000,1760513286),
('translation_data_2e364d315ad5ad984609e7f4beedf0f7','\0\0\0�����.Symfony\\Component\\Translation\\MessageCatalogue8\0Symfony\\Component\\Translation\\MessageCatalogue\0messagesadmin__pimcore_dummyonly_a_dummyApplicationEnglish\rFrench\rGerman\rJobJobCategory\rMain\rMain (Admin Mode)\rPimcore\'s logotype\rPosition	Positions\rbottom\rclear\rglobal\r\nignoreCase\rlogin\r	multiline\r)object_add_dialog_custom_text.JobCategory\r*object_add_dialog_custom_title.JobCategory\rsticky\runicode\radmin+intl-icu8\0Symfony\\Component\\Translation\\MessageCatalogue\0metadata\0A\0Symfony\\Component\\Translation\\MessageCatalogue\0catalogueMetadata9\0Symfony\\Component\\Translation\\MessageCatalogue\0resources6\0Symfony\\Component\\Translation\\MessageCatalogue\0localeenA\0Symfony\\Component\\Translation\\MessageCatalogue\0fallbackCatalogue\06\0Symfony\\Component\\Translation\\MessageCatalogue\0parent\0\ntranslator\�c�v1\�translator_website%	translate%',31536000,1760513285),
('translator_websitetags','\0\0\0\�c�v1\�',NULL,1760513285);
/*!40000 ALTER TABLE `cache_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classes`
--

DROP TABLE IF EXISTS `classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `classes` (
  `id` varchar(50) NOT NULL,
  `name` varchar(190) NOT NULL DEFAULT '',
  `definitionModificationDate` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classes`
--

LOCK TABLES `classes` WRITE;
/*!40000 ALTER TABLE `classes` DISABLE KEYS */;
INSERT INTO `classes` VALUES
('application','Application',1760513420),
('job_category','JobCategory',1760513329),
('position','Position',1760513721);
/*!40000 ALTER TABLE `classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classificationstore_collectionrelations`
--

DROP TABLE IF EXISTS `classificationstore_collectionrelations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `classificationstore_collectionrelations` (
  `colId` int(11) unsigned NOT NULL,
  `groupId` int(11) unsigned NOT NULL,
  `sorter` int(10) DEFAULT 0,
  PRIMARY KEY (`colId`,`groupId`),
  KEY `FK_classificationstore_collectionrelations_groups` (`groupId`),
  CONSTRAINT `FK_classificationstore_collectionrelations_groups` FOREIGN KEY (`groupId`) REFERENCES `classificationstore_groups` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classificationstore_collectionrelations`
--

LOCK TABLES `classificationstore_collectionrelations` WRITE;
/*!40000 ALTER TABLE `classificationstore_collectionrelations` DISABLE KEYS */;
/*!40000 ALTER TABLE `classificationstore_collectionrelations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classificationstore_collections`
--

DROP TABLE IF EXISTS `classificationstore_collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `classificationstore_collections` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `storeId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) DEFAULT NULL,
  `creationDate` int(11) unsigned DEFAULT 0,
  `modificationDate` int(11) unsigned DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `storeId` (`storeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classificationstore_collections`
--

LOCK TABLES `classificationstore_collections` WRITE;
/*!40000 ALTER TABLE `classificationstore_collections` DISABLE KEYS */;
/*!40000 ALTER TABLE `classificationstore_collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classificationstore_groups`
--

DROP TABLE IF EXISTS `classificationstore_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `classificationstore_groups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `storeId` int(11) DEFAULT NULL,
  `parentId` int(11) unsigned NOT NULL DEFAULT 0,
  `name` varchar(190) NOT NULL DEFAULT '',
  `description` varchar(255) DEFAULT NULL,
  `creationDate` int(11) unsigned DEFAULT 0,
  `modificationDate` int(11) unsigned DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `storeId` (`storeId`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classificationstore_groups`
--

LOCK TABLES `classificationstore_groups` WRITE;
/*!40000 ALTER TABLE `classificationstore_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `classificationstore_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classificationstore_keys`
--

DROP TABLE IF EXISTS `classificationstore_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `classificationstore_keys` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `storeId` int(11) DEFAULT NULL,
  `name` varchar(190) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` text DEFAULT NULL,
  `type` varchar(190) DEFAULT NULL,
  `creationDate` int(11) unsigned DEFAULT 0,
  `modificationDate` int(11) unsigned DEFAULT 0,
  `definition` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`definition`)),
  `enabled` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `enabled` (`enabled`),
  KEY `type` (`type`),
  KEY `storeId` (`storeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classificationstore_keys`
--

LOCK TABLES `classificationstore_keys` WRITE;
/*!40000 ALTER TABLE `classificationstore_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `classificationstore_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classificationstore_relations`
--

DROP TABLE IF EXISTS `classificationstore_relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `classificationstore_relations` (
  `groupId` int(11) unsigned NOT NULL,
  `keyId` int(11) unsigned NOT NULL,
  `sorter` int(11) DEFAULT NULL,
  `mandatory` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`groupId`,`keyId`),
  KEY `FK_classificationstore_relations_classificationstore_keys` (`keyId`),
  KEY `mandatory` (`mandatory`),
  CONSTRAINT `FK_classificationstore_relations_classificationstore_groups` FOREIGN KEY (`groupId`) REFERENCES `classificationstore_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_classificationstore_relations_classificationstore_keys` FOREIGN KEY (`keyId`) REFERENCES `classificationstore_keys` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classificationstore_relations`
--

LOCK TABLES `classificationstore_relations` WRITE;
/*!40000 ALTER TABLE `classificationstore_relations` DISABLE KEYS */;
/*!40000 ALTER TABLE `classificationstore_relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classificationstore_stores`
--

DROP TABLE IF EXISTS `classificationstore_stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `classificationstore_stores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(190) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classificationstore_stores`
--

LOCK TABLES `classificationstore_stores` WRITE;
/*!40000 ALTER TABLE `classificationstore_stores` DISABLE KEYS */;
/*!40000 ALTER TABLE `classificationstore_stores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dependencies`
--

DROP TABLE IF EXISTS `dependencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `dependencies` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sourcetype` enum('document','asset','object') NOT NULL DEFAULT 'document',
  `sourceid` int(11) unsigned NOT NULL DEFAULT 0,
  `targettype` enum('document','asset','object') NOT NULL DEFAULT 'document',
  `targetid` int(11) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `combi` (`sourcetype`,`sourceid`,`targettype`,`targetid`),
  KEY `targettype_targetid` (`targettype`,`targetid`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dependencies`
--

LOCK TABLES `dependencies` WRITE;
/*!40000 ALTER TABLE `dependencies` DISABLE KEYS */;
INSERT INTO `dependencies` VALUES
(1,'object',8,'object',6),
(2,'object',9,'object',6),
(3,'object',10,'object',6),
(4,'object',11,'object',12),
(5,'object',13,'object',5),
(6,'object',14,'object',6),
(7,'object',15,'object',16),
(8,'object',17,'object',6),
(9,'object',18,'object',6),
(10,'object',20,'object',19),
(11,'object',21,'object',8),
(12,'object',22,'object',13);
/*!40000 ALTER TABLE `dependencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents`
--

DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parentId` int(11) unsigned DEFAULT NULL,
  `type` enum('page','link','snippet','folder','hardlink','email') DEFAULT NULL,
  `key` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT '',
  `path` varchar(765) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `index` int(11) unsigned DEFAULT 0,
  `published` tinyint(1) unsigned DEFAULT 1,
  `creationDate` int(11) unsigned DEFAULT NULL,
  `modificationDate` int(11) unsigned DEFAULT NULL,
  `userOwner` int(11) unsigned DEFAULT NULL,
  `userModification` int(11) unsigned DEFAULT NULL,
  `versionCount` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fullpath` (`path`,`key`),
  KEY `parentId` (`parentId`),
  KEY `key` (`key`),
  KEY `published` (`published`),
  KEY `modificationDate` (`modificationDate`),
  KEY `versionCount` (`versionCount`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents`
--

LOCK TABLES `documents` WRITE;
/*!40000 ALTER TABLE `documents` DISABLE KEYS */;
INSERT INTO `documents` VALUES
(1,0,'page','','/',999999,1,1760512442,1760512442,1,1,0);
/*!40000 ALTER TABLE `documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_editables`
--

DROP TABLE IF EXISTS `documents_editables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents_editables` (
  `documentId` int(11) unsigned NOT NULL DEFAULT 0,
  `name` varchar(750) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL DEFAULT '',
  `type` varchar(50) DEFAULT NULL,
  `data` longtext DEFAULT NULL,
  PRIMARY KEY (`documentId`,`name`),
  CONSTRAINT `fk_documents_editables_documents` FOREIGN KEY (`documentId`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_editables`
--

LOCK TABLES `documents_editables` WRITE;
/*!40000 ALTER TABLE `documents_editables` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_editables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_email`
--

DROP TABLE IF EXISTS `documents_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents_email` (
  `id` int(11) unsigned NOT NULL DEFAULT 0,
  `controller` varchar(500) DEFAULT NULL,
  `template` varchar(255) DEFAULT NULL,
  `to` varchar(255) DEFAULT NULL,
  `from` varchar(255) DEFAULT NULL,
  `replyTo` varchar(255) DEFAULT NULL,
  `cc` varchar(255) DEFAULT NULL,
  `bcc` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `missingRequiredEditable` tinyint(1) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_documents_email_documents` FOREIGN KEY (`id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_email`
--

LOCK TABLES `documents_email` WRITE;
/*!40000 ALTER TABLE `documents_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_hardlink`
--

DROP TABLE IF EXISTS `documents_hardlink`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents_hardlink` (
  `id` int(11) unsigned NOT NULL DEFAULT 0,
  `sourceId` int(11) DEFAULT NULL,
  `propertiesFromSource` tinyint(1) DEFAULT NULL,
  `childrenFromSource` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sourceId` (`sourceId`),
  CONSTRAINT `fk_documents_hardlink_documents` FOREIGN KEY (`id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_hardlink`
--

LOCK TABLES `documents_hardlink` WRITE;
/*!40000 ALTER TABLE `documents_hardlink` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_hardlink` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_link`
--

DROP TABLE IF EXISTS `documents_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents_link` (
  `id` int(11) unsigned NOT NULL DEFAULT 0,
  `internalType` enum('document','asset','object') DEFAULT NULL,
  `internal` int(11) unsigned DEFAULT NULL,
  `direct` varchar(1000) DEFAULT NULL,
  `linktype` enum('direct','internal') DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_documents_link_documents` FOREIGN KEY (`id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_link`
--

LOCK TABLES `documents_link` WRITE;
/*!40000 ALTER TABLE `documents_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_page`
--

DROP TABLE IF EXISTS `documents_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents_page` (
  `id` int(11) unsigned NOT NULL DEFAULT 0,
  `controller` varchar(500) DEFAULT NULL,
  `template` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` varchar(383) DEFAULT NULL,
  `prettyUrl` varchar(255) DEFAULT NULL,
  `contentMainDocumentId` int(11) DEFAULT NULL,
  `targetGroupIds` varchar(255) NOT NULL DEFAULT '',
  `missingRequiredEditable` tinyint(1) unsigned DEFAULT NULL,
  `staticGeneratorEnabled` tinyint(1) unsigned DEFAULT NULL,
  `staticGeneratorLifetime` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `prettyUrl` (`prettyUrl`),
  CONSTRAINT `fk_documents_page_documents` FOREIGN KEY (`id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_page`
--

LOCK TABLES `documents_page` WRITE;
/*!40000 ALTER TABLE `documents_page` DISABLE KEYS */;
INSERT INTO `documents_page` VALUES
(1,'App\\Controller\\DefaultController::defaultAction','','','',NULL,NULL,'',NULL,NULL,NULL);
/*!40000 ALTER TABLE `documents_page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_snippet`
--

DROP TABLE IF EXISTS `documents_snippet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents_snippet` (
  `id` int(11) unsigned NOT NULL DEFAULT 0,
  `controller` varchar(500) DEFAULT NULL,
  `template` varchar(255) DEFAULT NULL,
  `contentMainDocumentId` int(11) DEFAULT NULL,
  `missingRequiredEditable` tinyint(1) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_documents_snippet_documents` FOREIGN KEY (`id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_snippet`
--

LOCK TABLES `documents_snippet` WRITE;
/*!40000 ALTER TABLE `documents_snippet` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_snippet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_translations`
--

DROP TABLE IF EXISTS `documents_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents_translations` (
  `id` int(11) unsigned NOT NULL DEFAULT 0,
  `sourceId` int(11) unsigned NOT NULL DEFAULT 0,
  `language` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`sourceId`,`language`),
  KEY `id` (`id`),
  KEY `language` (`language`),
  CONSTRAINT `fk_documents_translations_documents` FOREIGN KEY (`id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_translations`
--

LOCK TABLES `documents_translations` WRITE;
/*!40000 ALTER TABLE `documents_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edit_lock`
--

DROP TABLE IF EXISTS `edit_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `edit_lock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) unsigned NOT NULL DEFAULT 0,
  `ctype` enum('document','asset','object') DEFAULT NULL,
  `userId` int(11) unsigned NOT NULL DEFAULT 0,
  `sessionId` varchar(255) DEFAULT NULL,
  `date` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ctype` (`ctype`),
  KEY `cidtype` (`cid`,`ctype`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edit_lock`
--

LOCK TABLES `edit_lock` WRITE;
/*!40000 ALTER TABLE `edit_lock` DISABLE KEYS */;
INSERT INTO `edit_lock` VALUES
(25,14,'object',2,'rrn6rjaaem74o3o69c89ir0u1m',1760515077),
(26,10,'object',2,'rrn6rjaaem74o3o69c89ir0u1m',1760515087),
(27,9,'object',2,'rrn6rjaaem74o3o69c89ir0u1m',1760515100),
(28,13,'object',2,'rrn6rjaaem74o3o69c89ir0u1m',1760515121),
(29,20,'object',2,'rrn6rjaaem74o3o69c89ir0u1m',1760515132),
(30,11,'object',2,'rrn6rjaaem74o3o69c89ir0u1m',1760515142),
(31,18,'object',2,'rrn6rjaaem74o3o69c89ir0u1m',1760515155),
(32,15,'object',2,'rrn6rjaaem74o3o69c89ir0u1m',1760515165),
(33,21,'object',2,'rrn6rjaaem74o3o69c89ir0u1m',1760515344),
(34,22,'object',2,'rrn6rjaaem74o3o69c89ir0u1m',1760515397);
/*!40000 ALTER TABLE `edit_lock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `element_workflow_state`
--

DROP TABLE IF EXISTS `element_workflow_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `element_workflow_state` (
  `cid` int(10) NOT NULL DEFAULT 0,
  `ctype` enum('document','asset','object') NOT NULL,
  `place` text DEFAULT NULL,
  `workflow` varchar(100) NOT NULL,
  PRIMARY KEY (`cid`,`ctype`,`workflow`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `element_workflow_state`
--

LOCK TABLES `element_workflow_state` WRITE;
/*!40000 ALTER TABLE `element_workflow_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `element_workflow_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_blocklist`
--

DROP TABLE IF EXISTS `email_blocklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_blocklist` (
  `address` varchar(190) NOT NULL DEFAULT '',
  `creationDate` int(11) unsigned DEFAULT NULL,
  `modificationDate` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_blocklist`
--

LOCK TABLES `email_blocklist` WRITE;
/*!40000 ALTER TABLE `email_blocklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_blocklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_log`
--

DROP TABLE IF EXISTS `email_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `documentId` int(11) unsigned DEFAULT NULL,
  `requestUri` varchar(500) DEFAULT NULL,
  `params` text DEFAULT NULL,
  `from` varchar(500) DEFAULT NULL,
  `replyTo` varchar(255) DEFAULT NULL,
  `to` longtext DEFAULT NULL,
  `cc` longtext DEFAULT NULL,
  `bcc` longtext DEFAULT NULL,
  `sentDate` int(11) unsigned DEFAULT NULL,
  `subject` varchar(500) DEFAULT NULL,
  `error` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sentDate` (`sentDate`,`id`),
  KEY `document_id` (`documentId`),
  FULLTEXT KEY `fulltext` (`from`,`to`,`cc`,`bcc`,`subject`,`params`),
  CONSTRAINT `fk_email_log_documents` FOREIGN KEY (`documentId`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_log`
--

LOCK TABLES `email_log` WRITE;
/*!40000 ALTER TABLE `email_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gridconfig_favourites`
--

DROP TABLE IF EXISTS `gridconfig_favourites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `gridconfig_favourites` (
  `ownerId` int(11) NOT NULL,
  `classId` varchar(50) NOT NULL,
  `objectId` int(11) NOT NULL DEFAULT 0,
  `gridConfigId` int(11) NOT NULL,
  `searchType` varchar(50) NOT NULL DEFAULT '',
  `type` enum('asset','object') NOT NULL DEFAULT 'object',
  PRIMARY KEY (`ownerId`,`classId`,`searchType`,`objectId`),
  KEY `classId` (`classId`),
  KEY `searchType` (`searchType`),
  KEY `grid_config_id` (`gridConfigId`),
  CONSTRAINT `fk_gridconfig_favourites_gridconfigs` FOREIGN KEY (`gridConfigId`) REFERENCES `gridconfigs` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gridconfig_favourites`
--

LOCK TABLES `gridconfig_favourites` WRITE;
/*!40000 ALTER TABLE `gridconfig_favourites` DISABLE KEYS */;
INSERT INTO `gridconfig_favourites` VALUES
(2,'job_category',0,1,'folder','object'),
(2,'job_category',4,1,'folder','object'),
(2,'position',0,2,'folder','object'),
(2,'position',2,2,'folder','object');
/*!40000 ALTER TABLE `gridconfig_favourites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gridconfig_shares`
--

DROP TABLE IF EXISTS `gridconfig_shares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `gridconfig_shares` (
  `gridConfigId` int(11) NOT NULL,
  `sharedWithUserId` int(11) NOT NULL,
  PRIMARY KEY (`gridConfigId`,`sharedWithUserId`),
  KEY `sharedWithUserId` (`sharedWithUserId`),
  KEY `grid_config_id` (`gridConfigId`),
  CONSTRAINT `fk_gridconfig_shares_gridconfigs` FOREIGN KEY (`gridConfigId`) REFERENCES `gridconfigs` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gridconfig_shares`
--

LOCK TABLES `gridconfig_shares` WRITE;
/*!40000 ALTER TABLE `gridconfig_shares` DISABLE KEYS */;
/*!40000 ALTER TABLE `gridconfig_shares` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gridconfigs`
--

DROP TABLE IF EXISTS `gridconfigs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `gridconfigs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ownerId` int(11) DEFAULT NULL,
  `classId` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `searchType` varchar(50) DEFAULT NULL,
  `type` enum('asset','object') NOT NULL DEFAULT 'object',
  `config` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`config`)),
  `description` longtext DEFAULT NULL,
  `creationDate` int(11) DEFAULT NULL,
  `modificationDate` int(11) DEFAULT NULL,
  `shareGlobally` tinyint(1) DEFAULT NULL,
  `setAsFavourite` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ownerId` (`ownerId`),
  KEY `classId` (`classId`),
  KEY `searchType` (`searchType`),
  KEY `shareGlobally` (`shareGlobally`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gridconfigs`
--

LOCK TABLES `gridconfigs` WRITE;
/*!40000 ALTER TABLE `gridconfigs` DISABLE KEYS */;
INSERT INTO `gridconfigs` VALUES
(1,2,'job_category','Default','folder','object','{\"language\":\"en\",\"pageSize\":25,\"sortinfo\":false,\"classId\":\"job_category\",\"columns\":{\"id\":{\"name\":\"id\",\"position\":1,\"hidden\":false,\"width\":40,\"locked\":false,\"fieldConfig\":{\"key\":\"id\",\"label\":\"ID\",\"type\":\"system\"}},\"fullpath\":{\"name\":\"fullpath\",\"position\":2,\"hidden\":false,\"width\":44,\"locked\":false,\"fieldConfig\":{\"key\":\"fullpath\",\"label\":\"Full Path\",\"type\":\"system\"}},\"published\":{\"name\":\"published\",\"position\":3,\"hidden\":false,\"width\":40,\"locked\":false,\"fieldConfig\":{\"key\":\"published\",\"label\":\"Published\",\"type\":\"system\"}},\"creationDate\":{\"name\":\"creationDate\",\"position\":4,\"hidden\":false,\"width\":160,\"locked\":false,\"fieldConfig\":{\"key\":\"creationDate\",\"label\":\"Creation Date\",\"type\":\"system\"}},\"modificationDate\":{\"name\":\"modificationDate\",\"position\":5,\"hidden\":false,\"width\":160,\"locked\":false,\"fieldConfig\":{\"key\":\"modificationDate\",\"label\":\"Modification Date\",\"type\":\"system\"}},\"title\":{\"name\":\"title\",\"position\":6,\"hidden\":false,\"width\":43,\"locked\":false,\"fieldConfig\":{\"key\":\"title\",\"label\":\"Title\",\"type\":\"input\",\"layout\":{\"name\":\"title\",\"title\":\"Title\",\"tooltip\":\"\",\"mandatory\":true,\"noteditable\":false,\"index\":false,\"locked\":false,\"style\":\"\",\"permissions\":null,\"fieldtype\":\"input\",\"relationType\":false,\"invisible\":false,\"visibleGridView\":false,\"visibleSearch\":false,\"defaultValue\":null,\"columnLength\":190,\"regex\":\"\",\"regexFlags\":[],\"unique\":false,\"showCharCount\":false,\"width\":\"\",\"defaultValueGenerator\":\"\",\"datatype\":\"data\"}}},\"#68ef53b9ce781\":{\"name\":\"#68ef53b9ce781\",\"position\":7,\"hidden\":false,\"width\":68,\"locked\":false,\"fieldConfig\":{\"isOperator\":true,\"attributes\":{\"label\":\"Positions\",\"type\":\"operator\",\"class\":\"ElementCounter\",\"countEmpty\":true,\"children\":[{\"label\":\"Positions (positions)\",\"type\":\"value\",\"class\":\"DefaultValue\",\"attribute\":\"positions\",\"dataType\":\"reverseObjectRelation\",\"children\":[]}]},\"key\":\"#68ef53b9ce781\"},\"isOperator\":true}},\"onlyDirectChildren\":false,\"searchFilter\":\"\",\"filter\":[],\"pimcore_version\":\"v11.5.11\",\"pimcore_revision\":\"4a6b08e7633aeb0ecf0fc983412498b6d5e828d3\",\"context\":\"{}\"}','',1760514942,1760515001,1,1),
(2,2,'position','Default','folder','object','{\"language\":\"en\",\"pageSize\":25,\"sortinfo\":false,\"classId\":\"position\",\"columns\":{\"id\":{\"name\":\"id\",\"position\":1,\"hidden\":false,\"width\":40,\"locked\":false,\"fieldConfig\":{\"key\":\"id\",\"label\":\"ID\",\"type\":\"system\"}},\"fullpath\":{\"name\":\"fullpath\",\"position\":2,\"hidden\":false,\"width\":44,\"locked\":false,\"fieldConfig\":{\"key\":\"fullpath\",\"label\":\"Full Path\",\"type\":\"system\"}},\"published\":{\"name\":\"published\",\"position\":3,\"hidden\":false,\"width\":40,\"locked\":false,\"fieldConfig\":{\"key\":\"published\",\"label\":\"Published\",\"type\":\"system\"}},\"creationDate\":{\"name\":\"creationDate\",\"position\":4,\"hidden\":false,\"width\":160,\"locked\":false,\"fieldConfig\":{\"key\":\"creationDate\",\"label\":\"Creation Date\",\"type\":\"system\"}},\"modificationDate\":{\"name\":\"modificationDate\",\"position\":5,\"hidden\":false,\"width\":160,\"locked\":false,\"fieldConfig\":{\"key\":\"modificationDate\",\"label\":\"Modification Date\",\"type\":\"system\"}},\"title\":{\"name\":\"title\",\"position\":6,\"hidden\":false,\"width\":43,\"locked\":false,\"fieldConfig\":{\"key\":\"title\",\"label\":\"Title\",\"type\":\"input\",\"layout\":{\"name\":\"title\",\"title\":\"Title\",\"tooltip\":\"\",\"mandatory\":true,\"noteditable\":false,\"index\":false,\"locked\":false,\"style\":\"\",\"permissions\":null,\"fieldtype\":\"input\",\"relationType\":false,\"invisible\":false,\"visibleGridView\":false,\"visibleSearch\":false,\"defaultValue\":null,\"columnLength\":190,\"regex\":\"\",\"regexFlags\":[],\"unique\":false,\"showCharCount\":false,\"width\":\"\",\"defaultValueGenerator\":\"\",\"datatype\":\"data\"},\"width\":43}},\"category\":{\"name\":\"category\",\"position\":7,\"hidden\":false,\"width\":67,\"locked\":false,\"fieldConfig\":{\"key\":\"category\",\"label\":\"Category\",\"type\":\"manyToOneRelation\",\"layout\":{\"name\":\"category\",\"title\":\"Category\",\"tooltip\":\"\",\"mandatory\":true,\"noteditable\":false,\"index\":false,\"locked\":false,\"style\":\"\",\"permissions\":null,\"fieldtype\":\"manyToOneRelation\",\"relationType\":true,\"invisible\":false,\"visibleGridView\":false,\"visibleSearch\":false,\"classes\":[{\"classes\":\"JobCategory\"}],\"displayMode\":\"grid\",\"pathFormatterClass\":\"\",\"assetInlineDownloadAllowed\":false,\"assetUploadPath\":\"\",\"allowToClearRelation\":true,\"objectsAllowed\":true,\"assetsAllowed\":false,\"assetTypes\":[],\"documentsAllowed\":false,\"documentTypes\":[],\"width\":\"\",\"datatype\":\"data\",\"visibleFields\":\"fullpath\"},\"width\":67}},\"site\":{\"name\":\"site\",\"position\":8,\"hidden\":false,\"width\":40,\"locked\":false,\"fieldConfig\":{\"key\":\"site\",\"label\":\"Site\",\"type\":\"select\",\"layout\":{\"name\":\"site\",\"title\":\"Site\",\"tooltip\":\"\",\"mandatory\":false,\"noteditable\":false,\"index\":false,\"locked\":false,\"style\":\"\",\"permissions\":null,\"fieldtype\":\"select\",\"relationType\":false,\"invisible\":false,\"visibleGridView\":false,\"visibleSearch\":false,\"options\":[{\"value\":\"MI\",\"key\":\"Milano\"},{\"value\":\"PD\",\"key\":\"Padova\"},{\"value\":\"ROMA\",\"key\":\"Roma\"},{\"value\":\"TO\",\"key\":\"Torino\"}],\"defaultValue\":\"\",\"columnLength\":190,\"dynamicOptions\":false,\"defaultValueGenerator\":\"\",\"width\":\"\",\"optionsProviderType\":\"select_options\",\"optionsProviderClass\":\"Pimcore\\\\Bundle\\\\CoreBundle\\\\OptionsProvider\\\\SelectOptionsOptionsProvider\",\"optionsProviderData\":\"Sites\",\"datatype\":\"data\"}}},\"#68ef547f6148e\":{\"name\":\"#68ef547f6148e\",\"position\":9,\"hidden\":false,\"width\":84,\"locked\":false,\"fieldConfig\":{\"isOperator\":true,\"attributes\":{\"label\":\"Applications\",\"type\":\"operator\",\"class\":\"ElementCounter\",\"countEmpty\":true,\"children\":[{\"label\":\"Applications (applications)\",\"type\":\"value\",\"class\":\"DefaultValue\",\"attribute\":\"applications\",\"dataType\":\"reverseObjectRelation\",\"children\":[]}]},\"key\":\"#68ef547f6148e\"},\"isOperator\":true}},\"onlyDirectChildren\":false,\"searchFilter\":\"\",\"filter\":[],\"pimcore_version\":\"v11.5.11\",\"pimcore_revision\":\"4a6b08e7633aeb0ecf0fc983412498b6d5e828d3\",\"context\":\"{}\"}','',1760514984,1760515199,1,1);
/*!40000 ALTER TABLE `gridconfigs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `http_error_log`
--

DROP TABLE IF EXISTS `http_error_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `http_error_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uri` varchar(1024) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `code` int(3) DEFAULT NULL,
  `parametersGet` longtext DEFAULT NULL,
  `parametersPost` longtext DEFAULT NULL,
  `cookies` longtext DEFAULT NULL,
  `serverVars` longtext DEFAULT NULL,
  `date` int(11) unsigned DEFAULT NULL,
  `count` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `uri` (`uri`),
  KEY `code` (`code`),
  KEY `date` (`date`),
  KEY `count` (`count`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `http_error_log`
--

LOCK TABLES `http_error_log` WRITE;
/*!40000 ALTER TABLE `http_error_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `http_error_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `importconfig_shares`
--

DROP TABLE IF EXISTS `importconfig_shares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `importconfig_shares` (
  `importConfigId` int(11) NOT NULL,
  `sharedWithUserId` int(11) NOT NULL,
  PRIMARY KEY (`importConfigId`,`sharedWithUserId`),
  KEY `sharedWithUserId` (`sharedWithUserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `importconfig_shares`
--

LOCK TABLES `importconfig_shares` WRITE;
/*!40000 ALTER TABLE `importconfig_shares` DISABLE KEYS */;
/*!40000 ALTER TABLE `importconfig_shares` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `importconfigs`
--

DROP TABLE IF EXISTS `importconfigs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `importconfigs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ownerId` int(11) DEFAULT NULL,
  `classId` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `config` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`config`)),
  `description` longtext DEFAULT NULL,
  `creationDate` int(11) DEFAULT NULL,
  `modificationDate` int(11) DEFAULT NULL,
  `shareGlobally` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ownerId` (`ownerId`),
  KEY `classId` (`classId`),
  KEY `shareGlobally` (`shareGlobally`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `importconfigs`
--

LOCK TABLES `importconfigs` WRITE;
/*!40000 ALTER TABLE `importconfigs` DISABLE KEYS */;
/*!40000 ALTER TABLE `importconfigs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lock_keys`
--

DROP TABLE IF EXISTS `lock_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lock_keys` (
  `key_id` varchar(64) NOT NULL,
  `key_token` varchar(44) NOT NULL,
  `key_expiration` int(10) unsigned NOT NULL,
  PRIMARY KEY (`key_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lock_keys`
--

LOCK TABLES `lock_keys` WRITE;
/*!40000 ALTER TABLE `lock_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `lock_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messenger_messages`
--

DROP TABLE IF EXISTS `messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `messenger_messages` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `available_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `delivered_at` datetime DEFAULT NULL COMMENT '(DC2Type:datetime_immutable)',
  PRIMARY KEY (`id`),
  KEY `IDX_75EA56E0FB7336F0` (`queue_name`),
  KEY `IDX_75EA56E0E3BD61CE` (`available_at`),
  KEY `IDX_75EA56E016BA31DB` (`delivered_at`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messenger_messages`
--

LOCK TABLES `messenger_messages` WRITE;
/*!40000 ALTER TABLE `messenger_messages` DISABLE KEYS */;
INSERT INTO `messenger_messages` VALUES
(1,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:2;}}','[]','pimcore_search_backend_message','2025-10-15 07:26:26','2025-10-15 07:26:26',NULL),
(2,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:2;}}','[]','pimcore_search_backend_message','2025-10-15 07:26:26','2025-10-15 07:26:26',NULL),
(3,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:3;}}','[]','pimcore_search_backend_message','2025-10-15 07:26:35','2025-10-15 07:26:35',NULL),
(4,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:3;}}','[]','pimcore_search_backend_message','2025-10-15 07:26:35','2025-10-15 07:26:35',NULL),
(5,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:4;}}','[]','pimcore_search_backend_message','2025-10-15 07:26:41','2025-10-15 07:26:41',NULL),
(6,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:4;}}','[]','pimcore_search_backend_message','2025-10-15 07:26:41','2025-10-15 07:26:41',NULL),
(7,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:5;}}','[]','pimcore_search_backend_message','2025-10-15 07:26:48','2025-10-15 07:26:48',NULL),
(8,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:6;}}','[]','pimcore_search_backend_message','2025-10-15 07:26:55','2025-10-15 07:26:55',NULL),
(9,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:7;}}','[]','pimcore_search_backend_message','2025-10-15 07:27:01','2025-10-15 07:27:01',NULL),
(10,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:5;}}','[]','pimcore_search_backend_message','2025-10-15 07:27:07','2025-10-15 07:27:07',NULL),
(11,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:6;}}','[]','pimcore_search_backend_message','2025-10-15 07:27:12','2025-10-15 07:27:12',NULL),
(12,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:5;}}','[]','pimcore_search_backend_message','2025-10-15 07:27:18','2025-10-15 07:27:18',NULL),
(13,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:7;}}','[]','pimcore_search_backend_message','2025-10-15 07:28:29','2025-10-15 07:28:29',NULL),
(14,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:5;}}','[]','pimcore_search_backend_message','2025-10-15 07:28:34','2025-10-15 07:28:34',NULL),
(15,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:6;}}','[]','pimcore_search_backend_message','2025-10-15 07:28:35','2025-10-15 07:28:35',NULL),
(16,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:7;}}','[]','pimcore_search_backend_message','2025-10-15 07:28:35','2025-10-15 07:28:35',NULL),
(17,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:8;}}','[]','pimcore_search_backend_message','2025-10-15 07:36:58','2025-10-15 07:36:58',NULL),
(18,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:8;}}','[]','pimcore_search_backend_message','2025-10-15 07:44:54','2025-10-15 07:44:54',NULL),
(19,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:9;}}','[]','pimcore_search_backend_message','2025-10-15 07:45:18','2025-10-15 07:45:18',NULL),
(20,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:9;}}','[]','pimcore_search_backend_message','2025-10-15 07:45:42','2025-10-15 07:45:42',NULL),
(21,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:8;}}','[]','pimcore_search_backend_message','2025-10-15 07:45:50','2025-10-15 07:45:50',NULL),
(22,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:10;}}','[]','pimcore_search_backend_message','2025-10-15 07:46:09','2025-10-15 07:46:09',NULL),
(23,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:10;}}','[]','pimcore_search_backend_message','2025-10-15 07:46:31','2025-10-15 07:46:31',NULL),
(24,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:11;}}','[]','pimcore_search_backend_message','2025-10-15 07:46:53','2025-10-15 07:46:53',NULL),
(25,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:12;}}','[]','pimcore_search_backend_message','2025-10-15 07:47:20','2025-10-15 07:47:20',NULL),
(26,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:12;}}','[]','pimcore_search_backend_message','2025-10-15 07:47:30','2025-10-15 07:47:30',NULL),
(27,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:11;}}','[]','pimcore_search_backend_message','2025-10-15 07:47:36','2025-10-15 07:47:36',NULL),
(28,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:13;}}','[]','pimcore_search_backend_message','2025-10-15 07:47:58','2025-10-15 07:47:58',NULL),
(29,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:13;}}','[]','pimcore_search_backend_message','2025-10-15 07:48:15','2025-10-15 07:48:15',NULL),
(30,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:14;}}','[]','pimcore_search_backend_message','2025-10-15 07:50:26','2025-10-15 07:50:26',NULL),
(31,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:14;}}','[]','pimcore_search_backend_message','2025-10-15 07:50:45','2025-10-15 07:50:45',NULL),
(32,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:15;}}','[]','pimcore_search_backend_message','2025-10-15 07:50:59','2025-10-15 07:50:59',NULL),
(33,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:16;}}','[]','pimcore_search_backend_message','2025-10-15 07:51:18','2025-10-15 07:51:18',NULL),
(34,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:16;}}','[]','pimcore_search_backend_message','2025-10-15 07:51:24','2025-10-15 07:51:24',NULL),
(35,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:15;}}','[]','pimcore_search_backend_message','2025-10-15 07:51:29','2025-10-15 07:51:29',NULL),
(36,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:17;}}','[]','pimcore_search_backend_message','2025-10-15 07:51:45','2025-10-15 07:51:45',NULL),
(37,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:17;}}','[]','pimcore_search_backend_message','2025-10-15 07:52:02','2025-10-15 07:52:02',NULL),
(38,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:18;}}','[]','pimcore_search_backend_message','2025-10-15 07:52:18','2025-10-15 07:52:18',NULL),
(39,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:18;}}','[]','pimcore_search_backend_message','2025-10-15 07:52:34','2025-10-15 07:52:34',NULL),
(40,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:19;}}','[]','pimcore_search_backend_message','2025-10-15 07:52:41','2025-10-15 07:52:41',NULL),
(41,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:19;}}','[]','pimcore_search_backend_message','2025-10-15 07:52:47','2025-10-15 07:52:47',NULL),
(42,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:20;}}','[]','pimcore_search_backend_message','2025-10-15 07:52:57','2025-10-15 07:52:57',NULL),
(43,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:20;}}','[]','pimcore_search_backend_message','2025-10-15 07:53:14','2025-10-15 07:53:14',NULL),
(44,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:20;}}','[]','pimcore_search_backend_message','2025-10-15 07:53:18','2025-10-15 07:53:18',NULL),
(45,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:12;}}','[]','pimcore_search_backend_message','2025-10-15 07:53:20','2025-10-15 07:53:20',NULL),
(46,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:16;}}','[]','pimcore_search_backend_message','2025-10-15 07:53:20','2025-10-15 07:53:20',NULL),
(47,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:19;}}','[]','pimcore_search_backend_message','2025-10-15 07:53:21','2025-10-15 07:53:21',NULL),
(48,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:4;}}','[]','pimcore_search_backend_message','2025-10-15 07:53:22','2025-10-15 07:53:22',NULL),
(49,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:8;}}','[]','pimcore_search_backend_message','2025-10-15 07:56:54','2025-10-15 07:56:54',NULL),
(50,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:9;}}','[]','pimcore_search_backend_message','2025-10-15 07:56:54','2025-10-15 07:56:54',NULL),
(51,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:10;}}','[]','pimcore_search_backend_message','2025-10-15 07:56:55','2025-10-15 07:56:55',NULL),
(52,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:11;}}','[]','pimcore_search_backend_message','2025-10-15 07:56:56','2025-10-15 07:56:56',NULL),
(53,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:13;}}','[]','pimcore_search_backend_message','2025-10-15 07:56:56','2025-10-15 07:56:56',NULL),
(54,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:14;}}','[]','pimcore_search_backend_message','2025-10-15 07:56:57','2025-10-15 07:56:57',NULL),
(55,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:15;}}','[]','pimcore_search_backend_message','2025-10-15 07:56:57','2025-10-15 07:56:57',NULL),
(56,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:17;}}','[]','pimcore_search_backend_message','2025-10-15 07:56:57','2025-10-15 07:56:57',NULL),
(57,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:18;}}','[]','pimcore_search_backend_message','2025-10-15 07:56:58','2025-10-15 07:56:58',NULL),
(58,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:20;}}','[]','pimcore_search_backend_message','2025-10-15 07:56:58','2025-10-15 07:56:58',NULL),
(59,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:8;}}','[]','pimcore_search_backend_message','2025-10-15 07:57:28','2025-10-15 07:57:28',NULL),
(60,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:9;}}','[]','pimcore_search_backend_message','2025-10-15 07:57:51','2025-10-15 07:57:51',NULL),
(61,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:14;}}','[]','pimcore_search_backend_message','2025-10-15 07:58:05','2025-10-15 07:58:05',NULL),
(62,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:10;}}','[]','pimcore_search_backend_message','2025-10-15 07:58:16','2025-10-15 07:58:16',NULL),
(63,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:9;}}','[]','pimcore_search_backend_message','2025-10-15 07:58:38','2025-10-15 07:58:38',NULL),
(64,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:13;}}','[]','pimcore_search_backend_message','2025-10-15 07:58:50','2025-10-15 07:58:50',NULL),
(65,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:20;}}','[]','pimcore_search_backend_message','2025-10-15 07:59:01','2025-10-15 07:59:01',NULL),
(66,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:11;}}','[]','pimcore_search_backend_message','2025-10-15 07:59:11','2025-10-15 07:59:11',NULL),
(67,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:21;}}','[]','pimcore_search_backend_message','2025-10-15 08:02:24','2025-10-15 08:02:24',NULL),
(68,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:21;}}','[]','pimcore_search_backend_message','2025-10-15 08:02:59','2025-10-15 08:02:59',NULL),
(69,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:21;}}','[]','pimcore_search_backend_message','2025-10-15 08:03:06','2025-10-15 08:03:06',NULL),
(70,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:22;}}','[]','pimcore_search_backend_message','2025-10-15 08:03:17','2025-10-15 08:03:17',NULL),
(71,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:22;}}','[]','pimcore_search_backend_message','2025-10-15 08:04:02','2025-10-15 08:04:02',NULL),
(72,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:26:\\\"messenger.bus.pimcore-core\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:69:\\\"Pimcore\\\\Bundle\\\\SimpleBackendSearchBundle\\\\Message\\\\SearchBackendMessage\\\":2:{s:7:\\\"\\0*\\0type\\\";s:6:\\\"object\\\";s:5:\\\"\\0*\\0id\\\";i:22;}}','[]','pimcore_search_backend_message','2025-10-15 08:04:04','2025-10-15 08:04:04',NULL);
/*!40000 ALTER TABLE `messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migration_versions`
--

DROP TABLE IF EXISTS `migration_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migration_versions` (
  `version` varchar(1024) NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migration_versions`
--

LOCK TABLES `migration_versions` WRITE;
/*!40000 ALTER TABLE `migration_versions` DISABLE KEYS */;
INSERT INTO `migration_versions` VALUES
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201007000000',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201008082752',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201008091131',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201008101817',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201008132324',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201009095924',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201012154224',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201014101437',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201113143914',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201201084201',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210218142556',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210323082921',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210323110055',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210324152821',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210324152822',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210330132354',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210408153226',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210412112812',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210428145320',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210505093841',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210531125102',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210608094532',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210616114744',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210624085031',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210630062445',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210702102100',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210901130000',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210928135248',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20211016084043',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20211018104331',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20211028134037',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20211028155535',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20211103055110',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20211209131141',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20211221152344',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220119082511',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220120121803',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220120162621',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220201132131',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220214110000',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220317125711',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220318101020',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220402104849',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220411172543',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220419120333',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220425082914',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220502104200',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220506103100',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220511085800',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220614115124',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220617145524',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220718162200',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220725154615',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220809154926',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220809164000',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220816120101',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220829132224',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220830105212',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220906111031',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220908113752',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20221003115124',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20221005090000',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20221019042134',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20221020195451',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20221025165133',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20221028115803',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20221107084519',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20221116115427',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20221129084031',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20221215071650',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20221216140012',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20221220152444',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20221222134837',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20221222181745',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20221228101109',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230107224432',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230110130748',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230111074323',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230113165612',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230120111111',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230124120641',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230125164101',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230202152342',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230221073317',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230222075502',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230222174636',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230223101848',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230320110429',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230320131322',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230321133700',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230322114936',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230405162853',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230406113010',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230424084415',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230428112302',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230517115427',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230525131748',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230615103905',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230616085142',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20230913173812',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20231127124738',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20240131080600',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20240222143211',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20240229152000',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20240606165618',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20240708083500',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20240813085200',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20241021111028',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20241025101923',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20241114142759',NULL,NULL),
('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20250416120333',NULL,NULL);
/*!40000 ALTER TABLE `migration_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  `cid` int(11) DEFAULT NULL,
  `ctype` enum('asset','document','object') DEFAULT NULL,
  `date` int(11) DEFAULT NULL,
  `user` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `locked` tinyint(1) unsigned DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `cid_ctype` (`cid`,`ctype`),
  KEY `date` (`date`),
  KEY `user` (`user`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes`
--

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
INSERT INTO `notes` VALUES
(1,'consent-given',21,'object',1760515379,2,'Consent given for field privacy','Manually by User via Pimcore Backend.',1),
(2,'consent-given',22,'object',1760515442,2,'Consent given for field privacy','Manually by User via Pimcore Backend.',1);
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes_data`
--

DROP TABLE IF EXISTS `notes_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notes_data` (
  `auto_id` int(11) NOT NULL AUTO_INCREMENT,
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` enum('text','date','document','asset','object','bool') DEFAULT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`auto_id`),
  UNIQUE KEY `UNIQ_E5A8E5E2BF3967505E237E06` (`id`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes_data`
--

LOCK TABLES `notes_data` WRITE;
/*!40000 ALTER TABLE `notes_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `notes_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL DEFAULT 'info',
  `title` varchar(250) NOT NULL DEFAULT '',
  `message` text NOT NULL,
  `sender` int(11) DEFAULT NULL,
  `recipient` int(11) NOT NULL,
  `read` tinyint(1) NOT NULL DEFAULT 0,
  `creationDate` timestamp NULL DEFAULT current_timestamp(),
  `modificationDate` timestamp NULL DEFAULT NULL,
  `linkedElementType` enum('document','asset','object') DEFAULT NULL,
  `linkedElement` int(11) DEFAULT NULL,
  `payload` longtext DEFAULT NULL,
  `isStudio` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `recipient` (`recipient`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `object_application`
--

DROP TABLE IF EXISTS `object_application`;
/*!50001 DROP VIEW IF EXISTS `object_application`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `object_application` AS SELECT
 1 AS `oo_id`,
  1 AS `oo_classId`,
  1 AS `oo_className`,
  1 AS `firstname`,
  1 AS `lastname`,
  1 AS `email`,
  1 AS `privacy`,
  1 AS `marketing`,
  1 AS `position__id`,
  1 AS `position__type`,
  1 AS `id`,
  1 AS `parentId`,
  1 AS `type`,
  1 AS `key`,
  1 AS `path`,
  1 AS `index`,
  1 AS `published`,
  1 AS `creationDate`,
  1 AS `modificationDate`,
  1 AS `userOwner`,
  1 AS `userModification`,
  1 AS `classId`,
  1 AS `className`,
  1 AS `childrenSortBy`,
  1 AS `childrenSortOrder`,
  1 AS `versionCount` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `object_job_category`
--

DROP TABLE IF EXISTS `object_job_category`;
/*!50001 DROP VIEW IF EXISTS `object_job_category`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `object_job_category` AS SELECT
 1 AS `oo_id`,
  1 AS `oo_classId`,
  1 AS `oo_className`,
  1 AS `positions`,
  1 AS `id`,
  1 AS `parentId`,
  1 AS `type`,
  1 AS `key`,
  1 AS `path`,
  1 AS `index`,
  1 AS `published`,
  1 AS `creationDate`,
  1 AS `modificationDate`,
  1 AS `userOwner`,
  1 AS `userModification`,
  1 AS `classId`,
  1 AS `className`,
  1 AS `childrenSortBy`,
  1 AS `childrenSortOrder`,
  1 AS `versionCount` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `object_localized_data_job_category`
--

DROP TABLE IF EXISTS `object_localized_data_job_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_localized_data_job_category` (
  `ooo_id` int(11) unsigned NOT NULL DEFAULT 0,
  `language` varchar(10) NOT NULL DEFAULT '',
  `title` varchar(190) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  PRIMARY KEY (`ooo_id`,`language`),
  KEY `language` (`language`),
  CONSTRAINT `fk_object_localized_data_job_category__ooo_id` FOREIGN KEY (`ooo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_localized_data_job_category`
--

LOCK TABLES `object_localized_data_job_category` WRITE;
/*!40000 ALTER TABLE `object_localized_data_job_category` DISABLE KEYS */;
INSERT INTO `object_localized_data_job_category` VALUES
(5,'de',NULL,NULL),
(5,'en','HR',NULL),
(5,'fr',NULL,NULL),
(5,'it',NULL,NULL),
(6,'de',NULL,NULL),
(6,'en',NULL,NULL),
(6,'fr',NULL,NULL),
(6,'it',NULL,NULL),
(7,'de',NULL,NULL),
(7,'en','Staff',NULL),
(7,'fr',NULL,NULL),
(7,'it','Staff',NULL),
(12,'en','Product',NULL),
(12,'it','Prodotto',NULL),
(16,'en','Design',NULL),
(16,'it','Design',NULL),
(19,'en','Marketing',NULL),
(19,'it','Marketing',NULL);
/*!40000 ALTER TABLE `object_localized_data_job_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_localized_data_position`
--

DROP TABLE IF EXISTS `object_localized_data_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_localized_data_position` (
  `ooo_id` int(11) unsigned NOT NULL DEFAULT 0,
  `language` varchar(10) NOT NULL DEFAULT '',
  `title` varchar(190) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  PRIMARY KEY (`ooo_id`,`language`),
  KEY `language` (`language`),
  CONSTRAINT `fk_object_localized_data_position__ooo_id` FOREIGN KEY (`ooo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_localized_data_position`
--

LOCK TABLES `object_localized_data_position` WRITE;
/*!40000 ALTER TABLE `object_localized_data_position` DISABLE KEYS */;
INSERT INTO `object_localized_data_position` VALUES
(8,'en','Backend Senior Developer',NULL),
(8,'it','Sviluppatore Backend Senior','<p><strong>Scalable API design and development, database management, and performance optimization. Experience with PHP/Laravel or Symfony and knowledge of CI/CD are required.</strong></p>'),
(9,'en','Frontend Developer React',NULL),
(9,'it','Frontend Developer React','<p><strong>Responsive interface development with React, REST/GraphQL integration, and a focus on accessibility. Experience with TypeScript, testing, and optimization.</strong></p>'),
(10,'en','DevOps Engineer',NULL),
(10,'it','DevOps Engineer','<p><strong>Cloud infrastructure management, deployment automation, monitoring, and security. Experience with Kubernetes, Docker, Terraform, and CI/CD pipelines.</strong></p>'),
(11,'en',NULL,NULL),
(11,'it','Product Manager','<p><strong>Product roadmap coordination, requirements analysis, stakeholder management, and KPI definition. Experience with Agile methodologies and cross-team communication required.</strong></p>'),
(13,'en','HR Generalist',NULL),
(13,'it','HR Generalist','<p><strong>HR process management: recruiting, onboarding, training, and personnel administration. Good communication skills and knowledge of labor regulations.</strong></p>'),
(14,'en','Data Scientist',NULL),
(14,'it','Data Scientist','<p><strong>Data analysis, predictive modeling, and insight visualization to support business decisions. Experience with Python, ML, and SQL required.</strong></p>'),
(15,'en','UX/UI Designer',NULL),
(15,'it','UX/UI Designer','<p><strong>Progettazione interfacce e prototipi centrati sull&#039;utente, test di usabilità e collaborazione con dev. Esperienza in Figma, wireframing e design system.</strong></p>'),
(17,'en','QA Automation Engineer',NULL),
(17,'it','QA Automation Engineer','<p><strong>Progettazione e sviluppo di test automatici, integrazione in pipeline CI e verifica regressioni. Esperienza con Selenium, Cypress o Playwright e testing API.</strong></p>'),
(18,'en','Technical Support Engineer',NULL),
(18,'it','Technical Support Engineer','<p><strong>Supporto tecnico di secondo livello, troubleshooting, gestione ticket e documentazione. Richiesta conoscenza di reti, sistemi operativi e strumenti di ticketing.</strong></p>'),
(20,'en','Marketing Specialist',NULL),
(20,'it','Marketing Specialist','<p><strong>Digital campaign planning and management, performance analysis, SEO/SEM, and content strategy. Experience with analytics and advertising tools.</strong></p>');
/*!40000 ALTER TABLE `object_localized_data_position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `object_localized_job_category_de`
--

DROP TABLE IF EXISTS `object_localized_job_category_de`;
/*!50001 DROP VIEW IF EXISTS `object_localized_job_category_de`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `object_localized_job_category_de` AS SELECT
 1 AS `oo_id`,
  1 AS `oo_classId`,
  1 AS `oo_className`,
  1 AS `positions`,
  1 AS `id`,
  1 AS `parentId`,
  1 AS `type`,
  1 AS `key`,
  1 AS `path`,
  1 AS `index`,
  1 AS `published`,
  1 AS `creationDate`,
  1 AS `modificationDate`,
  1 AS `userOwner`,
  1 AS `userModification`,
  1 AS `classId`,
  1 AS `className`,
  1 AS `childrenSortBy`,
  1 AS `childrenSortOrder`,
  1 AS `versionCount`,
  1 AS `ooo_id`,
  1 AS `language`,
  1 AS `title`,
  1 AS `description` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `object_localized_job_category_en`
--

DROP TABLE IF EXISTS `object_localized_job_category_en`;
/*!50001 DROP VIEW IF EXISTS `object_localized_job_category_en`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `object_localized_job_category_en` AS SELECT
 1 AS `oo_id`,
  1 AS `oo_classId`,
  1 AS `oo_className`,
  1 AS `positions`,
  1 AS `id`,
  1 AS `parentId`,
  1 AS `type`,
  1 AS `key`,
  1 AS `path`,
  1 AS `index`,
  1 AS `published`,
  1 AS `creationDate`,
  1 AS `modificationDate`,
  1 AS `userOwner`,
  1 AS `userModification`,
  1 AS `classId`,
  1 AS `className`,
  1 AS `childrenSortBy`,
  1 AS `childrenSortOrder`,
  1 AS `versionCount`,
  1 AS `ooo_id`,
  1 AS `language`,
  1 AS `title`,
  1 AS `description` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `object_localized_job_category_fr`
--

DROP TABLE IF EXISTS `object_localized_job_category_fr`;
/*!50001 DROP VIEW IF EXISTS `object_localized_job_category_fr`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `object_localized_job_category_fr` AS SELECT
 1 AS `oo_id`,
  1 AS `oo_classId`,
  1 AS `oo_className`,
  1 AS `positions`,
  1 AS `id`,
  1 AS `parentId`,
  1 AS `type`,
  1 AS `key`,
  1 AS `path`,
  1 AS `index`,
  1 AS `published`,
  1 AS `creationDate`,
  1 AS `modificationDate`,
  1 AS `userOwner`,
  1 AS `userModification`,
  1 AS `classId`,
  1 AS `className`,
  1 AS `childrenSortBy`,
  1 AS `childrenSortOrder`,
  1 AS `versionCount`,
  1 AS `ooo_id`,
  1 AS `language`,
  1 AS `title`,
  1 AS `description` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `object_localized_job_category_it`
--

DROP TABLE IF EXISTS `object_localized_job_category_it`;
/*!50001 DROP VIEW IF EXISTS `object_localized_job_category_it`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `object_localized_job_category_it` AS SELECT
 1 AS `oo_id`,
  1 AS `oo_classId`,
  1 AS `oo_className`,
  1 AS `positions`,
  1 AS `id`,
  1 AS `parentId`,
  1 AS `type`,
  1 AS `key`,
  1 AS `path`,
  1 AS `index`,
  1 AS `published`,
  1 AS `creationDate`,
  1 AS `modificationDate`,
  1 AS `userOwner`,
  1 AS `userModification`,
  1 AS `classId`,
  1 AS `className`,
  1 AS `childrenSortBy`,
  1 AS `childrenSortOrder`,
  1 AS `versionCount`,
  1 AS `ooo_id`,
  1 AS `language`,
  1 AS `title`,
  1 AS `description` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `object_localized_position_de`
--

DROP TABLE IF EXISTS `object_localized_position_de`;
/*!50001 DROP VIEW IF EXISTS `object_localized_position_de`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `object_localized_position_de` AS SELECT
 1 AS `oo_id`,
  1 AS `oo_classId`,
  1 AS `oo_className`,
  1 AS `category__id`,
  1 AS `category__type`,
  1 AS `id`,
  1 AS `parentId`,
  1 AS `type`,
  1 AS `key`,
  1 AS `path`,
  1 AS `index`,
  1 AS `published`,
  1 AS `creationDate`,
  1 AS `modificationDate`,
  1 AS `userOwner`,
  1 AS `userModification`,
  1 AS `classId`,
  1 AS `className`,
  1 AS `childrenSortBy`,
  1 AS `childrenSortOrder`,
  1 AS `versionCount`,
  1 AS `ooo_id`,
  1 AS `language`,
  1 AS `title`,
  1 AS `description` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `object_localized_position_en`
--

DROP TABLE IF EXISTS `object_localized_position_en`;
/*!50001 DROP VIEW IF EXISTS `object_localized_position_en`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `object_localized_position_en` AS SELECT
 1 AS `oo_id`,
  1 AS `oo_classId`,
  1 AS `oo_className`,
  1 AS `category__id`,
  1 AS `category__type`,
  1 AS `applications`,
  1 AS `site`,
  1 AS `id`,
  1 AS `parentId`,
  1 AS `type`,
  1 AS `key`,
  1 AS `path`,
  1 AS `index`,
  1 AS `published`,
  1 AS `creationDate`,
  1 AS `modificationDate`,
  1 AS `userOwner`,
  1 AS `userModification`,
  1 AS `classId`,
  1 AS `className`,
  1 AS `childrenSortBy`,
  1 AS `childrenSortOrder`,
  1 AS `versionCount`,
  1 AS `ooo_id`,
  1 AS `language`,
  1 AS `title`,
  1 AS `description` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `object_localized_position_fr`
--

DROP TABLE IF EXISTS `object_localized_position_fr`;
/*!50001 DROP VIEW IF EXISTS `object_localized_position_fr`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `object_localized_position_fr` AS SELECT
 1 AS `oo_id`,
  1 AS `oo_classId`,
  1 AS `oo_className`,
  1 AS `category__id`,
  1 AS `category__type`,
  1 AS `id`,
  1 AS `parentId`,
  1 AS `type`,
  1 AS `key`,
  1 AS `path`,
  1 AS `index`,
  1 AS `published`,
  1 AS `creationDate`,
  1 AS `modificationDate`,
  1 AS `userOwner`,
  1 AS `userModification`,
  1 AS `classId`,
  1 AS `className`,
  1 AS `childrenSortBy`,
  1 AS `childrenSortOrder`,
  1 AS `versionCount`,
  1 AS `ooo_id`,
  1 AS `language`,
  1 AS `title`,
  1 AS `description` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `object_localized_position_it`
--

DROP TABLE IF EXISTS `object_localized_position_it`;
/*!50001 DROP VIEW IF EXISTS `object_localized_position_it`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `object_localized_position_it` AS SELECT
 1 AS `oo_id`,
  1 AS `oo_classId`,
  1 AS `oo_className`,
  1 AS `category__id`,
  1 AS `category__type`,
  1 AS `applications`,
  1 AS `site`,
  1 AS `id`,
  1 AS `parentId`,
  1 AS `type`,
  1 AS `key`,
  1 AS `path`,
  1 AS `index`,
  1 AS `published`,
  1 AS `creationDate`,
  1 AS `modificationDate`,
  1 AS `userOwner`,
  1 AS `userModification`,
  1 AS `classId`,
  1 AS `className`,
  1 AS `childrenSortBy`,
  1 AS `childrenSortOrder`,
  1 AS `versionCount`,
  1 AS `ooo_id`,
  1 AS `language`,
  1 AS `title`,
  1 AS `description` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `object_localized_query_job_category_de`
--

DROP TABLE IF EXISTS `object_localized_query_job_category_de`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_localized_query_job_category_de` (
  `ooo_id` int(11) unsigned NOT NULL DEFAULT 0,
  `language` varchar(10) NOT NULL DEFAULT '',
  `title` varchar(190) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  PRIMARY KEY (`ooo_id`,`language`),
  KEY `language` (`language`),
  CONSTRAINT `fk_object_localized_query_job_category_de__ooo_id` FOREIGN KEY (`ooo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_localized_query_job_category_de`
--

LOCK TABLES `object_localized_query_job_category_de` WRITE;
/*!40000 ALTER TABLE `object_localized_query_job_category_de` DISABLE KEYS */;
INSERT INTO `object_localized_query_job_category_de` VALUES
(5,'de',NULL,NULL),
(6,'de',NULL,NULL),
(7,'de',NULL,NULL);
/*!40000 ALTER TABLE `object_localized_query_job_category_de` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_localized_query_job_category_en`
--

DROP TABLE IF EXISTS `object_localized_query_job_category_en`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_localized_query_job_category_en` (
  `ooo_id` int(11) unsigned NOT NULL DEFAULT 0,
  `language` varchar(10) NOT NULL DEFAULT '',
  `title` varchar(190) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  PRIMARY KEY (`ooo_id`,`language`),
  KEY `language` (`language`),
  CONSTRAINT `fk_object_localized_query_job_category_en__ooo_id` FOREIGN KEY (`ooo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_localized_query_job_category_en`
--

LOCK TABLES `object_localized_query_job_category_en` WRITE;
/*!40000 ALTER TABLE `object_localized_query_job_category_en` DISABLE KEYS */;
INSERT INTO `object_localized_query_job_category_en` VALUES
(5,'en','HR',NULL),
(6,'en',NULL,NULL),
(7,'en','Staff',NULL),
(12,'en','Product',NULL),
(16,'en','Design',NULL),
(19,'en','Marketing',NULL);
/*!40000 ALTER TABLE `object_localized_query_job_category_en` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_localized_query_job_category_fr`
--

DROP TABLE IF EXISTS `object_localized_query_job_category_fr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_localized_query_job_category_fr` (
  `ooo_id` int(11) unsigned NOT NULL DEFAULT 0,
  `language` varchar(10) NOT NULL DEFAULT '',
  `title` varchar(190) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  PRIMARY KEY (`ooo_id`,`language`),
  KEY `language` (`language`),
  CONSTRAINT `fk_object_localized_query_job_category_fr__ooo_id` FOREIGN KEY (`ooo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_localized_query_job_category_fr`
--

LOCK TABLES `object_localized_query_job_category_fr` WRITE;
/*!40000 ALTER TABLE `object_localized_query_job_category_fr` DISABLE KEYS */;
INSERT INTO `object_localized_query_job_category_fr` VALUES
(5,'fr',NULL,NULL),
(6,'fr',NULL,NULL),
(7,'fr',NULL,NULL);
/*!40000 ALTER TABLE `object_localized_query_job_category_fr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_localized_query_job_category_it`
--

DROP TABLE IF EXISTS `object_localized_query_job_category_it`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_localized_query_job_category_it` (
  `ooo_id` int(11) unsigned NOT NULL DEFAULT 0,
  `language` varchar(10) NOT NULL DEFAULT '',
  `title` varchar(190) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  PRIMARY KEY (`ooo_id`,`language`),
  KEY `language` (`language`),
  CONSTRAINT `fk_object_localized_query_job_category_it__ooo_id` FOREIGN KEY (`ooo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_localized_query_job_category_it`
--

LOCK TABLES `object_localized_query_job_category_it` WRITE;
/*!40000 ALTER TABLE `object_localized_query_job_category_it` DISABLE KEYS */;
INSERT INTO `object_localized_query_job_category_it` VALUES
(5,'it',NULL,NULL),
(6,'it',NULL,NULL),
(7,'it','Staff',NULL),
(12,'it','Prodotto',NULL),
(16,'it','Design',NULL),
(19,'it','Marketing',NULL);
/*!40000 ALTER TABLE `object_localized_query_job_category_it` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_localized_query_position_de`
--

DROP TABLE IF EXISTS `object_localized_query_position_de`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_localized_query_position_de` (
  `ooo_id` int(11) unsigned NOT NULL DEFAULT 0,
  `language` varchar(10) NOT NULL DEFAULT '',
  `title` varchar(190) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  PRIMARY KEY (`ooo_id`,`language`),
  KEY `language` (`language`),
  CONSTRAINT `fk_object_localized_query_position_de__ooo_id` FOREIGN KEY (`ooo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_localized_query_position_de`
--

LOCK TABLES `object_localized_query_position_de` WRITE;
/*!40000 ALTER TABLE `object_localized_query_position_de` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_localized_query_position_de` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_localized_query_position_en`
--

DROP TABLE IF EXISTS `object_localized_query_position_en`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_localized_query_position_en` (
  `ooo_id` int(11) unsigned NOT NULL DEFAULT 0,
  `language` varchar(10) NOT NULL DEFAULT '',
  `title` varchar(190) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  PRIMARY KEY (`ooo_id`,`language`),
  KEY `language` (`language`),
  CONSTRAINT `fk_object_localized_query_position_en__ooo_id` FOREIGN KEY (`ooo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_localized_query_position_en`
--

LOCK TABLES `object_localized_query_position_en` WRITE;
/*!40000 ALTER TABLE `object_localized_query_position_en` DISABLE KEYS */;
INSERT INTO `object_localized_query_position_en` VALUES
(8,'en','Backend Senior Developer',NULL),
(9,'en','Frontend Developer React',NULL),
(10,'en','DevOps Engineer',NULL),
(11,'en',NULL,NULL),
(13,'en','HR Generalist',NULL),
(14,'en','Data Scientist',NULL),
(15,'en','UX/UI Designer',NULL),
(17,'en','QA Automation Engineer',NULL),
(18,'en','Technical Support Engineer',NULL),
(20,'en','Marketing Specialist',NULL);
/*!40000 ALTER TABLE `object_localized_query_position_en` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_localized_query_position_fr`
--

DROP TABLE IF EXISTS `object_localized_query_position_fr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_localized_query_position_fr` (
  `ooo_id` int(11) unsigned NOT NULL DEFAULT 0,
  `language` varchar(10) NOT NULL DEFAULT '',
  `title` varchar(190) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  PRIMARY KEY (`ooo_id`,`language`),
  KEY `language` (`language`),
  CONSTRAINT `fk_object_localized_query_position_fr__ooo_id` FOREIGN KEY (`ooo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_localized_query_position_fr`
--

LOCK TABLES `object_localized_query_position_fr` WRITE;
/*!40000 ALTER TABLE `object_localized_query_position_fr` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_localized_query_position_fr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_localized_query_position_it`
--

DROP TABLE IF EXISTS `object_localized_query_position_it`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_localized_query_position_it` (
  `ooo_id` int(11) unsigned NOT NULL DEFAULT 0,
  `language` varchar(10) NOT NULL DEFAULT '',
  `title` varchar(190) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  PRIMARY KEY (`ooo_id`,`language`),
  KEY `language` (`language`),
  CONSTRAINT `fk_object_localized_query_position_it__ooo_id` FOREIGN KEY (`ooo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_localized_query_position_it`
--

LOCK TABLES `object_localized_query_position_it` WRITE;
/*!40000 ALTER TABLE `object_localized_query_position_it` DISABLE KEYS */;
INSERT INTO `object_localized_query_position_it` VALUES
(8,'it','Sviluppatore Backend Senior','Scalable API design and development, database management, and performance optimization. Experience with PHP/Laravel or Symfony and knowledge of CI/CD are required.'),
(9,'it','Frontend Developer React','Responsive interface development with React, REST/GraphQL integration, and a focus on accessibility. Experience with TypeScript, testing, and optimization.'),
(10,'it','DevOps Engineer','Cloud infrastructure management, deployment automation, monitoring, and security. Experience with Kubernetes, Docker, Terraform, and CI/CD pipelines.'),
(11,'it','Product Manager','Product roadmap coordination, requirements analysis, stakeholder management, and KPI definition. Experience with Agile methodologies and cross-team communication required.'),
(13,'it','HR Generalist','HR process management: recruiting, onboarding, training, and personnel administration. Good communication skills and knowledge of labor regulations.'),
(14,'it','Data Scientist','Data analysis, predictive modeling, and insight visualization to support business decisions. Experience with Python, ML, and SQL required.'),
(15,'it','UX/UI Designer','Progettazione interfacce e prototipi centrati sull&#039;utente, test di usabilità e collaborazione con dev. Esperienza in Figma, wireframing e design system.'),
(17,'it','QA Automation Engineer','Progettazione e sviluppo di test automatici, integrazione in pipeline CI e verifica regressioni. Esperienza con Selenium, Cypress o Playwright e testing API.'),
(18,'it','Technical Support Engineer','Supporto tecnico di secondo livello, troubleshooting, gestione ticket e documentazione. Richiesta conoscenza di reti, sistemi operativi e strumenti di ticketing.'),
(20,'it','Marketing Specialist','Digital campaign planning and management, performance analysis, SEO/SEM, and content strategy. Experience with analytics and advertising tools.');
/*!40000 ALTER TABLE `object_localized_query_position_it` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `object_position`
--

DROP TABLE IF EXISTS `object_position`;
/*!50001 DROP VIEW IF EXISTS `object_position`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `object_position` AS SELECT
 1 AS `oo_id`,
  1 AS `oo_classId`,
  1 AS `oo_className`,
  1 AS `category__id`,
  1 AS `category__type`,
  1 AS `applications`,
  1 AS `site`,
  1 AS `id`,
  1 AS `parentId`,
  1 AS `type`,
  1 AS `key`,
  1 AS `path`,
  1 AS `index`,
  1 AS `published`,
  1 AS `creationDate`,
  1 AS `modificationDate`,
  1 AS `userOwner`,
  1 AS `userModification`,
  1 AS `classId`,
  1 AS `className`,
  1 AS `childrenSortBy`,
  1 AS `childrenSortOrder`,
  1 AS `versionCount` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `object_query_application`
--

DROP TABLE IF EXISTS `object_query_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_query_application` (
  `oo_id` int(11) unsigned NOT NULL DEFAULT 0,
  `oo_classId` varchar(50) DEFAULT 'application',
  `oo_className` varchar(255) DEFAULT 'Application',
  `firstname` varchar(190) DEFAULT NULL,
  `lastname` varchar(190) DEFAULT NULL,
  `email` varchar(190) DEFAULT NULL,
  `privacy` tinyint(1) DEFAULT NULL,
  `marketing` tinyint(1) DEFAULT NULL,
  `position__id` int(11) DEFAULT NULL,
  `position__type` enum('document','asset','object') DEFAULT NULL,
  PRIMARY KEY (`oo_id`),
  CONSTRAINT `fk_object_query_application__oo_id` FOREIGN KEY (`oo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_query_application`
--

LOCK TABLES `object_query_application` WRITE;
/*!40000 ALTER TABLE `object_query_application` DISABLE KEYS */;
INSERT INTO `object_query_application` VALUES
(21,'application','Application','Leonardo','Da Vinci','leo_da_vinci@inventore.co',1,0,8,'object'),
(22,'application','Application','Giovanna','D\'arco','gio@orleans.com',1,0,13,'object');
/*!40000 ALTER TABLE `object_query_application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_query_job_category`
--

DROP TABLE IF EXISTS `object_query_job_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_query_job_category` (
  `oo_id` int(11) unsigned NOT NULL DEFAULT 0,
  `oo_classId` varchar(50) DEFAULT 'job_category',
  `oo_className` varchar(255) DEFAULT 'JobCategory',
  `positions` text DEFAULT NULL,
  PRIMARY KEY (`oo_id`),
  CONSTRAINT `fk_object_query_job_category__oo_id` FOREIGN KEY (`oo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_query_job_category`
--

LOCK TABLES `object_query_job_category` WRITE;
/*!40000 ALTER TABLE `object_query_job_category` DISABLE KEYS */;
INSERT INTO `object_query_job_category` VALUES
(5,'job_category','JobCategory',NULL),
(6,'job_category','JobCategory',NULL),
(7,'job_category','JobCategory',NULL),
(12,'job_category','JobCategory',NULL),
(16,'job_category','JobCategory',NULL),
(19,'job_category','JobCategory',NULL);
/*!40000 ALTER TABLE `object_query_job_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_query_position`
--

DROP TABLE IF EXISTS `object_query_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_query_position` (
  `oo_id` int(11) unsigned NOT NULL DEFAULT 0,
  `oo_classId` varchar(50) DEFAULT 'position',
  `oo_className` varchar(255) DEFAULT 'Position',
  `category__id` int(11) DEFAULT NULL,
  `category__type` enum('document','asset','object') DEFAULT NULL,
  `applications` text DEFAULT NULL,
  `site` varchar(190) DEFAULT NULL,
  PRIMARY KEY (`oo_id`),
  CONSTRAINT `fk_object_query_position__oo_id` FOREIGN KEY (`oo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_query_position`
--

LOCK TABLES `object_query_position` WRITE;
/*!40000 ALTER TABLE `object_query_position` DISABLE KEYS */;
INSERT INTO `object_query_position` VALUES
(8,'position','Position',6,'object',NULL,'MI'),
(9,'position','Position',6,'object',NULL,'PD'),
(10,'position','Position',6,'object',NULL,'ROMA'),
(11,'position','Position',12,'object',NULL,'MI'),
(13,'position','Position',5,'object',NULL,''),
(14,'position','Position',6,'object',NULL,'PD'),
(15,'position','Position',16,'object',NULL,'TO'),
(17,'position','Position',6,'object',NULL,'PD'),
(18,'position','Position',6,'object',NULL,'ROMA'),
(20,'position','Position',19,'object',NULL,'PD');
/*!40000 ALTER TABLE `object_query_position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_relations_application`
--

DROP TABLE IF EXISTS `object_relations_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_relations_application` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `src_id` int(11) unsigned NOT NULL DEFAULT 0,
  `dest_id` int(11) unsigned NOT NULL DEFAULT 0,
  `type` enum('object','asset','document') NOT NULL,
  `fieldname` varchar(70) NOT NULL DEFAULT '0',
  `index` int(11) unsigned NOT NULL DEFAULT 0,
  `ownertype` enum('object','fieldcollection','localizedfield','objectbrick') NOT NULL DEFAULT 'object',
  `ownername` varchar(70) NOT NULL DEFAULT '',
  `position` varchar(70) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `forward_lookup` (`src_id`,`ownertype`,`ownername`,`position`),
  KEY `reverse_lookup` (`dest_id`,`type`),
  KEY `fieldname` (`fieldname`),
  CONSTRAINT `fk_object_relations_application__src_id` FOREIGN KEY (`src_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_relations_application`
--

LOCK TABLES `object_relations_application` WRITE;
/*!40000 ALTER TABLE `object_relations_application` DISABLE KEYS */;
INSERT INTO `object_relations_application` VALUES
(1,21,8,'object','position',0,'object','','0'),
(2,22,13,'object','position',0,'object','','0');
/*!40000 ALTER TABLE `object_relations_application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_relations_job_category`
--

DROP TABLE IF EXISTS `object_relations_job_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_relations_job_category` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `src_id` int(11) unsigned NOT NULL DEFAULT 0,
  `dest_id` int(11) unsigned NOT NULL DEFAULT 0,
  `type` enum('object','asset','document') NOT NULL,
  `fieldname` varchar(70) NOT NULL DEFAULT '0',
  `index` int(11) unsigned NOT NULL DEFAULT 0,
  `ownertype` enum('object','fieldcollection','localizedfield','objectbrick') NOT NULL DEFAULT 'object',
  `ownername` varchar(70) NOT NULL DEFAULT '',
  `position` varchar(70) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `forward_lookup` (`src_id`,`ownertype`,`ownername`,`position`),
  KEY `reverse_lookup` (`dest_id`,`type`),
  KEY `fieldname` (`fieldname`),
  CONSTRAINT `fk_object_relations_job_category__src_id` FOREIGN KEY (`src_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_relations_job_category`
--

LOCK TABLES `object_relations_job_category` WRITE;
/*!40000 ALTER TABLE `object_relations_job_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_relations_job_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_relations_position`
--

DROP TABLE IF EXISTS `object_relations_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_relations_position` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `src_id` int(11) unsigned NOT NULL DEFAULT 0,
  `dest_id` int(11) unsigned NOT NULL DEFAULT 0,
  `type` enum('object','asset','document') NOT NULL,
  `fieldname` varchar(70) NOT NULL DEFAULT '0',
  `index` int(11) unsigned NOT NULL DEFAULT 0,
  `ownertype` enum('object','fieldcollection','localizedfield','objectbrick') NOT NULL DEFAULT 'object',
  `ownername` varchar(70) NOT NULL DEFAULT '',
  `position` varchar(70) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `forward_lookup` (`src_id`,`ownertype`,`ownername`,`position`),
  KEY `reverse_lookup` (`dest_id`,`type`),
  KEY `fieldname` (`fieldname`),
  CONSTRAINT `fk_object_relations_position__src_id` FOREIGN KEY (`src_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_relations_position`
--

LOCK TABLES `object_relations_position` WRITE;
/*!40000 ALTER TABLE `object_relations_position` DISABLE KEYS */;
INSERT INTO `object_relations_position` VALUES
(1,8,6,'object','category',0,'object','','0'),
(2,9,6,'object','category',0,'object','','0'),
(3,10,6,'object','category',0,'object','','0'),
(4,11,12,'object','category',0,'object','','0'),
(5,13,5,'object','category',0,'object','','0'),
(6,14,6,'object','category',0,'object','','0'),
(7,15,16,'object','category',0,'object','','0'),
(8,17,6,'object','category',0,'object','','0'),
(9,18,6,'object','category',0,'object','','0'),
(10,20,19,'object','category',0,'object','','0');
/*!40000 ALTER TABLE `object_relations_position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_store_application`
--

DROP TABLE IF EXISTS `object_store_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_store_application` (
  `oo_id` int(11) unsigned NOT NULL DEFAULT 0,
  `firstname` varchar(190) DEFAULT NULL,
  `lastname` varchar(190) DEFAULT NULL,
  `email` varchar(190) DEFAULT NULL,
  `privacy__consent` tinyint(1) DEFAULT NULL,
  `privacy__note` int(11) DEFAULT NULL,
  `marketing__consent` tinyint(1) DEFAULT NULL,
  `marketing__note` int(11) DEFAULT NULL,
  PRIMARY KEY (`oo_id`),
  CONSTRAINT `fk_object_store_application__oo_id` FOREIGN KEY (`oo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_store_application`
--

LOCK TABLES `object_store_application` WRITE;
/*!40000 ALTER TABLE `object_store_application` DISABLE KEYS */;
INSERT INTO `object_store_application` VALUES
(21,'Leonardo','Da Vinci','leo_da_vinci@inventore.co',1,1,0,NULL),
(22,'Giovanna','D\'arco','gio@orleans.com',1,2,0,NULL);
/*!40000 ALTER TABLE `object_store_application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_store_job_category`
--

DROP TABLE IF EXISTS `object_store_job_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_store_job_category` (
  `oo_id` int(11) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`oo_id`),
  CONSTRAINT `fk_object_store_job_category__oo_id` FOREIGN KEY (`oo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_store_job_category`
--

LOCK TABLES `object_store_job_category` WRITE;
/*!40000 ALTER TABLE `object_store_job_category` DISABLE KEYS */;
INSERT INTO `object_store_job_category` VALUES
(5),
(6),
(7),
(12),
(16),
(19);
/*!40000 ALTER TABLE `object_store_job_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_store_position`
--

DROP TABLE IF EXISTS `object_store_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_store_position` (
  `oo_id` int(11) unsigned NOT NULL DEFAULT 0,
  `site` varchar(190) DEFAULT NULL,
  PRIMARY KEY (`oo_id`),
  CONSTRAINT `fk_object_store_position__oo_id` FOREIGN KEY (`oo_id`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_store_position`
--

LOCK TABLES `object_store_position` WRITE;
/*!40000 ALTER TABLE `object_store_position` DISABLE KEYS */;
INSERT INTO `object_store_position` VALUES
(8,'MI'),
(9,'PD'),
(10,'ROMA'),
(11,'MI'),
(13,''),
(14,'PD'),
(15,'TO'),
(17,'PD'),
(18,'ROMA'),
(20,'PD');
/*!40000 ALTER TABLE `object_store_position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_url_slugs`
--

DROP TABLE IF EXISTS `object_url_slugs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `object_url_slugs` (
  `objectId` int(11) unsigned NOT NULL DEFAULT 0,
  `classId` varchar(50) NOT NULL DEFAULT '0',
  `fieldname` varchar(70) NOT NULL DEFAULT '0',
  `ownertype` enum('object','fieldcollection','localizedfield','objectbrick') NOT NULL DEFAULT 'object',
  `ownername` varchar(70) NOT NULL DEFAULT '',
  `position` varchar(70) NOT NULL DEFAULT '0',
  `slug` varchar(765) NOT NULL,
  `siteId` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`slug`,`siteId`),
  KEY `objectId` (`objectId`),
  KEY `classId` (`classId`),
  KEY `fieldname` (`fieldname`),
  KEY `position` (`position`),
  KEY `ownertype` (`ownertype`),
  KEY `ownername` (`ownername`),
  KEY `slug` (`slug`),
  KEY `siteId` (`siteId`),
  KEY `fieldname_ownertype_position_objectId` (`fieldname`,`ownertype`,`position`,`objectId`),
  CONSTRAINT `fk_object_url_slugs__objectId` FOREIGN KEY (`objectId`) REFERENCES `objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_url_slugs`
--

LOCK TABLES `object_url_slugs` WRITE;
/*!40000 ALTER TABLE `object_url_slugs` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_url_slugs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `objects`
--

DROP TABLE IF EXISTS `objects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `objects` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parentId` int(11) unsigned DEFAULT NULL,
  `type` enum('object','folder','variant') DEFAULT NULL,
  `key` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT '',
  `path` varchar(765) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `index` int(11) unsigned DEFAULT 0,
  `published` tinyint(1) unsigned DEFAULT 1,
  `creationDate` int(11) unsigned DEFAULT NULL,
  `modificationDate` int(11) unsigned DEFAULT NULL,
  `userOwner` int(11) unsigned DEFAULT NULL,
  `userModification` int(11) unsigned DEFAULT NULL,
  `classId` varchar(50) DEFAULT NULL,
  `className` varchar(255) DEFAULT NULL,
  `childrenSortBy` enum('key','index') DEFAULT NULL,
  `childrenSortOrder` enum('ASC','DESC') DEFAULT NULL,
  `versionCount` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fullpath` (`path`,`key`),
  KEY `key` (`key`),
  KEY `index` (`index`),
  KEY `published` (`published`),
  KEY `parentId` (`parentId`),
  KEY `type_path_classId` (`type`,`path`,`classId`),
  KEY `modificationDate` (`modificationDate`),
  KEY `classId` (`classId`),
  KEY `versionCount` (`versionCount`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `objects`
--

LOCK TABLES `objects` WRITE;
/*!40000 ALTER TABLE `objects` DISABLE KEYS */;
INSERT INTO `objects` VALUES
(1,0,'folder','','/',999999,1,1760512442,1760512442,1,1,NULL,NULL,NULL,NULL,0),
(2,1,'folder','positions','/',0,1,1760513186,1760513186,2,2,NULL,NULL,NULL,NULL,2),
(3,1,'folder','applications','/',0,1,1760513195,1760513195,2,2,NULL,NULL,NULL,NULL,2),
(4,1,'folder','categories','/',0,1,1760513201,1760514802,2,2,NULL,NULL,NULL,NULL,3),
(5,4,'object','hr','/categories/',0,1,1760513208,1760513314,2,2,'job_category','JobCategory',NULL,NULL,6),
(6,4,'object','it','/categories/',0,1,1760513215,1760513315,2,2,'job_category','JobCategory',NULL,NULL,4),
(7,4,'object','staff','/categories/',0,1,1760513221,1760513315,2,2,'job_category','JobCategory',NULL,NULL,4),
(8,2,'object','backend-dev','/positions/',0,1,1760513818,1760515048,2,2,'position','Position',NULL,NULL,7),
(9,2,'object','frontend-dev','/positions/',0,1,1760514318,1760515118,2,2,'position','Position',NULL,NULL,8),
(10,2,'object','devops','/positions/',0,1,1760514369,1760515096,2,2,'position','Position',NULL,NULL,6),
(11,2,'object','product-manager','/positions/',0,1,1760514413,1760515151,2,2,'position','Position',NULL,NULL,7),
(12,4,'object','product','/categories/',0,1,1760514440,1760514800,2,2,'job_category','JobCategory',NULL,NULL,4),
(13,2,'object','hr-generalist','/positions/',0,1,1760514478,1760515130,2,2,'position','Position',NULL,NULL,6),
(14,2,'object','data-scientist','/positions/',0,1,1760514626,1760515085,2,2,'position','Position',NULL,NULL,6),
(15,2,'object','ux-designer','/positions/',0,1,1760514659,1760515017,2,2,'position','Position',NULL,NULL,5),
(16,4,'object','design','/categories/',0,1,1760514678,1760514800,2,2,'job_category','JobCategory',NULL,NULL,4),
(17,2,'object','automation-engineer','/positions/',0,1,1760514705,1760515017,2,2,'position','Position',NULL,NULL,4),
(18,2,'object','technical-support-engineer','/positions/',0,1,1760514738,1760515018,2,2,'position','Position',NULL,NULL,4),
(19,4,'object','marketing','/categories/',0,1,1760514761,1760514801,2,2,'job_category','JobCategory',NULL,NULL,4),
(20,2,'object','marketing-specialist','/positions/',0,1,1760514777,1760515141,2,2,'position','Position',NULL,NULL,8),
(21,3,'object','application-1','/applications/',0,1,1760515344,1760515386,2,2,'application','Application',NULL,NULL,4),
(22,3,'object','application-2','/applications/',0,1,1760515397,1760515444,2,2,'application','Application',NULL,NULL,4);
/*!40000 ALTER TABLE `objects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `properties`
--

DROP TABLE IF EXISTS `properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `properties` (
  `cid` int(11) unsigned NOT NULL DEFAULT 0,
  `ctype` enum('document','asset','object') NOT NULL DEFAULT 'document',
  `cpath` varchar(765) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `name` varchar(190) NOT NULL DEFAULT '',
  `type` enum('text','document','asset','object','bool','select') DEFAULT NULL,
  `data` text DEFAULT NULL,
  `inheritable` tinyint(1) unsigned DEFAULT 1,
  PRIMARY KEY (`cid`,`ctype`,`name`),
  KEY `getall` (`cpath`,`ctype`,`inheritable`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `properties`
--

LOCK TABLES `properties` WRITE;
/*!40000 ALTER TABLE `properties` DISABLE KEYS */;
/*!40000 ALTER TABLE `properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quantityvalue_units`
--

DROP TABLE IF EXISTS `quantityvalue_units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `quantityvalue_units` (
  `id` varchar(50) NOT NULL,
  `group` varchar(50) DEFAULT NULL,
  `abbreviation` varchar(20) DEFAULT NULL,
  `longname` varchar(250) DEFAULT NULL,
  `baseunit` varchar(50) DEFAULT NULL,
  `factor` double DEFAULT NULL,
  `conversionOffset` double DEFAULT NULL,
  `reference` varchar(50) DEFAULT NULL,
  `converter` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_baseunit` (`baseunit`),
  CONSTRAINT `fk_baseunit` FOREIGN KEY (`baseunit`) REFERENCES `quantityvalue_units` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quantityvalue_units`
--

LOCK TABLES `quantityvalue_units` WRITE;
/*!40000 ALTER TABLE `quantityvalue_units` DISABLE KEYS */;
/*!40000 ALTER TABLE `quantityvalue_units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recyclebin`
--

DROP TABLE IF EXISTS `recyclebin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `recyclebin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) DEFAULT NULL,
  `subtype` varchar(20) DEFAULT NULL,
  `path` varchar(765) DEFAULT NULL,
  `amount` int(3) DEFAULT NULL,
  `date` int(11) unsigned DEFAULT NULL,
  `deletedby` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recyclebin_date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recyclebin`
--

LOCK TABLES `recyclebin` WRITE;
/*!40000 ALTER TABLE `recyclebin` DISABLE KEYS */;
/*!40000 ALTER TABLE `recyclebin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `redirects`
--

DROP TABLE IF EXISTS `redirects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirects` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('entire_uri','path_query','path','auto_create') NOT NULL,
  `source` varchar(255) DEFAULT NULL,
  `sourceSite` int(11) DEFAULT NULL,
  `target` varchar(255) DEFAULT NULL,
  `targetSite` int(11) DEFAULT NULL,
  `statusCode` varchar(3) DEFAULT NULL,
  `priority` int(2) DEFAULT 0,
  `regex` tinyint(1) DEFAULT NULL,
  `passThroughParameters` tinyint(1) DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `expiry` int(11) unsigned DEFAULT NULL,
  `creationDate` int(11) unsigned DEFAULT 0,
  `modificationDate` int(11) unsigned DEFAULT 0,
  `userOwner` int(11) unsigned DEFAULT NULL,
  `userModification` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `priority` (`priority`),
  KEY `routing_lookup` (`active`,`regex`,`sourceSite`,`source`,`type`,`expiry`,`priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `redirects`
--

LOCK TABLES `redirects` WRITE;
/*!40000 ALTER TABLE `redirects` DISABLE KEYS */;
/*!40000 ALTER TABLE `redirects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule_tasks`
--

DROP TABLE IF EXISTS `schedule_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedule_tasks` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cid` int(11) unsigned DEFAULT NULL,
  `ctype` enum('document','asset','object') DEFAULT NULL,
  `date` int(11) unsigned DEFAULT NULL,
  `action` enum('publish','unpublish','delete','publish-version') DEFAULT NULL,
  `version` bigint(20) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT 0,
  `userId` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cid` (`cid`),
  KEY `ctype` (`ctype`),
  KEY `active` (`active`),
  KEY `version` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule_tasks`
--

LOCK TABLES `schedule_tasks` WRITE;
/*!40000 ALTER TABLE `schedule_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `schedule_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `search_backend_data`
--

DROP TABLE IF EXISTS `search_backend_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `search_backend_data` (
  `id` int(11) NOT NULL,
  `key` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT '',
  `index` int(11) unsigned DEFAULT 0,
  `fullpath` varchar(765) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `maintype` varchar(8) NOT NULL DEFAULT '',
  `type` varchar(20) DEFAULT NULL,
  `subtype` varchar(190) DEFAULT NULL,
  `published` tinyint(1) unsigned DEFAULT NULL,
  `creationDate` int(11) unsigned DEFAULT NULL,
  `modificationDate` int(11) unsigned DEFAULT NULL,
  `userOwner` int(11) DEFAULT NULL,
  `userModification` int(11) DEFAULT NULL,
  `data` longtext DEFAULT NULL,
  `properties` text DEFAULT NULL,
  PRIMARY KEY (`id`,`maintype`),
  KEY `key` (`key`),
  KEY `index` (`index`),
  KEY `fullpath` (`fullpath`),
  KEY `maintype` (`maintype`),
  KEY `type` (`type`),
  KEY `subtype` (`subtype`),
  KEY `published` (`published`),
  FULLTEXT KEY `fulltext` (`data`,`properties`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_backend_data`
--

LOCK TABLES `search_backend_data` WRITE;
/*!40000 ALTER TABLE `search_backend_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `search_backend_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings_store`
--

DROP TABLE IF EXISTS `settings_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings_store` (
  `id` varchar(190) NOT NULL DEFAULT '',
  `scope` varchar(190) NOT NULL DEFAULT '',
  `data` longtext DEFAULT NULL,
  `type` enum('bool','int','float','string') NOT NULL DEFAULT 'string',
  PRIMARY KEY (`id`,`scope`),
  KEY `scope` (`scope`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings_store`
--

LOCK TABLES `settings_store` WRITE;
/*!40000 ALTER TABLE `settings_store` DISABLE KEYS */;
INSERT INTO `settings_store` VALUES
('BUNDLE_INSTALLED__Pimcore\\Bundle\\AdminBundle\\PimcoreAdminBundle','pimcore','1','bool'),
('BUNDLE_INSTALLED__Pimcore\\Bundle\\SeoBundle\\PimcoreSeoBundle','pimcore','1','bool'),
('BUNDLE_INSTALLED__Pimcore\\Bundle\\SimpleBackendSearchBundle\\PimcoreSimpleBackendSearchBundle','pimcore','1','bool');
/*!40000 ALTER TABLE `settings_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `mainDomain` varchar(255) DEFAULT NULL,
  `domains` text DEFAULT NULL,
  `rootId` int(11) unsigned DEFAULT NULL,
  `errorDocument` varchar(255) DEFAULT NULL,
  `localizedErrorDocuments` text DEFAULT NULL,
  `redirectToMainDomain` tinyint(1) DEFAULT NULL,
  `creationDate` int(11) unsigned DEFAULT 0,
  `modificationDate` int(11) unsigned DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rootId` (`rootId`),
  CONSTRAINT `fk_sites_documents` FOREIGN KEY (`rootId`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parentId` int(10) unsigned DEFAULT NULL,
  `idPath` varchar(190) DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idPath_name` (`idPath`,`name`),
  KEY `idpath` (`idPath`),
  KEY `parentid` (`parentId`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags_assignment`
--

DROP TABLE IF EXISTS `tags_assignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags_assignment` (
  `tagid` int(10) unsigned NOT NULL DEFAULT 0,
  `cid` int(10) NOT NULL DEFAULT 0,
  `ctype` enum('document','asset','object') NOT NULL,
  PRIMARY KEY (`tagid`,`cid`,`ctype`),
  KEY `ctype` (`ctype`),
  KEY `ctype_cid` (`cid`,`ctype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags_assignment`
--

LOCK TABLES `tags_assignment` WRITE;
/*!40000 ALTER TABLE `tags_assignment` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags_assignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tmp_store`
--

DROP TABLE IF EXISTS `tmp_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmp_store` (
  `id` varchar(190) NOT NULL DEFAULT '',
  `tag` varchar(190) DEFAULT NULL,
  `data` longtext DEFAULT NULL,
  `serialized` tinyint(2) NOT NULL DEFAULT 0,
  `date` int(11) unsigned DEFAULT NULL,
  `expiryDate` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tag` (`tag`),
  KEY `date` (`date`),
  KEY `expiryDate` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmp_store`
--

LOCK TABLES `tmp_store` WRITE;
/*!40000 ALTER TABLE `tmp_store` DISABLE KEYS */;
/*!40000 ALTER TABLE `tmp_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `translations_admin`
--

DROP TABLE IF EXISTS `translations_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `translations_admin` (
  `key` varchar(190) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `type` varchar(10) DEFAULT NULL,
  `language` varchar(10) NOT NULL DEFAULT '',
  `text` text DEFAULT NULL,
  `creationDate` int(11) unsigned DEFAULT NULL,
  `modificationDate` int(11) unsigned DEFAULT NULL,
  `userOwner` int(11) unsigned DEFAULT NULL,
  `userModification` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`key`,`language`),
  KEY `language` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `translations_admin`
--

LOCK TABLES `translations_admin` WRITE;
/*!40000 ALTER TABLE `translations_admin` DISABLE KEYS */;
INSERT INTO `translations_admin` VALUES
('Another saving process is in progress, please wait and retry again','simple','ca','',1760515176,1760515176,2,2),
('Another saving process is in progress, please wait and retry again','simple','cs','',1760515176,1760515176,2,2),
('Another saving process is in progress, please wait and retry again','simple','de','',1760515176,1760515176,2,2),
('Another saving process is in progress, please wait and retry again','simple','en','',1760515176,1760515176,2,2),
('Another saving process is in progress, please wait and retry again','simple','es','',1760515176,1760515176,2,2),
('Another saving process is in progress, please wait and retry again','simple','fr','',1760515176,1760515176,2,2),
('Another saving process is in progress, please wait and retry again','simple','hu','',1760515176,1760515176,2,2),
('Another saving process is in progress, please wait and retry again','simple','it','',1760515176,1760515176,2,2),
('Another saving process is in progress, please wait and retry again','simple','ja','',1760515176,1760515176,2,2),
('Another saving process is in progress, please wait and retry again','simple','nl','',1760515176,1760515176,2,2),
('Another saving process is in progress, please wait and retry again','simple','pl','',1760515176,1760515176,2,2),
('Another saving process is in progress, please wait and retry again','simple','pt','',1760515176,1760515176,2,2),
('Another saving process is in progress, please wait and retry again','simple','ru','',1760515176,1760515176,2,2),
('Another saving process is in progress, please wait and retry again','simple','sk','',1760515176,1760515176,2,2),
('Another saving process is in progress, please wait and retry again','simple','sv','',1760515176,1760515176,2,2),
('Another saving process is in progress, please wait and retry again','simple','th','',1760515176,1760515176,2,2),
('Another saving process is in progress, please wait and retry again','simple','tr','',1760515176,1760515176,2,2),
('Another saving process is in progress, please wait and retry again','simple','uk','',1760515176,1760515176,2,2),
('Another saving process is in progress, please wait and retry again','simple','zh_Hans','',1760515176,1760515176,2,2),
('Application','simple','ca','Application',1760512838,1760512838,2,2),
('Application','simple','cs','Application',1760512838,1760512838,2,2),
('Application','simple','de','Application',1760512838,1760512838,2,2),
('Application','simple','en','Application',1760512838,1760512838,2,2),
('Application','simple','es','Application',1760512838,1760512838,2,2),
('Application','simple','fr','Application',1760512838,1760512838,2,2),
('Application','simple','hu','Application',1760512838,1760512838,2,2),
('Application','simple','it','Application',1760512838,1760512838,2,2),
('Application','simple','ja','Application',1760512838,1760512838,2,2),
('Application','simple','nl','Application',1760512838,1760512838,2,2),
('Application','simple','pl','Application',1760512838,1760512838,2,2),
('Application','simple','pt','Application',1760512838,1760512838,2,2),
('Application','simple','ru','Application',1760512838,1760512838,2,2),
('Application','simple','sk','Application',1760512838,1760512838,2,2),
('Application','simple','sv','Application',1760512838,1760512838,2,2),
('Application','simple','th','Application',1760512838,1760512838,2,2),
('Application','simple','tr','Application',1760512838,1760512838,2,2),
('Application','simple','uk','Application',1760512838,1760512838,2,2),
('Application','simple','zh_Hans','Application',1760512838,1760512838,2,2),
('Applications','simple','ca','',1760514187,1760514187,2,2),
('Applications','simple','cs','',1760514187,1760514187,2,2),
('Applications','simple','de','',1760514187,1760514187,2,2),
('Applications','simple','en','',1760514187,1760514187,2,2),
('Applications','simple','es','',1760514187,1760514187,2,2),
('Applications','simple','fr','',1760514187,1760514187,2,2),
('Applications','simple','hu','',1760514187,1760514187,2,2),
('Applications','simple','it','',1760514187,1760514187,2,2),
('Applications','simple','ja','',1760514187,1760514187,2,2),
('Applications','simple','nl','',1760514187,1760514187,2,2),
('Applications','simple','pl','',1760514187,1760514187,2,2),
('Applications','simple','pt','',1760514187,1760514187,2,2),
('Applications','simple','ru','',1760514187,1760514187,2,2),
('Applications','simple','sk','',1760514187,1760514187,2,2),
('Applications','simple','sv','',1760514187,1760514187,2,2),
('Applications','simple','th','',1760514187,1760514187,2,2),
('Applications','simple','tr','',1760514187,1760514187,2,2),
('Applications','simple','uk','',1760514187,1760514187,2,2),
('Applications','simple','zh_Hans','',1760514187,1760514187,2,2),
('CSV Export','simple','ca','',1760513316,1760513316,2,2),
('CSV Export','simple','cs','',1760513316,1760513316,2,2),
('CSV Export','simple','de','',1760513316,1760513316,2,2),
('CSV Export','simple','en','',1760513316,1760513316,2,2),
('CSV Export','simple','es','',1760513316,1760513316,2,2),
('CSV Export','simple','fr','',1760513316,1760513316,2,2),
('CSV Export','simple','hu','',1760513316,1760513316,2,2),
('CSV Export','simple','it','',1760513316,1760513316,2,2),
('CSV Export','simple','ja','',1760513316,1760513316,2,2),
('CSV Export','simple','nl','',1760513316,1760513316,2,2),
('CSV Export','simple','pl','',1760513316,1760513316,2,2),
('CSV Export','simple','pt','',1760513316,1760513316,2,2),
('CSV Export','simple','ru','',1760513316,1760513316,2,2),
('CSV Export','simple','sk','',1760513316,1760513316,2,2),
('CSV Export','simple','sv','',1760513316,1760513316,2,2),
('CSV Export','simple','th','',1760513316,1760513316,2,2),
('CSV Export','simple','tr','',1760513316,1760513316,2,2),
('CSV Export','simple','uk','',1760513316,1760513316,2,2),
('CSV Export','simple','zh_Hans','',1760513316,1760513316,2,2),
('Categories','simple','ca','',1760513826,1760513826,2,2),
('Categories','simple','cs','',1760513826,1760513826,2,2),
('Categories','simple','de','',1760513826,1760513826,2,2),
('Categories','simple','en','',1760513826,1760513826,2,2),
('Categories','simple','es','',1760513826,1760513826,2,2),
('Categories','simple','fr','',1760513826,1760513826,2,2),
('Categories','simple','hu','',1760513826,1760513826,2,2),
('Categories','simple','it','',1760513826,1760513826,2,2),
('Categories','simple','ja','',1760513826,1760513826,2,2),
('Categories','simple','nl','',1760513826,1760513826,2,2),
('Categories','simple','pl','',1760513826,1760513826,2,2),
('Categories','simple','pt','',1760513826,1760513826,2,2),
('Categories','simple','ru','',1760513826,1760513826,2,2),
('Categories','simple','sk','',1760513826,1760513826,2,2),
('Categories','simple','sv','',1760513826,1760513826,2,2),
('Categories','simple','th','',1760513826,1760513826,2,2),
('Categories','simple','tr','',1760513826,1760513826,2,2),
('Categories','simple','uk','',1760513826,1760513826,2,2),
('Categories','simple','zh_Hans','',1760513826,1760513826,2,2),
('English','simple','ca','',1760513208,1760513208,2,2),
('English','simple','cs','',1760513208,1760513208,2,2),
('English','simple','de','',1760513208,1760513208,2,2),
('English','simple','en','',1760513208,1760513208,2,2),
('English','simple','es','',1760513208,1760513208,2,2),
('English','simple','fr','',1760513208,1760513208,2,2),
('English','simple','hu','',1760513208,1760513208,2,2),
('English','simple','it','',1760513208,1760513208,2,2),
('English','simple','ja','',1760513208,1760513208,2,2),
('English','simple','nl','',1760513208,1760513208,2,2),
('English','simple','pl','',1760513208,1760513208,2,2),
('English','simple','pt','',1760513208,1760513208,2,2),
('English','simple','ru','',1760513208,1760513208,2,2),
('English','simple','sk','',1760513208,1760513208,2,2),
('English','simple','sv','',1760513208,1760513208,2,2),
('English','simple','th','',1760513208,1760513208,2,2),
('English','simple','tr','',1760513208,1760513208,2,2),
('English','simple','uk','',1760513208,1760513208,2,2),
('English','simple','zh_Hans','',1760513208,1760513208,2,2),
('French','simple','ca','',1760513208,1760513208,2,2),
('French','simple','cs','',1760513208,1760513208,2,2),
('French','simple','de','',1760513208,1760513208,2,2),
('French','simple','en','',1760513208,1760513208,2,2),
('French','simple','es','',1760513208,1760513208,2,2),
('French','simple','fr','',1760513208,1760513208,2,2),
('French','simple','hu','',1760513208,1760513208,2,2),
('French','simple','it','',1760513208,1760513208,2,2),
('French','simple','ja','',1760513208,1760513208,2,2),
('French','simple','nl','',1760513208,1760513208,2,2),
('French','simple','pl','',1760513208,1760513208,2,2),
('French','simple','pt','',1760513208,1760513208,2,2),
('French','simple','ru','',1760513208,1760513208,2,2),
('French','simple','sk','',1760513208,1760513208,2,2),
('French','simple','sv','',1760513208,1760513208,2,2),
('French','simple','th','',1760513208,1760513208,2,2),
('French','simple','tr','',1760513208,1760513208,2,2),
('French','simple','uk','',1760513208,1760513208,2,2),
('French','simple','zh_Hans','',1760513208,1760513208,2,2),
('General','simple','ca','',1760513826,1760513826,2,2),
('General','simple','cs','',1760513826,1760513826,2,2),
('General','simple','de','',1760513826,1760513826,2,2),
('General','simple','en','',1760513826,1760513826,2,2),
('General','simple','es','',1760513826,1760513826,2,2),
('General','simple','fr','',1760513826,1760513826,2,2),
('General','simple','hu','',1760513826,1760513826,2,2),
('General','simple','it','',1760513826,1760513826,2,2),
('General','simple','ja','',1760513826,1760513826,2,2),
('General','simple','nl','',1760513826,1760513826,2,2),
('General','simple','pl','',1760513826,1760513826,2,2),
('General','simple','pt','',1760513826,1760513826,2,2),
('General','simple','ru','',1760513826,1760513826,2,2),
('General','simple','sk','',1760513826,1760513826,2,2),
('General','simple','sv','',1760513826,1760513826,2,2),
('General','simple','th','',1760513826,1760513826,2,2),
('General','simple','tr','',1760513826,1760513826,2,2),
('General','simple','uk','',1760513826,1760513826,2,2),
('General','simple','zh_Hans','',1760513826,1760513826,2,2),
('German','simple','ca','',1760513208,1760513208,2,2),
('German','simple','cs','',1760513208,1760513208,2,2),
('German','simple','de','',1760513208,1760513208,2,2),
('German','simple','en','',1760513208,1760513208,2,2),
('German','simple','es','',1760513208,1760513208,2,2),
('German','simple','fr','',1760513208,1760513208,2,2),
('German','simple','hu','',1760513208,1760513208,2,2),
('German','simple','it','',1760513208,1760513208,2,2),
('German','simple','ja','',1760513208,1760513208,2,2),
('German','simple','nl','',1760513208,1760513208,2,2),
('German','simple','pl','',1760513208,1760513208,2,2),
('German','simple','pt','',1760513208,1760513208,2,2),
('German','simple','ru','',1760513208,1760513208,2,2),
('German','simple','sk','',1760513208,1760513208,2,2),
('German','simple','sv','',1760513208,1760513208,2,2),
('German','simple','th','',1760513208,1760513208,2,2),
('German','simple','tr','',1760513208,1760513208,2,2),
('German','simple','uk','',1760513208,1760513208,2,2),
('German','simple','zh_Hans','',1760513208,1760513208,2,2),
('HTML Edit','simple','ca','',1760513826,1760513826,2,2),
('HTML Edit','simple','cs','',1760513826,1760513826,2,2),
('HTML Edit','simple','de','',1760513826,1760513826,2,2),
('HTML Edit','simple','en','',1760513826,1760513826,2,2),
('HTML Edit','simple','es','',1760513826,1760513826,2,2),
('HTML Edit','simple','fr','',1760513826,1760513826,2,2),
('HTML Edit','simple','hu','',1760513826,1760513826,2,2),
('HTML Edit','simple','it','',1760513826,1760513826,2,2),
('HTML Edit','simple','ja','',1760513826,1760513826,2,2),
('HTML Edit','simple','nl','',1760513826,1760513826,2,2),
('HTML Edit','simple','pl','',1760513826,1760513826,2,2),
('HTML Edit','simple','pt','',1760513826,1760513826,2,2),
('HTML Edit','simple','ru','',1760513826,1760513826,2,2),
('HTML Edit','simple','sk','',1760513826,1760513826,2,2),
('HTML Edit','simple','sv','',1760513826,1760513826,2,2),
('HTML Edit','simple','th','',1760513826,1760513826,2,2),
('HTML Edit','simple','tr','',1760513826,1760513826,2,2),
('HTML Edit','simple','uk','',1760513826,1760513826,2,2),
('HTML Edit','simple','zh_Hans','',1760513826,1760513826,2,2),
('Italian','simple','ca','',1760513316,1760513316,2,2),
('Italian','simple','cs','',1760513316,1760513316,2,2),
('Italian','simple','de','',1760513316,1760513316,2,2),
('Italian','simple','en','',1760513316,1760513316,2,2),
('Italian','simple','es','',1760513316,1760513316,2,2),
('Italian','simple','fr','',1760513316,1760513316,2,2),
('Italian','simple','hu','',1760513316,1760513316,2,2),
('Italian','simple','it','',1760513316,1760513316,2,2),
('Italian','simple','ja','',1760513316,1760513316,2,2),
('Italian','simple','nl','',1760513316,1760513316,2,2),
('Italian','simple','pl','',1760513316,1760513316,2,2),
('Italian','simple','pt','',1760513316,1760513316,2,2),
('Italian','simple','ru','',1760513316,1760513316,2,2),
('Italian','simple','sk','',1760513316,1760513316,2,2),
('Italian','simple','sv','',1760513316,1760513316,2,2),
('Italian','simple','th','',1760513316,1760513316,2,2),
('Italian','simple','tr','',1760513316,1760513316,2,2),
('Italian','simple','uk','',1760513316,1760513316,2,2),
('Italian','simple','zh_Hans','',1760513316,1760513316,2,2),
('Job','simple','ca','Job',1760512864,1760512864,2,2),
('Job','simple','cs','Job',1760512864,1760512864,2,2),
('Job','simple','de','Job',1760512864,1760512864,2,2),
('Job','simple','en','Job',1760512864,1760512864,2,2),
('Job','simple','es','Job',1760512864,1760512864,2,2),
('Job','simple','fr','Job',1760512864,1760512864,2,2),
('Job','simple','hu','Job',1760512864,1760512864,2,2),
('Job','simple','it','Job',1760512864,1760512864,2,2),
('Job','simple','ja','Job',1760512864,1760512864,2,2),
('Job','simple','nl','Job',1760512864,1760512864,2,2),
('Job','simple','pl','Job',1760512864,1760512864,2,2),
('Job','simple','pt','Job',1760512864,1760512864,2,2),
('Job','simple','ru','Job',1760512864,1760512864,2,2),
('Job','simple','sk','Job',1760512864,1760512864,2,2),
('Job','simple','sv','Job',1760512864,1760512864,2,2),
('Job','simple','th','Job',1760512864,1760512864,2,2),
('Job','simple','tr','Job',1760512864,1760512864,2,2),
('Job','simple','uk','Job',1760512864,1760512864,2,2),
('Job','simple','zh_Hans','Job',1760512864,1760512864,2,2),
('JobCategory','simple','ca','',1760512878,1760512878,2,2),
('JobCategory','simple','cs','',1760512878,1760512878,2,2),
('JobCategory','simple','de','',1760512878,1760512878,2,2),
('JobCategory','simple','en','',1760512878,1760512878,2,2),
('JobCategory','simple','es','',1760512878,1760512878,2,2),
('JobCategory','simple','fr','',1760512878,1760512878,2,2),
('JobCategory','simple','hu','',1760512878,1760512878,2,2),
('JobCategory','simple','it','',1760512878,1760512878,2,2),
('JobCategory','simple','ja','',1760512878,1760512878,2,2),
('JobCategory','simple','nl','',1760512878,1760512878,2,2),
('JobCategory','simple','pl','',1760512878,1760512878,2,2),
('JobCategory','simple','pt','',1760512878,1760512878,2,2),
('JobCategory','simple','ru','',1760512878,1760512878,2,2),
('JobCategory','simple','sk','',1760512878,1760512878,2,2),
('JobCategory','simple','sv','',1760512878,1760512878,2,2),
('JobCategory','simple','th','',1760512878,1760512878,2,2),
('JobCategory','simple','tr','',1760512878,1760512878,2,2),
('JobCategory','simple','uk','',1760512878,1760512878,2,2),
('JobCategory','simple','zh_Hans','',1760512878,1760512878,2,2),
('Main','simple','ca','',1760513208,1760513208,2,2),
('Main','simple','cs','',1760513208,1760513208,2,2),
('Main','simple','de','',1760513208,1760513208,2,2),
('Main','simple','en','',1760513208,1760513208,2,2),
('Main','simple','es','',1760513208,1760513208,2,2),
('Main','simple','fr','',1760513208,1760513208,2,2),
('Main','simple','hu','',1760513208,1760513208,2,2),
('Main','simple','it','',1760513208,1760513208,2,2),
('Main','simple','ja','',1760513208,1760513208,2,2),
('Main','simple','nl','',1760513208,1760513208,2,2),
('Main','simple','pl','',1760513208,1760513208,2,2),
('Main','simple','pt','',1760513208,1760513208,2,2),
('Main','simple','ru','',1760513208,1760513208,2,2),
('Main','simple','sk','',1760513208,1760513208,2,2),
('Main','simple','sv','',1760513208,1760513208,2,2),
('Main','simple','th','',1760513208,1760513208,2,2),
('Main','simple','tr','',1760513208,1760513208,2,2),
('Main','simple','uk','',1760513208,1760513208,2,2),
('Main','simple','zh_Hans','',1760513208,1760513208,2,2),
('Main (Admin Mode)','simple','ca','',1760513208,1760513208,2,2),
('Main (Admin Mode)','simple','cs','',1760513208,1760513208,2,2),
('Main (Admin Mode)','simple','de','',1760513208,1760513208,2,2),
('Main (Admin Mode)','simple','en','',1760513208,1760513208,2,2),
('Main (Admin Mode)','simple','es','',1760513208,1760513208,2,2),
('Main (Admin Mode)','simple','fr','',1760513208,1760513208,2,2),
('Main (Admin Mode)','simple','hu','',1760513208,1760513208,2,2),
('Main (Admin Mode)','simple','it','',1760513208,1760513208,2,2),
('Main (Admin Mode)','simple','ja','',1760513208,1760513208,2,2),
('Main (Admin Mode)','simple','nl','',1760513208,1760513208,2,2),
('Main (Admin Mode)','simple','pl','',1760513208,1760513208,2,2),
('Main (Admin Mode)','simple','pt','',1760513208,1760513208,2,2),
('Main (Admin Mode)','simple','ru','',1760513208,1760513208,2,2),
('Main (Admin Mode)','simple','sk','',1760513208,1760513208,2,2),
('Main (Admin Mode)','simple','sv','',1760513208,1760513208,2,2),
('Main (Admin Mode)','simple','th','',1760513208,1760513208,2,2),
('Main (Admin Mode)','simple','tr','',1760513208,1760513208,2,2),
('Main (Admin Mode)','simple','uk','',1760513208,1760513208,2,2),
('Main (Admin Mode)','simple','zh_Hans','',1760513208,1760513208,2,2),
('Milano','simple','ca','',1760513826,1760513826,2,2),
('Milano','simple','cs','',1760513826,1760513826,2,2),
('Milano','simple','de','',1760513826,1760513826,2,2),
('Milano','simple','en','',1760513826,1760513826,2,2),
('Milano','simple','es','',1760513826,1760513826,2,2),
('Milano','simple','fr','',1760513826,1760513826,2,2),
('Milano','simple','hu','',1760513826,1760513826,2,2),
('Milano','simple','it','',1760513826,1760513826,2,2),
('Milano','simple','ja','',1760513826,1760513826,2,2),
('Milano','simple','nl','',1760513826,1760513826,2,2),
('Milano','simple','pl','',1760513826,1760513826,2,2),
('Milano','simple','pt','',1760513826,1760513826,2,2),
('Milano','simple','ru','',1760513826,1760513826,2,2),
('Milano','simple','sk','',1760513826,1760513826,2,2),
('Milano','simple','sv','',1760513826,1760513826,2,2),
('Milano','simple','th','',1760513826,1760513826,2,2),
('Milano','simple','tr','',1760513826,1760513826,2,2),
('Milano','simple','uk','',1760513826,1760513826,2,2),
('Milano','simple','zh_Hans','',1760513826,1760513826,2,2),
('PHP Enum Name','simple','ca','',1760513646,1760513646,2,2),
('PHP Enum Name','simple','cs','',1760513646,1760513646,2,2),
('PHP Enum Name','simple','de','',1760513646,1760513646,2,2),
('PHP Enum Name','simple','en','',1760513646,1760513646,2,2),
('PHP Enum Name','simple','es','',1760513646,1760513646,2,2),
('PHP Enum Name','simple','fr','',1760513646,1760513646,2,2),
('PHP Enum Name','simple','hu','',1760513646,1760513646,2,2),
('PHP Enum Name','simple','it','',1760513646,1760513646,2,2),
('PHP Enum Name','simple','ja','',1760513646,1760513646,2,2),
('PHP Enum Name','simple','nl','',1760513646,1760513646,2,2),
('PHP Enum Name','simple','pl','',1760513646,1760513646,2,2),
('PHP Enum Name','simple','pt','',1760513646,1760513646,2,2),
('PHP Enum Name','simple','ru','',1760513646,1760513646,2,2),
('PHP Enum Name','simple','sk','',1760513646,1760513646,2,2),
('PHP Enum Name','simple','sv','',1760513646,1760513646,2,2),
('PHP Enum Name','simple','th','',1760513646,1760513646,2,2),
('PHP Enum Name','simple','tr','',1760513646,1760513646,2,2),
('PHP Enum Name','simple','uk','',1760513646,1760513646,2,2),
('PHP Enum Name','simple','zh_Hans','',1760513646,1760513646,2,2),
('Padova','simple','ca','',1760513826,1760513826,2,2),
('Padova','simple','cs','',1760513826,1760513826,2,2),
('Padova','simple','de','',1760513826,1760513826,2,2),
('Padova','simple','en','',1760513826,1760513826,2,2),
('Padova','simple','es','',1760513826,1760513826,2,2),
('Padova','simple','fr','',1760513826,1760513826,2,2),
('Padova','simple','hu','',1760513826,1760513826,2,2),
('Padova','simple','it','',1760513826,1760513826,2,2),
('Padova','simple','ja','',1760513826,1760513826,2,2),
('Padova','simple','nl','',1760513826,1760513826,2,2),
('Padova','simple','pl','',1760513826,1760513826,2,2),
('Padova','simple','pt','',1760513826,1760513826,2,2),
('Padova','simple','ru','',1760513826,1760513826,2,2),
('Padova','simple','sk','',1760513826,1760513826,2,2),
('Padova','simple','sv','',1760513826,1760513826,2,2),
('Padova','simple','th','',1760513826,1760513826,2,2),
('Padova','simple','tr','',1760513826,1760513826,2,2),
('Padova','simple','uk','',1760513826,1760513826,2,2),
('Padova','simple','zh_Hans','',1760513826,1760513826,2,2),
('Pimcore\'s logotype','simple','de','',1760512813,1760512813,0,0),
('Pimcore\'s logotype','simple','en','',1760512813,1760512813,0,0),
('Pimcore\'s logotype','simple','fr','',1760512813,1760512813,0,0),
('Position','simple','ca','Position',1760512883,1760512883,2,2),
('Position','simple','cs','Position',1760512883,1760512883,2,2),
('Position','simple','de','Position',1760512883,1760512883,2,2),
('Position','simple','en','Position',1760512883,1760512883,2,2),
('Position','simple','es','Position',1760512883,1760512883,2,2),
('Position','simple','fr','Position',1760512883,1760512883,2,2),
('Position','simple','hu','Position',1760512883,1760512883,2,2),
('Position','simple','it','Position',1760512883,1760512883,2,2),
('Position','simple','ja','Position',1760512883,1760512883,2,2),
('Position','simple','nl','Position',1760512883,1760512883,2,2),
('Position','simple','pl','Position',1760512883,1760512883,2,2),
('Position','simple','pt','Position',1760512883,1760512883,2,2),
('Position','simple','ru','Position',1760512883,1760512883,2,2),
('Position','simple','sk','Position',1760512883,1760512883,2,2),
('Position','simple','sv','Position',1760512883,1760512883,2,2),
('Position','simple','th','Position',1760512883,1760512883,2,2),
('Position','simple','tr','Position',1760512883,1760512883,2,2),
('Position','simple','uk','Position',1760512883,1760512883,2,2),
('Position','simple','zh_Hans','Position',1760512883,1760512883,2,2),
('Positions','simple','ca','',1760513208,1760513208,2,2),
('Positions','simple','cs','',1760513208,1760513208,2,2),
('Positions','simple','de','',1760513208,1760513208,2,2),
('Positions','simple','en','',1760513208,1760513208,2,2),
('Positions','simple','es','',1760513208,1760513208,2,2),
('Positions','simple','fr','',1760513208,1760513208,2,2),
('Positions','simple','hu','',1760513208,1760513208,2,2),
('Positions','simple','it','',1760513208,1760513208,2,2),
('Positions','simple','ja','',1760513208,1760513208,2,2),
('Positions','simple','nl','',1760513208,1760513208,2,2),
('Positions','simple','pl','',1760513208,1760513208,2,2),
('Positions','simple','pt','',1760513208,1760513208,2,2),
('Positions','simple','ru','',1760513208,1760513208,2,2),
('Positions','simple','sk','',1760513208,1760513208,2,2),
('Positions','simple','sv','',1760513208,1760513208,2,2),
('Positions','simple','th','',1760513208,1760513208,2,2),
('Positions','simple','tr','',1760513208,1760513208,2,2),
('Positions','simple','uk','',1760513208,1760513208,2,2),
('Positions','simple','zh_Hans','',1760513208,1760513208,2,2),
('Privacy','simple','ca','',1760515356,1760515356,2,2),
('Privacy','simple','cs','',1760515356,1760515356,2,2),
('Privacy','simple','de','',1760515356,1760515356,2,2),
('Privacy','simple','en','',1760515356,1760515356,2,2),
('Privacy','simple','es','',1760515356,1760515356,2,2),
('Privacy','simple','fr','',1760515356,1760515356,2,2),
('Privacy','simple','hu','',1760515356,1760515356,2,2),
('Privacy','simple','it','',1760515356,1760515356,2,2),
('Privacy','simple','ja','',1760515356,1760515356,2,2),
('Privacy','simple','nl','',1760515356,1760515356,2,2),
('Privacy','simple','pl','',1760515356,1760515356,2,2),
('Privacy','simple','pt','',1760515356,1760515356,2,2),
('Privacy','simple','ru','',1760515356,1760515356,2,2),
('Privacy','simple','sk','',1760515356,1760515356,2,2),
('Privacy','simple','sv','',1760515356,1760515356,2,2),
('Privacy','simple','th','',1760515356,1760515356,2,2),
('Privacy','simple','tr','',1760515356,1760515356,2,2),
('Privacy','simple','uk','',1760515356,1760515356,2,2),
('Privacy','simple','zh_Hans','',1760515356,1760515356,2,2),
('Roma','simple','ca','',1760513826,1760513826,2,2),
('Roma','simple','cs','',1760513826,1760513826,2,2),
('Roma','simple','de','',1760513826,1760513826,2,2),
('Roma','simple','en','',1760513826,1760513826,2,2),
('Roma','simple','es','',1760513826,1760513826,2,2),
('Roma','simple','fr','',1760513826,1760513826,2,2),
('Roma','simple','hu','',1760513826,1760513826,2,2),
('Roma','simple','it','',1760513826,1760513826,2,2),
('Roma','simple','ja','',1760513826,1760513826,2,2),
('Roma','simple','nl','',1760513826,1760513826,2,2),
('Roma','simple','pl','',1760513826,1760513826,2,2),
('Roma','simple','pt','',1760513826,1760513826,2,2),
('Roma','simple','ru','',1760513826,1760513826,2,2),
('Roma','simple','sk','',1760513826,1760513826,2,2),
('Roma','simple','sv','',1760513826,1760513826,2,2),
('Roma','simple','th','',1760513826,1760513826,2,2),
('Roma','simple','tr','',1760513826,1760513826,2,2),
('Roma','simple','uk','',1760513826,1760513826,2,2),
('Roma','simple','zh_Hans','',1760513826,1760513826,2,2),
('Site','simple','ca','Site',1760513583,1760513583,2,2),
('Site','simple','cs','Site',1760513583,1760513583,2,2),
('Site','simple','de','Site',1760513583,1760513583,2,2),
('Site','simple','en','Site',1760513583,1760513583,2,2),
('Site','simple','es','Site',1760513583,1760513583,2,2),
('Site','simple','fr','Site',1760513583,1760513583,2,2),
('Site','simple','hu','Site',1760513583,1760513583,2,2),
('Site','simple','it','Site',1760513583,1760513583,2,2),
('Site','simple','ja','Site',1760513583,1760513583,2,2),
('Site','simple','nl','Site',1760513583,1760513583,2,2),
('Site','simple','pl','Site',1760513583,1760513583,2,2),
('Site','simple','pt','Site',1760513583,1760513583,2,2),
('Site','simple','ru','Site',1760513583,1760513583,2,2),
('Site','simple','sk','Site',1760513583,1760513583,2,2),
('Site','simple','sv','Site',1760513583,1760513583,2,2),
('Site','simple','th','Site',1760513583,1760513583,2,2),
('Site','simple','tr','Site',1760513583,1760513583,2,2),
('Site','simple','uk','Site',1760513583,1760513583,2,2),
('Site','simple','zh_Hans','Site',1760513583,1760513583,2,2),
('Torino','simple','ca','',1760513826,1760513826,2,2),
('Torino','simple','cs','',1760513826,1760513826,2,2),
('Torino','simple','de','',1760513826,1760513826,2,2),
('Torino','simple','en','',1760513826,1760513826,2,2),
('Torino','simple','es','',1760513826,1760513826,2,2),
('Torino','simple','fr','',1760513826,1760513826,2,2),
('Torino','simple','hu','',1760513826,1760513826,2,2),
('Torino','simple','it','',1760513826,1760513826,2,2),
('Torino','simple','ja','',1760513826,1760513826,2,2),
('Torino','simple','nl','',1760513826,1760513826,2,2),
('Torino','simple','pl','',1760513826,1760513826,2,2),
('Torino','simple','pt','',1760513826,1760513826,2,2),
('Torino','simple','ru','',1760513826,1760513826,2,2),
('Torino','simple','sk','',1760513826,1760513826,2,2),
('Torino','simple','sv','',1760513826,1760513826,2,2),
('Torino','simple','th','',1760513826,1760513826,2,2),
('Torino','simple','tr','',1760513826,1760513826,2,2),
('Torino','simple','uk','',1760513826,1760513826,2,2),
('Torino','simple','zh_Hans','',1760513826,1760513826,2,2),
('XLSX Export','simple','ca','',1760513316,1760513316,2,2),
('XLSX Export','simple','cs','',1760513316,1760513316,2,2),
('XLSX Export','simple','de','',1760513316,1760513316,2,2),
('XLSX Export','simple','en','',1760513316,1760513316,2,2),
('XLSX Export','simple','es','',1760513316,1760513316,2,2),
('XLSX Export','simple','fr','',1760513316,1760513316,2,2),
('XLSX Export','simple','hu','',1760513316,1760513316,2,2),
('XLSX Export','simple','it','',1760513316,1760513316,2,2),
('XLSX Export','simple','ja','',1760513316,1760513316,2,2),
('XLSX Export','simple','nl','',1760513316,1760513316,2,2),
('XLSX Export','simple','pl','',1760513316,1760513316,2,2),
('XLSX Export','simple','pt','',1760513316,1760513316,2,2),
('XLSX Export','simple','ru','',1760513316,1760513316,2,2),
('XLSX Export','simple','sk','',1760513316,1760513316,2,2),
('XLSX Export','simple','sv','',1760513316,1760513316,2,2),
('XLSX Export','simple','th','',1760513316,1760513316,2,2),
('XLSX Export','simple','tr','',1760513316,1760513316,2,2),
('XLSX Export','simple','uk','',1760513316,1760513316,2,2),
('XLSX Export','simple','zh_Hans','',1760513316,1760513316,2,2),
('boolean','simple','ca','',1760514816,1760514816,2,2),
('boolean','simple','cs','',1760514816,1760514816,2,2),
('boolean','simple','de','',1760514816,1760514816,2,2),
('boolean','simple','en','',1760514816,1760514816,2,2),
('boolean','simple','es','',1760514816,1760514816,2,2),
('boolean','simple','fr','',1760514816,1760514816,2,2),
('boolean','simple','hu','',1760514816,1760514816,2,2),
('boolean','simple','it','',1760514816,1760514816,2,2),
('boolean','simple','ja','',1760514816,1760514816,2,2),
('boolean','simple','nl','',1760514816,1760514816,2,2),
('boolean','simple','pl','',1760514816,1760514816,2,2),
('boolean','simple','pt','',1760514816,1760514816,2,2),
('boolean','simple','ru','',1760514816,1760514816,2,2),
('boolean','simple','sk','',1760514816,1760514816,2,2),
('boolean','simple','sv','',1760514816,1760514816,2,2),
('boolean','simple','th','',1760514816,1760514816,2,2),
('boolean','simple','tr','',1760514816,1760514816,2,2),
('boolean','simple','uk','',1760514816,1760514816,2,2),
('boolean','simple','zh_Hans','',1760514816,1760514816,2,2),
('bottom','simple','ca','',1760512938,1760512938,2,2),
('bottom','simple','cs','',1760512938,1760512938,2,2),
('bottom','simple','de','',1760512938,1760512938,2,2),
('bottom','simple','en','',1760512938,1760512938,2,2),
('bottom','simple','es','',1760512938,1760512938,2,2),
('bottom','simple','fr','',1760512938,1760512938,2,2),
('bottom','simple','hu','',1760512938,1760512938,2,2),
('bottom','simple','it','',1760512938,1760512938,2,2),
('bottom','simple','ja','',1760512938,1760512938,2,2),
('bottom','simple','nl','',1760512938,1760512938,2,2),
('bottom','simple','pl','',1760512938,1760512938,2,2),
('bottom','simple','pt','',1760512938,1760512938,2,2),
('bottom','simple','ru','',1760512938,1760512938,2,2),
('bottom','simple','sk','',1760512938,1760512938,2,2),
('bottom','simple','sv','',1760512938,1760512938,2,2),
('bottom','simple','th','',1760512938,1760512938,2,2),
('bottom','simple','tr','',1760512938,1760512938,2,2),
('bottom','simple','uk','',1760512938,1760512938,2,2),
('bottom','simple','zh_Hans','',1760512938,1760512938,2,2),
('classname','simple','ca','',1760514816,1760514816,2,2),
('classname','simple','cs','',1760514816,1760514816,2,2),
('classname','simple','de','',1760514816,1760514816,2,2),
('classname','simple','en','',1760514816,1760514816,2,2),
('classname','simple','es','',1760514816,1760514816,2,2),
('classname','simple','fr','',1760514816,1760514816,2,2),
('classname','simple','hu','',1760514816,1760514816,2,2),
('classname','simple','it','',1760514816,1760514816,2,2),
('classname','simple','ja','',1760514816,1760514816,2,2),
('classname','simple','nl','',1760514816,1760514816,2,2),
('classname','simple','pl','',1760514816,1760514816,2,2),
('classname','simple','pt','',1760514816,1760514816,2,2),
('classname','simple','ru','',1760514816,1760514816,2,2),
('classname','simple','sk','',1760514816,1760514816,2,2),
('classname','simple','sv','',1760514816,1760514816,2,2),
('classname','simple','th','',1760514816,1760514816,2,2),
('classname','simple','tr','',1760514816,1760514816,2,2),
('classname','simple','uk','',1760514816,1760514816,2,2),
('classname','simple','zh_Hans','',1760514816,1760514816,2,2),
('clear','simple','ca','',1760513118,1760513118,2,2),
('clear','simple','cs','',1760513118,1760513118,2,2),
('clear','simple','de','',1760513118,1760513118,2,2),
('clear','simple','en','',1760513118,1760513118,2,2),
('clear','simple','es','',1760513118,1760513118,2,2),
('clear','simple','fr','',1760513118,1760513118,2,2),
('clear','simple','hu','',1760513118,1760513118,2,2),
('clear','simple','it','',1760513118,1760513118,2,2),
('clear','simple','ja','',1760513118,1760513118,2,2),
('clear','simple','nl','',1760513118,1760513118,2,2),
('clear','simple','pl','',1760513118,1760513118,2,2),
('clear','simple','pt','',1760513118,1760513118,2,2),
('clear','simple','ru','',1760513118,1760513118,2,2),
('clear','simple','sk','',1760513118,1760513118,2,2),
('clear','simple','sv','',1760513118,1760513118,2,2),
('clear','simple','th','',1760513118,1760513118,2,2),
('clear','simple','tr','',1760513118,1760513118,2,2),
('clear','simple','uk','',1760513118,1760513118,2,2),
('clear','simple','zh_Hans','',1760513118,1760513118,2,2),
('down','simple','ca','',1760513646,1760513646,2,2),
('down','simple','cs','',1760513646,1760513646,2,2),
('down','simple','de','',1760513646,1760513646,2,2),
('down','simple','en','',1760513646,1760513646,2,2),
('down','simple','es','',1760513646,1760513646,2,2),
('down','simple','fr','',1760513646,1760513646,2,2),
('down','simple','hu','',1760513646,1760513646,2,2),
('down','simple','it','',1760513646,1760513646,2,2),
('down','simple','ja','',1760513646,1760513646,2,2),
('down','simple','nl','',1760513646,1760513646,2,2),
('down','simple','pl','',1760513646,1760513646,2,2),
('down','simple','pt','',1760513646,1760513646,2,2),
('down','simple','ru','',1760513646,1760513646,2,2),
('down','simple','sk','',1760513646,1760513646,2,2),
('down','simple','sv','',1760513646,1760513646,2,2),
('down','simple','th','',1760513646,1760513646,2,2),
('down','simple','tr','',1760513646,1760513646,2,2),
('down','simple','uk','',1760513646,1760513646,2,2),
('down','simple','zh_Hans','',1760513646,1760513646,2,2),
('global','simple','ca','',1760512938,1760512938,2,2),
('global','simple','cs','',1760512938,1760512938,2,2),
('global','simple','de','',1760512938,1760512938,2,2),
('global','simple','en','',1760512938,1760512938,2,2),
('global','simple','es','',1760512938,1760512938,2,2),
('global','simple','fr','',1760512938,1760512938,2,2),
('global','simple','hu','',1760512938,1760512938,2,2),
('global','simple','it','',1760512938,1760512938,2,2),
('global','simple','ja','',1760512938,1760512938,2,2),
('global','simple','nl','',1760512938,1760512938,2,2),
('global','simple','pl','',1760512938,1760512938,2,2),
('global','simple','pt','',1760512938,1760512938,2,2),
('global','simple','ru','',1760512938,1760512938,2,2),
('global','simple','sk','',1760512938,1760512938,2,2),
('global','simple','sv','',1760512938,1760512938,2,2),
('global','simple','th','',1760512938,1760512938,2,2),
('global','simple','tr','',1760512938,1760512938,2,2),
('global','simple','uk','',1760512938,1760512938,2,2),
('global','simple','zh_Hans','',1760512938,1760512938,2,2),
('ignoreCase','simple','ca','',1760512938,1760512938,2,2),
('ignoreCase','simple','cs','',1760512938,1760512938,2,2),
('ignoreCase','simple','de','',1760512938,1760512938,2,2),
('ignoreCase','simple','en','',1760512938,1760512938,2,2),
('ignoreCase','simple','es','',1760512938,1760512938,2,2),
('ignoreCase','simple','fr','',1760512938,1760512938,2,2),
('ignoreCase','simple','hu','',1760512938,1760512938,2,2),
('ignoreCase','simple','it','',1760512938,1760512938,2,2),
('ignoreCase','simple','ja','',1760512938,1760512938,2,2),
('ignoreCase','simple','nl','',1760512938,1760512938,2,2),
('ignoreCase','simple','pl','',1760512938,1760512938,2,2),
('ignoreCase','simple','pt','',1760512938,1760512938,2,2),
('ignoreCase','simple','ru','',1760512938,1760512938,2,2),
('ignoreCase','simple','sk','',1760512938,1760512938,2,2),
('ignoreCase','simple','sv','',1760512938,1760512938,2,2),
('ignoreCase','simple','th','',1760512938,1760512938,2,2),
('ignoreCase','simple','tr','',1760512938,1760512938,2,2),
('ignoreCase','simple','uk','',1760512938,1760512938,2,2),
('ignoreCase','simple','zh_Hans','',1760512938,1760512938,2,2),
('login','simple','de','',1760512813,1760512813,0,0),
('login','simple','en','',1760512813,1760512813,0,0),
('login','simple','fr','',1760512813,1760512813,0,0),
('multiline','simple','ca','',1760512938,1760512938,2,2),
('multiline','simple','cs','',1760512938,1760512938,2,2),
('multiline','simple','de','',1760512938,1760512938,2,2),
('multiline','simple','en','',1760512938,1760512938,2,2),
('multiline','simple','es','',1760512938,1760512938,2,2),
('multiline','simple','fr','',1760512938,1760512938,2,2),
('multiline','simple','hu','',1760512938,1760512938,2,2),
('multiline','simple','it','',1760512938,1760512938,2,2),
('multiline','simple','ja','',1760512938,1760512938,2,2),
('multiline','simple','nl','',1760512938,1760512938,2,2),
('multiline','simple','pl','',1760512938,1760512938,2,2),
('multiline','simple','pt','',1760512938,1760512938,2,2),
('multiline','simple','ru','',1760512938,1760512938,2,2),
('multiline','simple','sk','',1760512938,1760512938,2,2),
('multiline','simple','sv','',1760512938,1760512938,2,2),
('multiline','simple','th','',1760512938,1760512938,2,2),
('multiline','simple','tr','',1760512938,1760512938,2,2),
('multiline','simple','uk','',1760512938,1760512938,2,2),
('multiline','simple','zh_Hans','',1760512938,1760512938,2,2),
('object_add_dialog_custom_text.Application','simple','ca','',1760515356,1760515356,2,2),
('object_add_dialog_custom_text.Application','simple','cs','',1760515356,1760515356,2,2),
('object_add_dialog_custom_text.Application','simple','de','',1760515356,1760515356,2,2),
('object_add_dialog_custom_text.Application','simple','en','',1760515356,1760515356,2,2),
('object_add_dialog_custom_text.Application','simple','es','',1760515356,1760515356,2,2),
('object_add_dialog_custom_text.Application','simple','fr','',1760515356,1760515356,2,2),
('object_add_dialog_custom_text.Application','simple','hu','',1760515356,1760515356,2,2),
('object_add_dialog_custom_text.Application','simple','it','',1760515356,1760515356,2,2),
('object_add_dialog_custom_text.Application','simple','ja','',1760515356,1760515356,2,2),
('object_add_dialog_custom_text.Application','simple','nl','',1760515356,1760515356,2,2),
('object_add_dialog_custom_text.Application','simple','pl','',1760515356,1760515356,2,2),
('object_add_dialog_custom_text.Application','simple','pt','',1760515356,1760515356,2,2),
('object_add_dialog_custom_text.Application','simple','ru','',1760515356,1760515356,2,2),
('object_add_dialog_custom_text.Application','simple','sk','',1760515356,1760515356,2,2),
('object_add_dialog_custom_text.Application','simple','sv','',1760515356,1760515356,2,2),
('object_add_dialog_custom_text.Application','simple','th','',1760515356,1760515356,2,2),
('object_add_dialog_custom_text.Application','simple','tr','',1760515356,1760515356,2,2),
('object_add_dialog_custom_text.Application','simple','uk','',1760515356,1760515356,2,2),
('object_add_dialog_custom_text.Application','simple','zh_Hans','',1760515356,1760515356,2,2),
('object_add_dialog_custom_text.JobCategory','simple','ca','',1760513208,1760513208,2,2),
('object_add_dialog_custom_text.JobCategory','simple','cs','',1760513208,1760513208,2,2),
('object_add_dialog_custom_text.JobCategory','simple','de','',1760513208,1760513208,2,2),
('object_add_dialog_custom_text.JobCategory','simple','en','',1760513208,1760513208,2,2),
('object_add_dialog_custom_text.JobCategory','simple','es','',1760513208,1760513208,2,2),
('object_add_dialog_custom_text.JobCategory','simple','fr','',1760513208,1760513208,2,2),
('object_add_dialog_custom_text.JobCategory','simple','hu','',1760513208,1760513208,2,2),
('object_add_dialog_custom_text.JobCategory','simple','it','',1760513208,1760513208,2,2),
('object_add_dialog_custom_text.JobCategory','simple','ja','',1760513208,1760513208,2,2),
('object_add_dialog_custom_text.JobCategory','simple','nl','',1760513208,1760513208,2,2),
('object_add_dialog_custom_text.JobCategory','simple','pl','',1760513208,1760513208,2,2),
('object_add_dialog_custom_text.JobCategory','simple','pt','',1760513208,1760513208,2,2),
('object_add_dialog_custom_text.JobCategory','simple','ru','',1760513208,1760513208,2,2),
('object_add_dialog_custom_text.JobCategory','simple','sk','',1760513208,1760513208,2,2),
('object_add_dialog_custom_text.JobCategory','simple','sv','',1760513208,1760513208,2,2),
('object_add_dialog_custom_text.JobCategory','simple','th','',1760513208,1760513208,2,2),
('object_add_dialog_custom_text.JobCategory','simple','tr','',1760513208,1760513208,2,2),
('object_add_dialog_custom_text.JobCategory','simple','uk','',1760513208,1760513208,2,2),
('object_add_dialog_custom_text.JobCategory','simple','zh_Hans','',1760513208,1760513208,2,2),
('object_add_dialog_custom_text.Position','simple','ca','',1760513826,1760513826,2,2),
('object_add_dialog_custom_text.Position','simple','cs','',1760513826,1760513826,2,2),
('object_add_dialog_custom_text.Position','simple','de','',1760513826,1760513826,2,2),
('object_add_dialog_custom_text.Position','simple','en','',1760513826,1760513826,2,2),
('object_add_dialog_custom_text.Position','simple','es','',1760513826,1760513826,2,2),
('object_add_dialog_custom_text.Position','simple','fr','',1760513826,1760513826,2,2),
('object_add_dialog_custom_text.Position','simple','hu','',1760513826,1760513826,2,2),
('object_add_dialog_custom_text.Position','simple','it','',1760513826,1760513826,2,2),
('object_add_dialog_custom_text.Position','simple','ja','',1760513826,1760513826,2,2),
('object_add_dialog_custom_text.Position','simple','nl','',1760513826,1760513826,2,2),
('object_add_dialog_custom_text.Position','simple','pl','',1760513826,1760513826,2,2),
('object_add_dialog_custom_text.Position','simple','pt','',1760513826,1760513826,2,2),
('object_add_dialog_custom_text.Position','simple','ru','',1760513826,1760513826,2,2),
('object_add_dialog_custom_text.Position','simple','sk','',1760513826,1760513826,2,2),
('object_add_dialog_custom_text.Position','simple','sv','',1760513826,1760513826,2,2),
('object_add_dialog_custom_text.Position','simple','th','',1760513826,1760513826,2,2),
('object_add_dialog_custom_text.Position','simple','tr','',1760513826,1760513826,2,2),
('object_add_dialog_custom_text.Position','simple','uk','',1760513826,1760513826,2,2),
('object_add_dialog_custom_text.Position','simple','zh_Hans','',1760513826,1760513826,2,2),
('object_add_dialog_custom_title.Application','simple','ca','',1760515356,1760515356,2,2),
('object_add_dialog_custom_title.Application','simple','cs','',1760515356,1760515356,2,2),
('object_add_dialog_custom_title.Application','simple','de','',1760515356,1760515356,2,2),
('object_add_dialog_custom_title.Application','simple','en','',1760515356,1760515356,2,2),
('object_add_dialog_custom_title.Application','simple','es','',1760515356,1760515356,2,2),
('object_add_dialog_custom_title.Application','simple','fr','',1760515356,1760515356,2,2),
('object_add_dialog_custom_title.Application','simple','hu','',1760515356,1760515356,2,2),
('object_add_dialog_custom_title.Application','simple','it','',1760515356,1760515356,2,2),
('object_add_dialog_custom_title.Application','simple','ja','',1760515356,1760515356,2,2),
('object_add_dialog_custom_title.Application','simple','nl','',1760515356,1760515356,2,2),
('object_add_dialog_custom_title.Application','simple','pl','',1760515356,1760515356,2,2),
('object_add_dialog_custom_title.Application','simple','pt','',1760515356,1760515356,2,2),
('object_add_dialog_custom_title.Application','simple','ru','',1760515356,1760515356,2,2),
('object_add_dialog_custom_title.Application','simple','sk','',1760515356,1760515356,2,2),
('object_add_dialog_custom_title.Application','simple','sv','',1760515356,1760515356,2,2),
('object_add_dialog_custom_title.Application','simple','th','',1760515356,1760515356,2,2),
('object_add_dialog_custom_title.Application','simple','tr','',1760515356,1760515356,2,2),
('object_add_dialog_custom_title.Application','simple','uk','',1760515356,1760515356,2,2),
('object_add_dialog_custom_title.Application','simple','zh_Hans','',1760515356,1760515356,2,2),
('object_add_dialog_custom_title.JobCategory','simple','ca','',1760513208,1760513208,2,2),
('object_add_dialog_custom_title.JobCategory','simple','cs','',1760513208,1760513208,2,2),
('object_add_dialog_custom_title.JobCategory','simple','de','',1760513208,1760513208,2,2),
('object_add_dialog_custom_title.JobCategory','simple','en','',1760513208,1760513208,2,2),
('object_add_dialog_custom_title.JobCategory','simple','es','',1760513208,1760513208,2,2),
('object_add_dialog_custom_title.JobCategory','simple','fr','',1760513208,1760513208,2,2),
('object_add_dialog_custom_title.JobCategory','simple','hu','',1760513208,1760513208,2,2),
('object_add_dialog_custom_title.JobCategory','simple','it','',1760513208,1760513208,2,2),
('object_add_dialog_custom_title.JobCategory','simple','ja','',1760513208,1760513208,2,2),
('object_add_dialog_custom_title.JobCategory','simple','nl','',1760513208,1760513208,2,2),
('object_add_dialog_custom_title.JobCategory','simple','pl','',1760513208,1760513208,2,2),
('object_add_dialog_custom_title.JobCategory','simple','pt','',1760513208,1760513208,2,2),
('object_add_dialog_custom_title.JobCategory','simple','ru','',1760513208,1760513208,2,2),
('object_add_dialog_custom_title.JobCategory','simple','sk','',1760513208,1760513208,2,2),
('object_add_dialog_custom_title.JobCategory','simple','sv','',1760513208,1760513208,2,2),
('object_add_dialog_custom_title.JobCategory','simple','th','',1760513208,1760513208,2,2),
('object_add_dialog_custom_title.JobCategory','simple','tr','',1760513208,1760513208,2,2),
('object_add_dialog_custom_title.JobCategory','simple','uk','',1760513208,1760513208,2,2),
('object_add_dialog_custom_title.JobCategory','simple','zh_Hans','',1760513208,1760513208,2,2),
('object_add_dialog_custom_title.Position','simple','ca','',1760513826,1760513826,2,2),
('object_add_dialog_custom_title.Position','simple','cs','',1760513826,1760513826,2,2),
('object_add_dialog_custom_title.Position','simple','de','',1760513826,1760513826,2,2),
('object_add_dialog_custom_title.Position','simple','en','',1760513826,1760513826,2,2),
('object_add_dialog_custom_title.Position','simple','es','',1760513826,1760513826,2,2),
('object_add_dialog_custom_title.Position','simple','fr','',1760513826,1760513826,2,2),
('object_add_dialog_custom_title.Position','simple','hu','',1760513826,1760513826,2,2),
('object_add_dialog_custom_title.Position','simple','it','',1760513826,1760513826,2,2),
('object_add_dialog_custom_title.Position','simple','ja','',1760513826,1760513826,2,2),
('object_add_dialog_custom_title.Position','simple','nl','',1760513826,1760513826,2,2),
('object_add_dialog_custom_title.Position','simple','pl','',1760513826,1760513826,2,2),
('object_add_dialog_custom_title.Position','simple','pt','',1760513826,1760513826,2,2),
('object_add_dialog_custom_title.Position','simple','ru','',1760513826,1760513826,2,2),
('object_add_dialog_custom_title.Position','simple','sk','',1760513826,1760513826,2,2),
('object_add_dialog_custom_title.Position','simple','sv','',1760513826,1760513826,2,2),
('object_add_dialog_custom_title.Position','simple','th','',1760513826,1760513826,2,2),
('object_add_dialog_custom_title.Position','simple','tr','',1760513826,1760513826,2,2),
('object_add_dialog_custom_title.Position','simple','uk','',1760513826,1760513826,2,2),
('object_add_dialog_custom_title.Position','simple','zh_Hans','',1760513826,1760513826,2,2),
('sticky','simple','ca','',1760512938,1760512938,2,2),
('sticky','simple','cs','',1760512938,1760512938,2,2),
('sticky','simple','de','',1760512938,1760512938,2,2),
('sticky','simple','en','',1760512938,1760512938,2,2),
('sticky','simple','es','',1760512938,1760512938,2,2),
('sticky','simple','fr','',1760512938,1760512938,2,2),
('sticky','simple','hu','',1760512938,1760512938,2,2),
('sticky','simple','it','',1760512938,1760512938,2,2),
('sticky','simple','ja','',1760512938,1760512938,2,2),
('sticky','simple','nl','',1760512938,1760512938,2,2),
('sticky','simple','pl','',1760512938,1760512938,2,2),
('sticky','simple','pt','',1760512938,1760512938,2,2),
('sticky','simple','ru','',1760512938,1760512938,2,2),
('sticky','simple','sk','',1760512938,1760512938,2,2),
('sticky','simple','sv','',1760512938,1760512938,2,2),
('sticky','simple','th','',1760512938,1760512938,2,2),
('sticky','simple','tr','',1760512938,1760512938,2,2),
('sticky','simple','uk','',1760512938,1760512938,2,2),
('sticky','simple','zh_Hans','',1760512938,1760512938,2,2),
('unicode','simple','ca','',1760512938,1760512938,2,2),
('unicode','simple','cs','',1760512938,1760512938,2,2),
('unicode','simple','de','',1760512938,1760512938,2,2),
('unicode','simple','en','',1760512938,1760512938,2,2),
('unicode','simple','es','',1760512938,1760512938,2,2),
('unicode','simple','fr','',1760512938,1760512938,2,2),
('unicode','simple','hu','',1760512938,1760512938,2,2),
('unicode','simple','it','',1760512938,1760512938,2,2),
('unicode','simple','ja','',1760512938,1760512938,2,2),
('unicode','simple','nl','',1760512938,1760512938,2,2),
('unicode','simple','pl','',1760512938,1760512938,2,2),
('unicode','simple','pt','',1760512938,1760512938,2,2),
('unicode','simple','ru','',1760512938,1760512938,2,2),
('unicode','simple','sk','',1760512938,1760512938,2,2),
('unicode','simple','sv','',1760512938,1760512938,2,2),
('unicode','simple','th','',1760512938,1760512938,2,2),
('unicode','simple','tr','',1760512938,1760512938,2,2),
('unicode','simple','uk','',1760512938,1760512938,2,2),
('unicode','simple','zh_Hans','',1760512938,1760512938,2,2),
('up','simple','ca','',1760513646,1760513646,2,2),
('up','simple','cs','',1760513646,1760513646,2,2),
('up','simple','de','',1760513646,1760513646,2,2),
('up','simple','en','',1760513646,1760513646,2,2),
('up','simple','es','',1760513646,1760513646,2,2),
('up','simple','fr','',1760513646,1760513646,2,2),
('up','simple','hu','',1760513646,1760513646,2,2),
('up','simple','it','',1760513646,1760513646,2,2),
('up','simple','ja','',1760513646,1760513646,2,2),
('up','simple','nl','',1760513646,1760513646,2,2),
('up','simple','pl','',1760513646,1760513646,2,2),
('up','simple','pt','',1760513646,1760513646,2,2),
('up','simple','ru','',1760513646,1760513646,2,2),
('up','simple','sk','',1760513646,1760513646,2,2),
('up','simple','sv','',1760513646,1760513646,2,2),
('up','simple','th','',1760513646,1760513646,2,2),
('up','simple','tr','',1760513646,1760513646,2,2),
('up','simple','uk','',1760513646,1760513646,2,2),
('up','simple','zh_Hans','',1760513646,1760513646,2,2);
/*!40000 ALTER TABLE `translations_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `translations_messages`
--

DROP TABLE IF EXISTS `translations_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `translations_messages` (
  `key` varchar(190) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `type` varchar(10) DEFAULT NULL,
  `language` varchar(10) NOT NULL DEFAULT '',
  `text` text DEFAULT NULL,
  `creationDate` int(11) unsigned DEFAULT NULL,
  `modificationDate` int(11) unsigned DEFAULT NULL,
  `userOwner` int(11) unsigned DEFAULT NULL,
  `userModification` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`key`,`language`),
  KEY `language` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `translations_messages`
--

LOCK TABLES `translations_messages` WRITE;
/*!40000 ALTER TABLE `translations_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `translations_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tree_locks`
--

DROP TABLE IF EXISTS `tree_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tree_locks` (
  `id` int(11) NOT NULL DEFAULT 0,
  `type` enum('asset','document','object') NOT NULL DEFAULT 'asset',
  `locked` enum('self','propagate') DEFAULT NULL,
  PRIMARY KEY (`id`,`type`),
  KEY `type` (`type`),
  KEY `locked` (`locked`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tree_locks`
--

LOCK TABLES `tree_locks` WRITE;
/*!40000 ALTER TABLE `tree_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `tree_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parentId` int(11) unsigned DEFAULT NULL,
  `type` enum('user','userfolder','role','rolefolder') NOT NULL DEFAULT 'user',
  `name` varchar(50) DEFAULT NULL,
  `password` varchar(190) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `language` varchar(10) DEFAULT 'en',
  `datetimeLocale` varchar(10) DEFAULT '',
  `contentLanguages` longtext DEFAULT NULL,
  `admin` tinyint(1) unsigned DEFAULT 0,
  `active` tinyint(1) unsigned DEFAULT 1,
  `permissions` text DEFAULT NULL,
  `roles` varchar(1000) DEFAULT NULL,
  `welcomescreen` tinyint(1) DEFAULT NULL,
  `closeWarning` tinyint(1) DEFAULT NULL,
  `memorizeTabs` tinyint(1) DEFAULT NULL,
  `allowDirtyClose` tinyint(1) unsigned DEFAULT 1,
  `docTypes` text DEFAULT NULL,
  `classes` text DEFAULT NULL,
  `twoFactorAuthentication` varchar(255) DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `activePerspective` varchar(255) DEFAULT NULL,
  `perspectives` longtext DEFAULT NULL,
  `websiteTranslationLanguagesEdit` longtext DEFAULT NULL,
  `websiteTranslationLanguagesView` longtext DEFAULT NULL,
  `lastLogin` int(11) unsigned DEFAULT NULL,
  `keyBindings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`keyBindings`)),
  `passwordRecoveryToken` varchar(290) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `type_name` (`type`,`name`),
  KEY `parentId` (`parentId`),
  KEY `name` (`name`),
  KEY `password` (`password`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(0,0,'user','system',NULL,NULL,NULL,NULL,'en','',NULL,1,1,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(2,0,'user','admin','$2y$10$kABUJVl06Ola9I3I5BRmOOcs.N7.o1DTT0dO98m4J7KiJ/ej3tC/a',NULL,NULL,NULL,'en','',NULL,1,1,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_permission_definitions`
--

DROP TABLE IF EXISTS `users_permission_definitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_permission_definitions` (
  `key` varchar(50) NOT NULL DEFAULT '',
  `category` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_permission_definitions`
--

LOCK TABLES `users_permission_definitions` WRITE;
/*!40000 ALTER TABLE `users_permission_definitions` DISABLE KEYS */;
INSERT INTO `users_permission_definitions` VALUES
('admin_translations','Pimcore Admin Bundle'),
('assets',''),
('asset_metadata',''),
('classes',''),
('classificationstore',''),
('clear_cache',''),
('clear_fullpage_cache',''),
('clear_temp_files',''),
('dashboards',''),
('documents',''),
('document_types',''),
('emails',''),
('fieldcollections',''),
('gdpr_data_extractor','Pimcore Admin Bundle'),
('http_errors','Pimcore Seo Bundle'),
('notes_events',''),
('notifications',''),
('notifications_send',''),
('objectbricks',''),
('objects',''),
('objects_sort_method',''),
('predefined_properties',''),
('quantityValueUnits',''),
('recyclebin',''),
('redirects',''),
('robots.txt','Pimcore Seo Bundle'),
('seemode',''),
('selectoptions',''),
('seo_document_editor','Pimcore Seo Bundle'),
('share_configurations',''),
('sites',''),
('system_appearance_settings','Pimcore Admin Bundle'),
('system_settings',''),
('tags_assignment',''),
('tags_configuration',''),
('tags_search',''),
('thumbnails',''),
('translations',''),
('users',''),
('website_settings',''),
('workflow_details','');
/*!40000 ALTER TABLE `users_permission_definitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_workspaces_asset`
--

DROP TABLE IF EXISTS `users_workspaces_asset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_workspaces_asset` (
  `cid` int(11) unsigned NOT NULL DEFAULT 0,
  `cpath` varchar(765) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `userId` int(11) unsigned NOT NULL DEFAULT 0,
  `list` tinyint(1) DEFAULT 0,
  `view` tinyint(1) DEFAULT 0,
  `publish` tinyint(1) DEFAULT 0,
  `delete` tinyint(1) DEFAULT 0,
  `rename` tinyint(1) DEFAULT 0,
  `create` tinyint(1) DEFAULT 0,
  `settings` tinyint(1) DEFAULT 0,
  `versions` tinyint(1) DEFAULT 0,
  `properties` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`cid`,`userId`),
  UNIQUE KEY `cpath_userId` (`cpath`,`userId`),
  UNIQUE KEY `idx_users_workspaces_list_permission` (`userId`,`cpath`,`list`),
  KEY `userId` (`userId`),
  CONSTRAINT `fk_users_workspaces_asset_assets` FOREIGN KEY (`cid`) REFERENCES `assets` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_users_workspaces_asset_users` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_workspaces_asset`
--

LOCK TABLES `users_workspaces_asset` WRITE;
/*!40000 ALTER TABLE `users_workspaces_asset` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_workspaces_asset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_workspaces_document`
--

DROP TABLE IF EXISTS `users_workspaces_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_workspaces_document` (
  `cid` int(11) unsigned NOT NULL DEFAULT 0,
  `cpath` varchar(765) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `userId` int(11) unsigned NOT NULL DEFAULT 0,
  `list` tinyint(1) unsigned DEFAULT 0,
  `view` tinyint(1) unsigned DEFAULT 0,
  `save` tinyint(1) unsigned DEFAULT 0,
  `publish` tinyint(1) unsigned DEFAULT 0,
  `unpublish` tinyint(1) unsigned DEFAULT 0,
  `delete` tinyint(1) unsigned DEFAULT 0,
  `rename` tinyint(1) unsigned DEFAULT 0,
  `create` tinyint(1) unsigned DEFAULT 0,
  `settings` tinyint(1) unsigned DEFAULT 0,
  `versions` tinyint(1) unsigned DEFAULT 0,
  `properties` tinyint(1) unsigned DEFAULT 0,
  PRIMARY KEY (`cid`,`userId`),
  UNIQUE KEY `cpath_userId` (`cpath`,`userId`),
  UNIQUE KEY `idx_users_workspaces_list_permission` (`userId`,`cpath`,`list`),
  KEY `userId` (`userId`),
  CONSTRAINT `fk_users_workspaces_document_documents` FOREIGN KEY (`cid`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_users_workspaces_document_users` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_workspaces_document`
--

LOCK TABLES `users_workspaces_document` WRITE;
/*!40000 ALTER TABLE `users_workspaces_document` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_workspaces_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_workspaces_object`
--

DROP TABLE IF EXISTS `users_workspaces_object`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_workspaces_object` (
  `cid` int(11) unsigned NOT NULL DEFAULT 0,
  `cpath` varchar(765) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `userId` int(11) unsigned NOT NULL DEFAULT 0,
  `list` tinyint(1) unsigned DEFAULT 0,
  `view` tinyint(1) unsigned DEFAULT 0,
  `save` tinyint(1) unsigned DEFAULT 0,
  `publish` tinyint(1) unsigned DEFAULT 0,
  `unpublish` tinyint(1) unsigned DEFAULT 0,
  `delete` tinyint(1) unsigned DEFAULT 0,
  `rename` tinyint(1) unsigned DEFAULT 0,
  `create` tinyint(1) unsigned DEFAULT 0,
  `settings` tinyint(1) unsigned DEFAULT 0,
  `versions` tinyint(1) unsigned DEFAULT 0,
  `properties` tinyint(1) unsigned DEFAULT 0,
  `lEdit` text DEFAULT NULL,
  `lView` text DEFAULT NULL,
  `layouts` text DEFAULT NULL,
  PRIMARY KEY (`cid`,`userId`),
  UNIQUE KEY `cpath_userId` (`cpath`,`userId`),
  UNIQUE KEY `idx_users_workspaces_list_permission` (`userId`,`cpath`,`list`),
  KEY `userId` (`userId`),
  CONSTRAINT `fk_users_workspaces_object_objects` FOREIGN KEY (`cid`) REFERENCES `objects` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_users_workspaces_object_users` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_workspaces_object`
--

LOCK TABLES `users_workspaces_object` WRITE;
/*!40000 ALTER TABLE `users_workspaces_object` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_workspaces_object` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `versions`
--

DROP TABLE IF EXISTS `versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `versions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cid` int(11) unsigned DEFAULT NULL,
  `ctype` enum('document','asset','object') DEFAULT NULL,
  `userId` int(11) unsigned DEFAULT NULL,
  `note` text DEFAULT NULL,
  `stackTrace` text DEFAULT NULL,
  `date` int(11) unsigned DEFAULT NULL,
  `public` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `serialized` tinyint(1) unsigned DEFAULT 0,
  `versionCount` int(10) unsigned NOT NULL DEFAULT 0,
  `binaryFileHash` varchar(128) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `binaryFileId` bigint(20) unsigned DEFAULT NULL,
  `autoSave` tinyint(4) NOT NULL DEFAULT 0,
  `storageType` varchar(5) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cid` (`cid`),
  KEY `ctype_cid` (`ctype`,`cid`),
  KEY `date` (`date`),
  KEY `public` (`public`),
  KEY `binaryFileHash` (`binaryFileHash`),
  KEY `autoSave` (`autoSave`),
  KEY `stackTrace` (`stackTrace`(1)),
  KEY `versionCount` (`versionCount`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `versions`
--

LOCK TABLES `versions` WRITE;
/*!40000 ALTER TABLE `versions` DISABLE KEYS */;
INSERT INTO `versions` VALUES
(1,5,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(895): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->addAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760513208,0,1,1,NULL,NULL,0,'fs'),
(2,6,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(895): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->addAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760513215,0,1,1,NULL,NULL,0,'fs'),
(3,7,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(895): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->addAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760513221,0,1,1,NULL,NULL,0,'fs'),
(4,5,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1135): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1054): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->executeUpdateAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->updateAction()\n#8 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#9 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#10 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#11 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#12 /var/www/html/public/index.php(19): require_once(\'...\')\n#13 {main}',1760513227,0,1,2,NULL,NULL,0,'fs'),
(5,6,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1135): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1054): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->executeUpdateAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->updateAction()\n#8 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#9 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#10 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#11 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#12 /var/www/html/public/index.php(19): require_once(\'...\')\n#13 {main}',1760513232,0,1,2,NULL,NULL,0,'fs'),
(7,5,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1430): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760513238,0,1,4,NULL,NULL,0,'fs'),
(8,5,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1423): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#4 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#5 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#6 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#7 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#8 /var/www/html/public/index.php(19): require_once(\'...\')\n#9 {main}',1760513297,0,1,5,NULL,NULL,1,'fs'),
(9,6,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1423): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#4 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#5 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#6 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#7 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#8 /var/www/html/public/index.php(19): require_once(\'...\')\n#9 {main}',1760513301,0,1,3,NULL,NULL,1,'fs'),
(11,7,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1430): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760513309,0,1,3,NULL,NULL,0,'fs'),
(12,5,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectActionsTrait.php(92): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1719): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxy()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxyAction()\n#8 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#9 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#10 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#11 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#12 /var/www/html/public/index.php(19): require_once(\'...\')\n#13 {main}',1760513314,0,1,6,NULL,NULL,0,'fs'),
(13,6,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectActionsTrait.php(92): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1719): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxy()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxyAction()\n#8 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#9 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#10 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#11 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#12 /var/www/html/public/index.php(19): require_once(\'...\')\n#13 {main}',1760513315,0,1,4,NULL,NULL,0,'fs'),
(14,7,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectActionsTrait.php(92): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1719): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxy()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxyAction()\n#8 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#9 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#10 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#11 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#12 /var/www/html/public/index.php(19): require_once(\'...\')\n#13 {main}',1760513315,0,1,4,NULL,NULL,0,'fs'),
(15,8,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(895): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->addAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760513818,0,1,1,NULL,NULL,0,'fs'),
(17,8,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1430): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760514294,0,1,3,NULL,NULL,0,'fs'),
(18,9,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(895): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->addAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760514318,0,1,1,NULL,NULL,0,'fs'),
(20,9,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1430): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760514342,0,1,3,NULL,NULL,0,'fs'),
(21,8,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1135): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1054): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->executeUpdateAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->updateAction()\n#8 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#9 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#10 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#11 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#12 /var/www/html/public/index.php(19): require_once(\'...\')\n#13 {main}',1760514350,0,1,4,NULL,NULL,0,'fs'),
(22,10,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(895): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->addAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760514369,0,1,1,NULL,NULL,0,'fs'),
(24,10,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1430): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760514391,0,1,3,NULL,NULL,0,'fs'),
(25,11,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(895): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->addAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760514413,0,1,1,NULL,NULL,0,'fs'),
(27,12,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(895): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->addAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760514440,0,1,1,NULL,NULL,0,'fs'),
(29,12,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1430): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760514450,0,1,3,NULL,NULL,0,'fs'),
(30,11,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1430): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760514456,0,1,4,NULL,NULL,0,'fs'),
(31,13,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(895): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->addAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760514478,0,1,1,NULL,NULL,0,'fs'),
(33,13,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1430): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760514495,0,1,3,NULL,NULL,0,'fs'),
(34,14,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(895): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->addAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760514626,0,1,1,NULL,NULL,0,'fs'),
(36,14,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1430): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760514645,0,1,3,NULL,NULL,0,'fs'),
(37,15,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(895): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->addAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760514659,0,1,1,NULL,NULL,0,'fs'),
(39,16,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(895): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->addAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760514678,0,1,1,NULL,NULL,0,'fs'),
(41,16,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1430): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760514684,0,1,3,NULL,NULL,0,'fs'),
(42,15,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1430): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760514689,0,1,4,NULL,NULL,0,'fs'),
(43,17,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(895): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->addAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760514705,0,1,1,NULL,NULL,0,'fs'),
(45,17,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1430): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760514722,0,1,3,NULL,NULL,0,'fs'),
(46,18,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(895): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->addAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760514738,0,1,1,NULL,NULL,0,'fs'),
(48,18,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1430): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760514754,0,1,3,NULL,NULL,0,'fs'),
(49,19,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(895): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->addAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760514761,0,1,1,NULL,NULL,0,'fs'),
(51,19,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1430): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760514767,0,1,3,NULL,NULL,0,'fs'),
(52,20,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(895): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->addAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760514777,0,1,1,NULL,NULL,0,'fs'),
(54,20,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1430): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760514794,0,1,3,NULL,NULL,0,'fs'),
(56,20,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1430): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760514798,0,1,5,NULL,NULL,0,'fs'),
(57,12,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectActionsTrait.php(92): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1719): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxy()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxyAction()\n#8 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#9 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#10 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#11 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#12 /var/www/html/public/index.php(19): require_once(\'...\')\n#13 {main}',1760514800,0,1,4,NULL,NULL,0,'fs'),
(58,16,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectActionsTrait.php(92): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1719): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxy()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxyAction()\n#8 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#9 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#10 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#11 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#12 /var/www/html/public/index.php(19): require_once(\'...\')\n#13 {main}',1760514800,0,1,4,NULL,NULL,0,'fs'),
(59,19,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectActionsTrait.php(92): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1719): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxy()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxyAction()\n#8 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#9 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#10 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#11 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#12 /var/www/html/public/index.php(19): require_once(\'...\')\n#13 {main}',1760514801,0,1,4,NULL,NULL,0,'fs'),
(60,8,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectActionsTrait.php(92): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1719): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxy()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxyAction()\n#8 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#9 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#10 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#11 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#12 /var/www/html/public/index.php(19): require_once(\'...\')\n#13 {main}',1760515014,0,1,5,NULL,NULL,0,'fs'),
(61,9,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectActionsTrait.php(92): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1719): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxy()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxyAction()\n#8 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#9 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#10 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#11 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#12 /var/www/html/public/index.php(19): require_once(\'...\')\n#13 {main}',1760515014,0,1,4,NULL,NULL,0,'fs'),
(62,10,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectActionsTrait.php(92): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1719): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxy()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxyAction()\n#8 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#9 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#10 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#11 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#12 /var/www/html/public/index.php(19): require_once(\'...\')\n#13 {main}',1760515015,0,1,4,NULL,NULL,0,'fs'),
(63,11,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectActionsTrait.php(92): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1719): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxy()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxyAction()\n#8 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#9 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#10 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#11 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#12 /var/www/html/public/index.php(19): require_once(\'...\')\n#13 {main}',1760515016,0,1,5,NULL,NULL,0,'fs'),
(64,13,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectActionsTrait.php(92): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1719): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxy()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxyAction()\n#8 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#9 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#10 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#11 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#12 /var/www/html/public/index.php(19): require_once(\'...\')\n#13 {main}',1760515016,0,1,4,NULL,NULL,0,'fs'),
(65,14,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectActionsTrait.php(92): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1719): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxy()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxyAction()\n#8 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#9 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#10 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#11 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#12 /var/www/html/public/index.php(19): require_once(\'...\')\n#13 {main}',1760515017,0,1,4,NULL,NULL,0,'fs'),
(66,15,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectActionsTrait.php(92): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1719): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxy()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxyAction()\n#8 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#9 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#10 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#11 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#12 /var/www/html/public/index.php(19): require_once(\'...\')\n#13 {main}',1760515017,0,1,5,NULL,NULL,0,'fs'),
(67,17,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectActionsTrait.php(92): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1719): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxy()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxyAction()\n#8 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#9 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#10 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#11 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#12 /var/www/html/public/index.php(19): require_once(\'...\')\n#13 {main}',1760515017,0,1,4,NULL,NULL,0,'fs'),
(68,18,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectActionsTrait.php(92): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1719): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxy()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxyAction()\n#8 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#9 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#10 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#11 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#12 /var/www/html/public/index.php(19): require_once(\'...\')\n#13 {main}',1760515018,0,1,4,NULL,NULL,0,'fs'),
(69,20,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectActionsTrait.php(92): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1719): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxy()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxyAction()\n#8 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#9 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#10 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#11 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#12 /var/www/html/public/index.php(19): require_once(\'...\')\n#13 {main}',1760515018,0,1,6,NULL,NULL,0,'fs'),
(71,8,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1391): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760515048,0,1,7,NULL,NULL,0,'fs'),
(73,9,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1391): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760515071,0,1,6,NULL,NULL,0,'fs'),
(75,14,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1391): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760515085,0,1,6,NULL,NULL,0,'fs'),
(77,10,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1391): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760515096,0,1,6,NULL,NULL,0,'fs'),
(79,9,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1391): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760515118,0,1,8,NULL,NULL,0,'fs'),
(81,13,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1391): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760515130,0,1,6,NULL,NULL,0,'fs'),
(83,20,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1391): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760515141,0,1,8,NULL,NULL,0,'fs'),
(85,11,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1391): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760515151,0,1,7,NULL,NULL,0,'fs'),
(86,18,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1423): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#4 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#5 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#6 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#7 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#8 /var/www/html/public/index.php(19): require_once(\'...\')\n#9 {main}',1760515164,0,1,5,NULL,NULL,1,'fs'),
(87,15,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1423): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#4 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#5 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#6 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#7 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#8 /var/www/html/public/index.php(19): require_once(\'...\')\n#9 {main}',1760515176,0,1,6,NULL,NULL,1,'fs'),
(88,13,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1423): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#4 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#5 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#6 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#7 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#8 /var/www/html/public/index.php(19): require_once(\'...\')\n#9 {main}',1760515206,0,1,7,NULL,NULL,1,'fs'),
(89,21,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(895): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->addAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760515344,0,1,1,NULL,NULL,0,'fs'),
(91,21,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1430): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760515379,0,1,3,NULL,NULL,0,'fs'),
(92,21,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1391): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760515386,0,1,4,NULL,NULL,0,'fs'),
(93,22,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(895): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->addAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760515397,0,1,1,NULL,NULL,0,'fs'),
(95,22,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1430): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->saveAction()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#8 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#9 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#10 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#11 /var/www/html/public/index.php(19): require_once(\'...\')\n#12 {main}',1760515442,0,1,3,NULL,NULL,0,'fs'),
(96,22,'object',2,'','#0 /var/www/html/vendor/pimcore/pimcore/models/Element/AbstractElement.php(607): Pimcore\\Model\\Version->save()\n#1 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(268): Pimcore\\Model\\Element\\AbstractElement->doSaveVersion()\n#2 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(206): Pimcore\\Model\\DataObject\\Concrete->saveVersion()\n#3 /var/www/html/vendor/pimcore/pimcore/models/DataObject/AbstractObject.php(550): Pimcore\\Model\\DataObject\\Concrete->update()\n#4 /var/www/html/vendor/pimcore/pimcore/models/DataObject/Concrete.php(637): Pimcore\\Model\\DataObject\\AbstractObject->save()\n#5 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectActionsTrait.php(92): Pimcore\\Model\\DataObject\\Concrete->save()\n#6 /var/www/html/vendor/pimcore/admin-ui-classic-bundle/src/Controller/Admin/DataObject/DataObjectController.php(1719): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxy()\n#7 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(181): Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController->gridProxyAction()\n#8 /var/www/html/vendor/symfony/http-kernel/HttpKernel.php(76): Symfony\\Component\\HttpKernel\\HttpKernel->handleRaw()\n#9 /var/www/html/vendor/symfony/http-kernel/Kernel.php(197): Symfony\\Component\\HttpKernel\\HttpKernel->handle()\n#10 /var/www/html/vendor/symfony/runtime/Runner/Symfony/HttpKernelRunner.php(35): Symfony\\Component\\HttpKernel\\Kernel->handle()\n#11 /var/www/html/vendor/autoload_runtime.php(29): Symfony\\Component\\Runtime\\Runner\\Symfony\\HttpKernelRunner->run()\n#12 /var/www/html/public/index.php(19): require_once(\'...\')\n#13 {main}',1760515444,0,1,4,NULL,NULL,0,'fs');
/*!40000 ALTER TABLE `versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webdav_locks`
--

DROP TABLE IF EXISTS `webdav_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `webdav_locks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `owner` varchar(100) DEFAULT NULL,
  `timeout` int(10) unsigned DEFAULT NULL,
  `created` int(11) DEFAULT NULL,
  `token` varbinary(100) DEFAULT NULL,
  `scope` tinyint(4) DEFAULT NULL,
  `depth` tinyint(4) DEFAULT NULL,
  `uri` varbinary(1000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `token` (`token`),
  KEY `uri` (`uri`(100))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webdav_locks`
--

LOCK TABLES `webdav_locks` WRITE;
/*!40000 ALTER TABLE `webdav_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `webdav_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `website_settings`
--

DROP TABLE IF EXISTS `website_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `website_settings` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(190) NOT NULL DEFAULT '',
  `type` enum('text','document','asset','object','bool') DEFAULT NULL,
  `data` text DEFAULT NULL,
  `language` varchar(15) NOT NULL DEFAULT '',
  `siteId` int(11) unsigned DEFAULT NULL,
  `creationDate` int(11) unsigned DEFAULT 0,
  `modificationDate` int(11) unsigned DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `siteId` (`siteId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `website_settings`
--

LOCK TABLES `website_settings` WRITE;
/*!40000 ALTER TABLE `website_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `website_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `object_application`
--

/*!50001 DROP VIEW IF EXISTS `object_application`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`db`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `object_application` AS select `object_query_application`.`oo_id` AS `oo_id`,`object_query_application`.`oo_classId` AS `oo_classId`,`object_query_application`.`oo_className` AS `oo_className`,`object_query_application`.`firstname` AS `firstname`,`object_query_application`.`lastname` AS `lastname`,`object_query_application`.`email` AS `email`,`object_query_application`.`privacy` AS `privacy`,`object_query_application`.`marketing` AS `marketing`,`object_query_application`.`position__id` AS `position__id`,`object_query_application`.`position__type` AS `position__type`,`objects`.`id` AS `id`,`objects`.`parentId` AS `parentId`,`objects`.`type` AS `type`,`objects`.`key` AS `key`,`objects`.`path` AS `path`,`objects`.`index` AS `index`,`objects`.`published` AS `published`,`objects`.`creationDate` AS `creationDate`,`objects`.`modificationDate` AS `modificationDate`,`objects`.`userOwner` AS `userOwner`,`objects`.`userModification` AS `userModification`,`objects`.`classId` AS `classId`,`objects`.`className` AS `className`,`objects`.`childrenSortBy` AS `childrenSortBy`,`objects`.`childrenSortOrder` AS `childrenSortOrder`,`objects`.`versionCount` AS `versionCount` from (`object_query_application` join `objects` on(`objects`.`id` = `object_query_application`.`oo_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `object_job_category`
--

/*!50001 DROP VIEW IF EXISTS `object_job_category`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`db`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `object_job_category` AS select `object_query_job_category`.`oo_id` AS `oo_id`,`object_query_job_category`.`oo_classId` AS `oo_classId`,`object_query_job_category`.`oo_className` AS `oo_className`,`object_query_job_category`.`positions` AS `positions`,`objects`.`id` AS `id`,`objects`.`parentId` AS `parentId`,`objects`.`type` AS `type`,`objects`.`key` AS `key`,`objects`.`path` AS `path`,`objects`.`index` AS `index`,`objects`.`published` AS `published`,`objects`.`creationDate` AS `creationDate`,`objects`.`modificationDate` AS `modificationDate`,`objects`.`userOwner` AS `userOwner`,`objects`.`userModification` AS `userModification`,`objects`.`classId` AS `classId`,`objects`.`className` AS `className`,`objects`.`childrenSortBy` AS `childrenSortBy`,`objects`.`childrenSortOrder` AS `childrenSortOrder`,`objects`.`versionCount` AS `versionCount` from (`object_query_job_category` join `objects` on(`objects`.`id` = `object_query_job_category`.`oo_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `object_localized_job_category_de`
--

/*!50001 DROP VIEW IF EXISTS `object_localized_job_category_de`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`db`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `object_localized_job_category_de` AS select `object_query_job_category`.`oo_id` AS `oo_id`,`object_query_job_category`.`oo_classId` AS `oo_classId`,`object_query_job_category`.`oo_className` AS `oo_className`,`object_query_job_category`.`positions` AS `positions`,`objects`.`id` AS `id`,`objects`.`parentId` AS `parentId`,`objects`.`type` AS `type`,`objects`.`key` AS `key`,`objects`.`path` AS `path`,`objects`.`index` AS `index`,`objects`.`published` AS `published`,`objects`.`creationDate` AS `creationDate`,`objects`.`modificationDate` AS `modificationDate`,`objects`.`userOwner` AS `userOwner`,`objects`.`userModification` AS `userModification`,`objects`.`classId` AS `classId`,`objects`.`className` AS `className`,`objects`.`childrenSortBy` AS `childrenSortBy`,`objects`.`childrenSortOrder` AS `childrenSortOrder`,`objects`.`versionCount` AS `versionCount`,`de`.`ooo_id` AS `ooo_id`,`de`.`language` AS `language`,`de`.`title` AS `title`,`de`.`description` AS `description` from ((`object_query_job_category` join `objects` on(`objects`.`id` = `object_query_job_category`.`oo_id`)) left join `object_localized_query_job_category_de` `de` on(1 and `object_query_job_category`.`oo_id` = `de`.`ooo_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `object_localized_job_category_en`
--

/*!50001 DROP VIEW IF EXISTS `object_localized_job_category_en`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`db`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `object_localized_job_category_en` AS select `object_query_job_category`.`oo_id` AS `oo_id`,`object_query_job_category`.`oo_classId` AS `oo_classId`,`object_query_job_category`.`oo_className` AS `oo_className`,`object_query_job_category`.`positions` AS `positions`,`objects`.`id` AS `id`,`objects`.`parentId` AS `parentId`,`objects`.`type` AS `type`,`objects`.`key` AS `key`,`objects`.`path` AS `path`,`objects`.`index` AS `index`,`objects`.`published` AS `published`,`objects`.`creationDate` AS `creationDate`,`objects`.`modificationDate` AS `modificationDate`,`objects`.`userOwner` AS `userOwner`,`objects`.`userModification` AS `userModification`,`objects`.`classId` AS `classId`,`objects`.`className` AS `className`,`objects`.`childrenSortBy` AS `childrenSortBy`,`objects`.`childrenSortOrder` AS `childrenSortOrder`,`objects`.`versionCount` AS `versionCount`,`en`.`ooo_id` AS `ooo_id`,`en`.`language` AS `language`,`en`.`title` AS `title`,`en`.`description` AS `description` from ((`object_query_job_category` join `objects` on(`objects`.`id` = `object_query_job_category`.`oo_id`)) left join `object_localized_query_job_category_en` `en` on(1 and `object_query_job_category`.`oo_id` = `en`.`ooo_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `object_localized_job_category_fr`
--

/*!50001 DROP VIEW IF EXISTS `object_localized_job_category_fr`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`db`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `object_localized_job_category_fr` AS select `object_query_job_category`.`oo_id` AS `oo_id`,`object_query_job_category`.`oo_classId` AS `oo_classId`,`object_query_job_category`.`oo_className` AS `oo_className`,`object_query_job_category`.`positions` AS `positions`,`objects`.`id` AS `id`,`objects`.`parentId` AS `parentId`,`objects`.`type` AS `type`,`objects`.`key` AS `key`,`objects`.`path` AS `path`,`objects`.`index` AS `index`,`objects`.`published` AS `published`,`objects`.`creationDate` AS `creationDate`,`objects`.`modificationDate` AS `modificationDate`,`objects`.`userOwner` AS `userOwner`,`objects`.`userModification` AS `userModification`,`objects`.`classId` AS `classId`,`objects`.`className` AS `className`,`objects`.`childrenSortBy` AS `childrenSortBy`,`objects`.`childrenSortOrder` AS `childrenSortOrder`,`objects`.`versionCount` AS `versionCount`,`fr`.`ooo_id` AS `ooo_id`,`fr`.`language` AS `language`,`fr`.`title` AS `title`,`fr`.`description` AS `description` from ((`object_query_job_category` join `objects` on(`objects`.`id` = `object_query_job_category`.`oo_id`)) left join `object_localized_query_job_category_fr` `fr` on(1 and `object_query_job_category`.`oo_id` = `fr`.`ooo_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `object_localized_job_category_it`
--

/*!50001 DROP VIEW IF EXISTS `object_localized_job_category_it`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`db`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `object_localized_job_category_it` AS select `object_query_job_category`.`oo_id` AS `oo_id`,`object_query_job_category`.`oo_classId` AS `oo_classId`,`object_query_job_category`.`oo_className` AS `oo_className`,`object_query_job_category`.`positions` AS `positions`,`objects`.`id` AS `id`,`objects`.`parentId` AS `parentId`,`objects`.`type` AS `type`,`objects`.`key` AS `key`,`objects`.`path` AS `path`,`objects`.`index` AS `index`,`objects`.`published` AS `published`,`objects`.`creationDate` AS `creationDate`,`objects`.`modificationDate` AS `modificationDate`,`objects`.`userOwner` AS `userOwner`,`objects`.`userModification` AS `userModification`,`objects`.`classId` AS `classId`,`objects`.`className` AS `className`,`objects`.`childrenSortBy` AS `childrenSortBy`,`objects`.`childrenSortOrder` AS `childrenSortOrder`,`objects`.`versionCount` AS `versionCount`,`it`.`ooo_id` AS `ooo_id`,`it`.`language` AS `language`,`it`.`title` AS `title`,`it`.`description` AS `description` from ((`object_query_job_category` join `objects` on(`objects`.`id` = `object_query_job_category`.`oo_id`)) left join `object_localized_query_job_category_it` `it` on(1 and `object_query_job_category`.`oo_id` = `it`.`ooo_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `object_localized_position_de`
--

/*!50001 DROP VIEW IF EXISTS `object_localized_position_de`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`db`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `object_localized_position_de` AS select `object_query_position`.`oo_id` AS `oo_id`,`object_query_position`.`oo_classId` AS `oo_classId`,`object_query_position`.`oo_className` AS `oo_className`,`object_query_position`.`category__id` AS `category__id`,`object_query_position`.`category__type` AS `category__type`,`objects`.`id` AS `id`,`objects`.`parentId` AS `parentId`,`objects`.`type` AS `type`,`objects`.`key` AS `key`,`objects`.`path` AS `path`,`objects`.`index` AS `index`,`objects`.`published` AS `published`,`objects`.`creationDate` AS `creationDate`,`objects`.`modificationDate` AS `modificationDate`,`objects`.`userOwner` AS `userOwner`,`objects`.`userModification` AS `userModification`,`objects`.`classId` AS `classId`,`objects`.`className` AS `className`,`objects`.`childrenSortBy` AS `childrenSortBy`,`objects`.`childrenSortOrder` AS `childrenSortOrder`,`objects`.`versionCount` AS `versionCount`,`de`.`ooo_id` AS `ooo_id`,`de`.`language` AS `language`,`de`.`title` AS `title`,`de`.`description` AS `description` from ((`object_query_position` join `objects` on(`objects`.`id` = `object_query_position`.`oo_id`)) left join `object_localized_query_position_de` `de` on(1 and `object_query_position`.`oo_id` = `de`.`ooo_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `object_localized_position_en`
--

/*!50001 DROP VIEW IF EXISTS `object_localized_position_en`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`db`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `object_localized_position_en` AS select `object_query_position`.`oo_id` AS `oo_id`,`object_query_position`.`oo_classId` AS `oo_classId`,`object_query_position`.`oo_className` AS `oo_className`,`object_query_position`.`category__id` AS `category__id`,`object_query_position`.`category__type` AS `category__type`,`object_query_position`.`applications` AS `applications`,`object_query_position`.`site` AS `site`,`objects`.`id` AS `id`,`objects`.`parentId` AS `parentId`,`objects`.`type` AS `type`,`objects`.`key` AS `key`,`objects`.`path` AS `path`,`objects`.`index` AS `index`,`objects`.`published` AS `published`,`objects`.`creationDate` AS `creationDate`,`objects`.`modificationDate` AS `modificationDate`,`objects`.`userOwner` AS `userOwner`,`objects`.`userModification` AS `userModification`,`objects`.`classId` AS `classId`,`objects`.`className` AS `className`,`objects`.`childrenSortBy` AS `childrenSortBy`,`objects`.`childrenSortOrder` AS `childrenSortOrder`,`objects`.`versionCount` AS `versionCount`,`en`.`ooo_id` AS `ooo_id`,`en`.`language` AS `language`,`en`.`title` AS `title`,`en`.`description` AS `description` from ((`object_query_position` join `objects` on(`objects`.`id` = `object_query_position`.`oo_id`)) left join `object_localized_query_position_en` `en` on(1 and `object_query_position`.`oo_id` = `en`.`ooo_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `object_localized_position_fr`
--

/*!50001 DROP VIEW IF EXISTS `object_localized_position_fr`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`db`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `object_localized_position_fr` AS select `object_query_position`.`oo_id` AS `oo_id`,`object_query_position`.`oo_classId` AS `oo_classId`,`object_query_position`.`oo_className` AS `oo_className`,`object_query_position`.`category__id` AS `category__id`,`object_query_position`.`category__type` AS `category__type`,`objects`.`id` AS `id`,`objects`.`parentId` AS `parentId`,`objects`.`type` AS `type`,`objects`.`key` AS `key`,`objects`.`path` AS `path`,`objects`.`index` AS `index`,`objects`.`published` AS `published`,`objects`.`creationDate` AS `creationDate`,`objects`.`modificationDate` AS `modificationDate`,`objects`.`userOwner` AS `userOwner`,`objects`.`userModification` AS `userModification`,`objects`.`classId` AS `classId`,`objects`.`className` AS `className`,`objects`.`childrenSortBy` AS `childrenSortBy`,`objects`.`childrenSortOrder` AS `childrenSortOrder`,`objects`.`versionCount` AS `versionCount`,`fr`.`ooo_id` AS `ooo_id`,`fr`.`language` AS `language`,`fr`.`title` AS `title`,`fr`.`description` AS `description` from ((`object_query_position` join `objects` on(`objects`.`id` = `object_query_position`.`oo_id`)) left join `object_localized_query_position_fr` `fr` on(1 and `object_query_position`.`oo_id` = `fr`.`ooo_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `object_localized_position_it`
--

/*!50001 DROP VIEW IF EXISTS `object_localized_position_it`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`db`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `object_localized_position_it` AS select `object_query_position`.`oo_id` AS `oo_id`,`object_query_position`.`oo_classId` AS `oo_classId`,`object_query_position`.`oo_className` AS `oo_className`,`object_query_position`.`category__id` AS `category__id`,`object_query_position`.`category__type` AS `category__type`,`object_query_position`.`applications` AS `applications`,`object_query_position`.`site` AS `site`,`objects`.`id` AS `id`,`objects`.`parentId` AS `parentId`,`objects`.`type` AS `type`,`objects`.`key` AS `key`,`objects`.`path` AS `path`,`objects`.`index` AS `index`,`objects`.`published` AS `published`,`objects`.`creationDate` AS `creationDate`,`objects`.`modificationDate` AS `modificationDate`,`objects`.`userOwner` AS `userOwner`,`objects`.`userModification` AS `userModification`,`objects`.`classId` AS `classId`,`objects`.`className` AS `className`,`objects`.`childrenSortBy` AS `childrenSortBy`,`objects`.`childrenSortOrder` AS `childrenSortOrder`,`objects`.`versionCount` AS `versionCount`,`it`.`ooo_id` AS `ooo_id`,`it`.`language` AS `language`,`it`.`title` AS `title`,`it`.`description` AS `description` from ((`object_query_position` join `objects` on(`objects`.`id` = `object_query_position`.`oo_id`)) left join `object_localized_query_position_it` `it` on(1 and `object_query_position`.`oo_id` = `it`.`ooo_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `object_position`
--

/*!50001 DROP VIEW IF EXISTS `object_position`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`db`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `object_position` AS select `object_query_position`.`oo_id` AS `oo_id`,`object_query_position`.`oo_classId` AS `oo_classId`,`object_query_position`.`oo_className` AS `oo_className`,`object_query_position`.`category__id` AS `category__id`,`object_query_position`.`category__type` AS `category__type`,`object_query_position`.`applications` AS `applications`,`object_query_position`.`site` AS `site`,`objects`.`id` AS `id`,`objects`.`parentId` AS `parentId`,`objects`.`type` AS `type`,`objects`.`key` AS `key`,`objects`.`path` AS `path`,`objects`.`index` AS `index`,`objects`.`published` AS `published`,`objects`.`creationDate` AS `creationDate`,`objects`.`modificationDate` AS `modificationDate`,`objects`.`userOwner` AS `userOwner`,`objects`.`userModification` AS `userModification`,`objects`.`classId` AS `classId`,`objects`.`className` AS `className`,`objects`.`childrenSortBy` AS `childrenSortBy`,`objects`.`childrenSortOrder` AS `childrenSortOrder`,`objects`.`versionCount` AS `versionCount` from (`object_query_position` join `objects` on(`objects`.`id` = `object_query_position`.`oo_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-15 10:04:51
